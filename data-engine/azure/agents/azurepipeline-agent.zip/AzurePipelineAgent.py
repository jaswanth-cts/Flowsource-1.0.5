from datetime import datetime,timedelta 
import base64

from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class AzurePipelineAgent(BaseAgent):
    @flowsource_exception_handler
    def process(self):
        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tool data and update tracking file
        self.process_tool_data()

    def load_configuration(self):
        
        # Retrieve common agent properties
        #self.timeStampFormat = self.config.get("timeStampFormat")
        self.apiTimeFormat = '%Y-%m-%dT%H:%M:%S'
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get('batchSize', 1000)
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000
        # Collect the number of days data to process   
        self.batchCollectDays = self.config.get("batchCollectDays", 30)  

        # Retrieve agent specific properties       
        self.responseTemplate = self.getResponseTemplate()
        self.azurepipelineToken = self.config.get(self.cloud_provider, "").get("azurepipelineToken", "") 

        if len(self.startFromDate) == 10: # Only date is provided
            self.configStartDate = self.startFromDate + "T00:00:00"
              

    def process_tool_data(self):

        self.logger.info('FLOWSOURCE_INFO: In process_tool_data')

        # Authorize the headers
        self.init_authorization()

        for catalog in self.catalogData:

            # Collect appId
            appId = catalog[0]

            # Collect projectName
            projectName = catalog[1]

            # Collect list of pipelines
            pipelineNames = [name.strip() for name in catalog[2].split(",")]

            pipelineIds = self.get_pipeline_ids(appId,projectName,pipelineNames)

            if not pipelineIds:
                self.logger.info(f"No valid pipelines found for appId {appId}")
                continue

            #Collect data for the available pipelines
            for pipelineName, pipelineId in pipelineIds.items():
                if pipelineId:
                    self.process_build_data(appId,projectName, pipelineId, pipelineName)
                else:
                    self.logger.info(f"Pipeline {pipelineName} not found")
                    self.logger.info("Proceeding with next pipeline")
                    continue
            
    def get_pipeline_ids(self, appId,projectName,pipelineNames):

        pipelineIds = {}
        pipelineIdUrl = f"{self.baseUrl}{projectName}/_apis/pipelines?api-version=6.0-preview.1"
        try:
            response = self.getResponse(pipelineIdUrl, "GET", None, None, None, reqHeaders=self.json_headers)
            pipelines = response['value']
            for pipeline in pipelines:
                if pipeline['name'] in pipelineNames:
                    pipelineIds[pipeline['name']] = pipeline['id']
                
        except Exception as e:
                if "404" in str(e):
                    self.logger.exception(f"FLOWSOURCE_AWSCODEPIPELINE_AGENT_ERROR: Error fetching pipelines for appID {appId}\n{str(e)}")
                    self.logger.info("Proceeding with next appId")
                    return
                else:
                    raise e
        return pipelineIds 
          
    def process_build_data(self, appId,projectName, pipelineId,pipelineName):
      
            self.allbuildData = []
            startDate,endDate = self.get_lastupdated_from_tracking(appId,pipelineName)
            pipelineDataUrl = f"{self.baseUrl}{projectName}/_apis/build/builds?definitions={pipelineId}&minTime={startDate}&maxTime={endDate}&resultFilter=Succeeded&api-version=6.0&queryOrder=finishTimeAscending"
            response = self.getResponse(pipelineDataUrl, "GET", None, None, None, reqHeaders=self.json_headers) 
            pipelineData = response.get('value', [])
            
            if pipelineData:
                    for execution in pipelineData:
                        buildEndTime = execution.get('finishTime')

                        # Extract buildEndTime up to seconds
                        buildEndTimeFormatted=buildEndTime[:19]

                        #Convert to buildEndTimeFormatted string to datetime object
                        buildEndTimeDateobj = datetime.strptime(buildEndTimeFormatted, self.apiTimeFormat).replace(tzinfo=self.toolsTimeZone)
                        
                        # Convert to epoch for storing in DB
                        buildEndTimeEpoch = int(buildEndTimeDateobj.timestamp())

                        buildNumber = execution.get('buildNumber')
                        buildUrl = execution.get('url')

                        injectData = {
                        "appid": appId,
                        "jobName": pipelineName,
                        "shortDescription": projectName,
                        "buildNumber": buildNumber,
                        "buildUrl": buildUrl,
                        "result": "SUCCESS",
                        "buildTimestamp": buildEndTimeEpoch
                        }

                        buildData = self.parseResponse(self.responseTemplate, execution, injectData)               
                        self.allbuildData.append(buildData[0])

                        #Update tracking with latest data and publish
                        self.update_tracking_data(appId,pipelineName,buildEndTimeFormatted)
                        self.publishData(self.allbuildData, "Builds", batchSize=self.batchSize, is_residual=False, tracking=self.tracking)
            else:
                    # Update tracking time to current time if there are no problems in the response
                    self.logger.error(f"4001 - FLOWSOURCE_ERROR: All data collected or No data in the given time frame for {pipelineName}")
                    self.update_tracking_data(appId,pipelineName,endDate)
                    self.updateTrackingFile(self.tracking)


            # publish residual data if any               
            if len(self.allbuildData) > 0:
                self.publishData(self.allbuildData, "Builds", batchSize=self.batchSize, is_residual=True, tracking=self.tracking)
                self.logger.info('FLOWSOURCE_INFO: Published a final set of Builds Data')

    def init_authorization(self):
        
        # Retrieve configurations from AWS Manager 
        azurepipelineToken=base64.b64decode(self.keyValues.get(self.azurepipelineToken, '')).decode("utf-8") 
        self.json_headers = {
         "Authorization": f"Bearer " + azurepipelineToken,
         "Content-Type": "application/json",
        }
        
    def update_tracking_data(self, appId,pipelineName,executionStartTime):
        if appId not in self.tracking:
            self.tracking[appId] = {"lastupdated_" +pipelineName: executionStartTime}
        else:
            lastupdated_pipeline_name = "lastupdated_"+pipelineName
            self.tracking[appId][lastupdated_pipeline_name] = executionStartTime
        
    def get_lastupdated_from_tracking(self, appId, pipelineName):
        
        startTime = self.tracking.get(appId, {}).get("lastupdated_" +pipelineName, self.configStartDate)
        endTime = self.getEndTime(startTime, self.batchCollectDays, timeFormat=self.apiTimeFormat, type='dateTime')
        #Convert to DateTime object
        startTimeDateObj = datetime.strptime(startTime, self.apiTimeFormat)
        # Add 1 seconds to the datetime object
        startTimeDateObj = startTimeDateObj + timedelta(seconds=1)
        # Convert back to string for storing in tracking
        startTimeUpdated = startTimeDateObj.strftime(self.apiTimeFormat)
      
        return startTimeUpdated, endTime
   