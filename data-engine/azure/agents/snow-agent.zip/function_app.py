import azure.functions as func
import logging
import os
from SnowAgent import SnowAgent

app = func.FunctionApp()

# Deafult timer is every 2 hr
TRIGGER_TIMER =  os.getenv('FN_TRIGGER_TIMER', '25 */2 * * *')

@app.function_name('snow_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="snowTimer", run_on_startup=False,
              use_monitor=False)
def snow_agent(snowTimer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        snow_Agent = SnowAgent(cloud_provider)
        snow_Agent.process()
        logging.info('Snow agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing snow agent {str(e)}')

        
