import azure.functions as func
import logging
import os
from AwsResilienceHubAgent import AwsResilienceHubAgent

app = func.FunctionApp()

# Deafult timer is every 2 hr
TRIGGER_TIMER =  os.getenv('FN_TRIGGER_TIMER', '15 */2 * * *')

@app.function_name('resilienceHub_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="resilienceHubTimer", run_on_startup=False,
              use_monitor=False)
def resilienceHub_agent(resilienceHubTimer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        awsResilienceHub_Agent = AwsResilienceHubAgent(cloud_provider)
        awsResilienceHub_Agent.process()
        logging.info('ResilienceHub agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing ResilienceHub agent {str(e)}')
