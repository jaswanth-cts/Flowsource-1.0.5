import azure.functions as func
import logging
import os
from DatadogAgent import DatadogAgent

app = func.FunctionApp()

# Deafult timer is every 2 hr
TRIGGER_TIMER =  os.getenv('FN_TRIGGER_TIMER', '5 */2 * * *')

@app.function_name('datadog_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="datadogTimer", run_on_startup=False,
              use_monitor=False)
def datadog_agent(datadogTimer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        datadog_Agent = DatadogAgent(cloud_provider)
        datadog_Agent.process()
        logging.info('Datadog agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing datadog agent {str(e)}')
