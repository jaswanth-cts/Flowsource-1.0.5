import azure.functions as func
import logging
import os
from AzureBoardsAgent import AzureBoardsAgent

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '35 */2 * * *')

@app.function_name('azureboards_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=False, use_monitor=False)
def azureboards_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = AzureBoardsAgent(cloud_provider)
        agent.process()
        logging.info(f'AzureBoardsAgent agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing AzureBoardsAgent agent: {str(e)}')
        