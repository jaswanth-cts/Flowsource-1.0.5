from datetime import datetime as dateTime
from dateutil import parser
import datetime
import re
import json
import base64
from requests.auth import HTTPBasicAuth
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class AzureBoardsAgent(BaseAgent):
    @flowsource_exception_handler
    def process(self):

        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        catalogData = self.fetchCatalogData(self.select_query)

        self.catalog_dict = self.process_catalog_data(catalogData)

        # Process and publish tools data and update tracking file
        self.process_tool_data()

    def load_configuration(self):
        # load common agent config
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get("batchSize", 1000)
        self.apiOutTimeFormat = "%Y-%m-%dT%H:%M:%S.%f%z"
        self.apiInTimeFormat = '%Y-%m-%d %H:%M'
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000
        self.batchCollectDays = self.config.get("batchCollectDays", 30)

        # agent specific var
        self.azureBoardsPAT = self.config.get(self.cloud_provider, "").get("azureBoardsPAT", "")
        self.maxResults = self.config.get("maxResults", "500")
        # load responseTemplate from dynamicTemplate in config.json
        self.responseTemplate = self.getResponseTemplate()

        if len(self.startFromDate) == 10:  # Only date is provided
            self.startFromDate = self.startFromDate + " 00:00"

    def process_tool_data(self):

        self.logger.info("Processing data ...")

        self.perform_authorization()

        # Initialize data structures
        self.data = []

        self.catalogProjectKey = list(self.catalog_dict.keys())

        for appid in self.catalogProjectKey:
            self.process_workitems(appid)

    def perform_authorization(self):
        # Get credentials for the tool
        self.devopsPAT = self.keyValues[self.azureBoardsPAT]    
        self.devopsAuthToken = "Basic " + base64.b64encode(f":{self.devopsPAT}".encode()).decode() 

        self.reqHeaders = {
                                "Content-Type": "application/json",
                                "Authorization": f"{self.devopsAuthToken}"
                            }


    def process_workitems(self, appid):
        projectKey = self.catalog_dict[appid]["projectKey"]
        finalStatus = self.catalog_dict[appid]["dora_final_status"]

        # Getting startTime and endTime for specific project from tracking else start from date
        startTime, endTime = self.get_tracking_last_update(appid)

        response = self.get_workitems(projectKey, finalStatus, startTime, endTime)
        # If there is no response, returning the control to skip the appid
        if not response:
            return
        # Get work items from the response
        workItems = response["workItems"]

        if workItems:
            for workItem in workItems:
                commits = []
                workItemResponse = self.get_workitem_relation(workItem)

                if "relations" in workItemResponse:
                    relations = workItemResponse["relations"]
                    commits = self.extract_commits(relations)
                eventTime = dateTime.strptime(
                                            workItemResponse.get("fields", {}).get("System.ChangedDate", ""),
                                            self.apiOutTimeFormat,)
                injectData = {
                    "commits": commits,
                    "lastUpdatedEpoch": int(eventTime.timestamp()),
                    "appid": appid,
                }
                # Filter the workItem data with responseTemplate specified in config.json
                parsedWorkItem = self.parseResponse(
                        self.responseTemplate, workItemResponse, injectData
                    )
                self.data += parsedWorkItem
                updatetimestamp = self.data[len(self.data) - 1]["lastUpdated"]

                # Update tracking with latest data
                self.update_tracking_data(projectKey, appid, updatetimestamp)
                # Publish Azure boards data
                self.publishData(
                    self.data,
                    fileType = "WorkItem",
                    batchSize=self.batchSize,
                    is_residual=False,
                    tracking=self.tracking,
                )

        else:
            # Update tracking time to current time if there are no workitems in the response
            self.logger.error(f"4001 - FLOWSOURCE_ERROR: No workitems for project key- {projectKey}")
            self.tracking[appid] = {"projectKey": projectKey, "lastupdated": endTime}
            self.updateTrackingFile(self.tracking)

        if len(self.data) > 0:
            # Publish remaining issue data
            self.publishData(
                self.data,
                fileType="WorkItem",
                batchSize=self.batchSize,
                is_residual=True,
                tracking=self.tracking,
            ) 

    def get_workitem_relation(self, workItem):
        workItemId = workItem["id"]
        workItemUrl = f"{self.baseUrl}/_apis/wit/workitems/{workItemId}?$expand=relations&api-version=7.1"
        workItemResponse = self.getResponse(
                        workItemUrl, "GET", None, None,None,None,self.reqHeaders
                    )

        return workItemResponse


    def get_workitems(self, projectKey, finalStatus, startTime, endTime):

        response = None

        # Initialize work item API template with project key in the query
        azureWorkItemsUrl = (
            self.baseUrl + "/_apis/wit/wiql?api-version=7.1&timePrecision=true&$top=" + self.maxResults
        )
        query = {
            "query": f"SELECT [System.Id], [System.ChangedDate] FROM workitems WHERE [System.TeamProject] = '{projectKey}' AND [System.ChangedDate] >= '{startTime}' AND [System.ChangedDate] <= '{endTime}' AND [System.State] = '{finalStatus}' ORDER BY [System.ChangedDate] ASC"
        }
        json_query = json.dumps(query)
        self.data = []


        try:
            response = self.getResponse(
                azureWorkItemsUrl,
                "POST",
                None,
                None,
                json_query,
                HTTPBasicAuth,
                self.reqHeaders,
            )
            return response

        except Exception as e:
            if "error 400" in str(e):
                # If the Project is not accessable by the user, move to next Project
                self.logger.error(
                    "FLOWSOURCE_AZUREBOARDS_AGENT_ERROR: Unable to reach project : "
                    + projectKey
                    + "\n"
                    + str(e)
                )
                self.logger.info("Proceeding to next project")
                # Continue to the next appid if it is not able to get the project
                return []

            else:
                raise e

    def get_tracking_last_update(self,appId):

        startTime = self.tracking.get(appId, {}).get('lastupdated', self.startFromDate)

        # Get end date from startTime with batchCollectDays
        endTime = self.getEndTime(startTime,self.batchCollectDays,timeFormat= self.apiInTimeFormat,type='dateTime')

        return str(startTime),str(endTime)

    def extract_commits(self, relations):
        commits = []
        for relation in relations:
            url = relation.get("url")
            commit = []
            commit_id = ""
            # Set commit_id and timestamp from the relations
            if "Git/Commit/" in url:
                # Get commit id from the url in relations
                commit = re.split(r"(?i)%2f", url)
                commit_id = commit[2]
                # Get timestamp from the authorizedDate in relations
                timestamp = dateTime.strptime(relation.get("attributes").get(
                                    "authorizedDate"
                                ), self.apiOutTimeFormat,)
                epoch_time = int(timestamp.timestamp())
                commits.append(
                                    {"id": commit_id, "timestamp": epoch_time}
                                )
        return commits

    def update_tracking_data(self, projectKey, appid, updatetimestamp):
        # update tracking with the last issue updatedTime
        dt = parser.parse(updatetimestamp)
        fromDateTime = dt + datetime.timedelta(minutes=0o1)
        fromDateTime = fromDateTime.strftime(self.apiInTimeFormat)
        self.tracking[appid] = {"projectKey": projectKey, "lastupdated": fromDateTime}

    def process_catalog_data(self, catalogData):
        # Format the catalog data in key:value pair
        # eg.{app_id_value:{"projectKey":projectKey_value,"dora_final_status":dora_final_status_value}
        processedCatalogData = {}
        for catalog in catalogData:
            if catalog:

                if (catalog[2] is not None and catalog[2] !=''):
                    # Take dora-alm-final-status as final status
                    finalStatus = catalog[2] 
                elif  (catalog[3] is not None and catalog[3] !=''):
                    # Take dora-jira-final-status as final status
                    finalStatus = catalog[3] 

                processedCatalogData[catalog[0]] = {
                    "projectKey": catalog[1],
                    "dora_final_status": finalStatus
                }
        return processedCatalogData
