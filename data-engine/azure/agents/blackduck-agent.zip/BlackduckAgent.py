from datetime import datetime 
import time
import os
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class BlackduckAgent(BaseAgent):
    @flowsource_exception_handler
    def process(self):
        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tool data and update tracking file
        self.process_tool_data()

    def load_configuration(self):
        # Retrieve common agent properties
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get('batchSize', 1000)
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        # Retrieve agent specific properties
        self.BlackduckToken = self.config.get(self.cloud_provider, '').get("BlackduckToken", '')
         #load responseTemplate from dynamicTemplate in config.json
        self.responseTemplate = self.getResponseTemplate()
        self.versionsResponseTemplate = self.responseTemplate.get('versionsResponseTemplate', {})

        if len(self.startFromDate) == 10:
            self.startFromDate = self.startFromDate + "T00:00:00.0000Z"
    
    def process_tool_data(self):
        self.logger.info('FLOWSOURCE_INFO: In process_tool_data')
        self.perform_authorization()
        for catalog in self.catalogData:
            appid = catalog[0]
            projectName = catalog[1]
            self.process_project_versions(appid, projectName)

    def process_project_versions(self,appid, projectName):
        """Process project versions for a given appId and projectName."""
    
        # Fetch project ID
        project_id = self.get_project_id(projectName)
        if not project_id:
            self.logger.info(f"Project '{projectName}' not found. Skipping...")
            return

        # Fetch and process project versions
        versions = self.get_project_versions(project_id)

        if not versions:
            self.logger.info(f"No versions found for project '{projectName}'. Skipping...")
            return

        self.lastScanDate_threshold = self.get_tracking_last_update(appid)

         # Filter and sort versions in ascending order of lastScanDate
        sorted_versions = sorted(
            [
                version for version in versions
                if 'lastScanDate' in version and datetime.strptime(version['lastScanDate'], "%Y-%m-%dT%H:%M:%S.%fZ") > self.lastScanDate_threshold
            ],
            key=lambda v: datetime.strptime(v['lastScanDate'], "%Y-%m-%dT%H:%M:%S.%fZ"),
            reverse=False  # Ascending order
        )

        # Check if no versions remain after filtering
        if not sorted_versions:
            self.logger.info(f"No versions found for project '{projectName}' after applying filtering criteria. Skipping...")
            return

        self.versionsData = []
        
        # Process version details (e.g., risk profiles, scan dates, etc.)
        self.extract_version_detail_data(appid, project_id, projectName, sorted_versions)

    def get_project_id(self, projectName):
        """Fetch the project ID by project name."""
        projects_url = f"{self.baseUrl}/api/projects?q=name:{projectName}"
        response = self.getResponse(projects_url, "GET", None, None, None, reqHeaders=self.headers)

        projects = response.get('items', [])
        if not projects:
            return None
    
        project = projects[0]
        project_id = project['_meta']['href'].split('/')[-1]  # Extract project ID
        return project_id
       
    
    def get_project_versions(self, project_id):
        """Fetch versions for a given project ID."""
        versions_url = f"{self.baseUrl}/api/projects/{project_id}/versions?limit=1000"
        response = self.getResponse(versions_url, "GET", None, None, None, reqHeaders=self.headers)

        return response.get('items', [])
    
    def extract_version_detail_data(self, appId, project_id, projectName, versions):
        """Extract details of a specific project version."""
        for version in versions:
            lastScanDate = version.get('lastScanDate', None)
            
            # Initialize totals for risk levels
            total_counts = {
                "CRITICAL": 0,
                "HIGH": 0,
                "MEDIUM": 0,
                "LOW": 0,
                "UNKNOWN": 0
            }


            # Dynamically process all profiles in the version data
            for profile, profile_data in version.items():
                # Check if the profile contains 'counts' and is a dictionary
                if isinstance(profile_data, dict) and 'counts' in profile_data:
                    for count in profile_data['counts']:
                        count_type = count['countType']
                        if count_type in total_counts:
                            total_counts[count_type] += count['count']
            
            # Prepare data for publishing
            injectData = {
                "appId": appId,
                "projectId": project_id,
                "versionId": version.get('_meta', {}).get('href', '').split('/')[-1],
                "versionName": version.get('versionName', ''),
                "highSeverity": total_counts["HIGH"],
                "criticalSeverity": total_counts["CRITICAL"],
                "mediumSeverity": total_counts["MEDIUM"],
                "lowSeverity": total_counts["LOW"],
                "infoSeverity": total_counts["UNKNOWN"]
            }
            self.versionsData += self.parseResponse(self.versionsResponseTemplate, version, injectData) 
            # Update tracking data           
            self.update_tracking_data(appId, projectName, lastScanDate)
            # Publish the processed data
            self.publishData(self.versionsData, "Versions", batchSize=self.batchSize, is_residual=False, tracking=self.tracking)

        # Publish remaining data if any
        if len(self.versionsData) > 0:
            self.publishData(self.versionsData, "Versions", batchSize=self.batchSize, is_residual=True, tracking=self.tracking)


    def perform_authorization(self):
        """Fetch the authorization token for Black Duck."""
        self.logger.info("Fetching the Black Duck authorization token...")
        # Retrieve the Bearer Token
        bearer_token = self.keyValues.get(self.BlackduckToken, '')

        # Black Duck authentication URL
        auth_url = f"{self.baseUrl}/api/tokens/authenticate"


        # Prepare the headers for the POST request
        headers = {
            "Authorization": f"token {bearer_token}",
            "Content-Type": "application/json"
        }

        # Make the POST request to fetch the token
        response = self.getResponse(auth_url, "POST", None, None, None, reqHeaders=headers)
        self.access_token = response.get("bearerToken", "")
        if self.access_token is None:
            self.logger.info("4003 - FLOWSOURCE_ERROR: No access token received")
            raise ValueError("4003 - FLOWSOURCE_ERROR: Failed to Get Access Token ...")

         # Prepare headers for API requests
        self.headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
    
    def get_tracking_last_update(self, appid):
        """ Get the last scan date from the tracking data for a given appId."""
        projectTracking = self.tracking.get(appid, {})
        lastScanDate_threshold = datetime.strptime(projectTracking.get("lastScanDate", self.startFromDate), "%Y-%m-%dT%H:%M:%S.%fZ")          # If the last scan date is not available, use the start date
        return lastScanDate_threshold
    
    def update_tracking_data(self, appId, projectName, last_scan_date):
        """ Update the tracking data with the last scan date for a given project."""
        projectTracking = self.tracking.get(appId, {})
        projectTracking["lastScanDate"] = str(last_scan_date)
        projectTracking["projectName"] = str(projectName)
        self.tracking[appId] = projectTracking
        