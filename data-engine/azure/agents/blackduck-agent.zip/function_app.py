import azure.functions as func
import logging
import os
from BlackduckAgent import BlackduckAgent

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '40 */2 * * *')

@app.function_name('blackduck_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=False, use_monitor=False)
def blackduck_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = BlackduckAgent(cloud_provider)
        agent.process()
        logging.info(f'Blackduck Agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing Blackduck Agent: {str(e)}')