import azure.functions as func
import logging
import os
from AppDynamicsAgent import AppDynamicsAgent

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '30 */2 * * *')

@app.function_name('appDynamics_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=False, use_monitor=False)
def appDynamics_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = AppDynamicsAgent(cloud_provider)
        agent.process()
        logging.info(f'appDynamics agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing appDynamics agent: {str(e)}')
        