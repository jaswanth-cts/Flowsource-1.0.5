import azure.functions as func
import logging
import os
from JenkinsAgent import JenkinsAgent

app = func.FunctionApp()

# Deafult timer is every 2 hr
TRIGGER_TIMER =  os.getenv('FN_TRIGGER_TIMER', '10 */2 * * *')

@app.function_name('jenkins_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="jenkinsTimer", run_on_startup=False,
              use_monitor=False)
def jenkins_agent(jenkinsTimer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        jenkins_Agent = JenkinsAgent(cloud_provider)
        jenkins_Agent.process()
        logging.info('Jenkins agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing Jenkins agent {str(e)}')
