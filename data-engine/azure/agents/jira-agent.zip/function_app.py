import azure.functions as func
import logging
import os
from JiraAgent import Jira_Agent

app = func.FunctionApp()

# Deafult timer is every 2 hr
TRIGGER_TIMER =  os.getenv('FN_TRIGGER_TIMER', '20 */2 * * *')

@app.function_name('jira_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="jiraTimer", run_on_startup=False,
              use_monitor=False)
def jira_agent(jiraTimer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        jira_Agent = Jira_Agent(cloud_provider)
        jira_Agent.process()
        logging.info('Jira agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing jira agent {str(e)}')
