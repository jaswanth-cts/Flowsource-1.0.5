import azure.functions as func
import logging
import os
from VeracodeAgent import VeracodeAgent

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '0 */2 * * *')

@app.function_name('veracode_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=True, use_monitor=False)
def veracode_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = VeracodeAgent(cloud_provider)
        agent.process()
        logging.info(f'Veracode agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing Veracode agent: {str(e)}')
        