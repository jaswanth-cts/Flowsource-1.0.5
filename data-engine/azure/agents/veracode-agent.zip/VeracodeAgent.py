from datetime import datetime
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class VeracodeAgent(BaseAgent):

    @flowsource_exception_handler
    def process(self):

        # Load configurations and initialize
        self.load_configuration()
        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Fetch catalog data 
        self.catalog_dict = self.process_catalog_data(self.catalogData)

        # Fetch authentication header
        self.perform_authorization()

        # Process and publish tools data and update tracking file
        self.process_tool_data()

    def load_configuration(self):

        # load common agent config var
        self.dynamicTemplate = self.config.get("dynamicTemplate", {})
        self.select_query = self.config.get(self.cloud_provider, "").get(
            "catalogDataSelectQuery", ""
        )
        # Retrieve credentials specific to the agent from config.json
        self.apiId = self.config.get(self.cloud_provider, "").get(
            "veracode_id", ""
        )
        self.apiKey = self.config.get(self.cloud_provider, "").get(
            "veracode_key", ""
        )
        self.select_query = self.config.get(self.cloud_provider, "").get(
            "catalogDataSelectQuery", ""
        )
        self.batchSize = self.config.get("batchSize", 1000)

        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        # Check the length of startFromDate, if it is equal to 10 add time and zone
        if len(self.startFromDate) == 10:
            self.startFromDate = self.startFromDate + "T00:00:00+0000"

    def perform_authorization(self):
        self.api_id = self.keyValues[self.apiId]
        self.api_key = self.keyValues[self.apiKey]
        

    def process_tool_data(self):

        self.logger.info("FLOWSOURCE_INFO: Processing tool data ...")

        # Initialize scanData list and ResponseTemplate from dynamicTemplate in config.json
        self.scanData = []
        self.scanResponseTemplate = self.dynamicTemplate.get("scanResponseTemplate", {})
        
        # Get appId(catalog[0]) and projectId(catalog[1]) to process
        for catalog in self.catalogData:
            self.process_scan_details(catalog[0], catalog[1])


    def process_scan_details(self, appid, appName):

        # Get application GUID
        appGUID = self.get_application_details(appName)

        if appGUID:
            tracking_last_scan_date = self.get_tracking_lastUpdate(appid)
            # Get Scans Details
            scan_detail = self.get_scan_data(appGUID)         
            
            if scan_detail:
                
                self.scanDate = (
                                scan_detail.get("static-analysis").get("submitted_date", "")
                            )
                scanDateEpoch = int(datetime.strptime(self.scanDate, "%Y-%m-%d %H:%M:%S %Z").timestamp())
                if scanDateEpoch < tracking_last_scan_date or scanDateEpoch == tracking_last_scan_date:

                    self.logger.info(f"Data has been collected till the latest scan for appname-{appName}")
                    
                else:
                    injectData = self.extract_scan_detail(appid, scan_detail) 
                    
                    self.scanData += self.parseResponse(
                                    self.scanResponseTemplate, scan_detail, injectData)
                
                    self.update_tracking_data(self.scanDate, self.scanId, appid, appName)
                    self.publishData(self.scanData,
                                    fileType="Scan",
                                    batchSize=self.batchSize,
                                    is_residual=True,
                                    tracking=self.tracking,
                                    )
        else:
            self.logger.info("Application name is invalid...skipping to the next application")


     # Get Scan Data
    def get_scan_data(self, application_guid):
        
        # Below API fetches only latest scan report for the application
        self.logger.info("Fetching the scan for the project ...")
        scan_url = self.baseUrl + f"appsec/v2/applications/{application_guid}/summary_report"

        # Make the GET request with HMAC authentication
        scans = None
        scans = self.getResponse(scan_url, "GET", self.api_id, self.api_key, None, aType='HMAC')
        return scans
    
    def extract_scan_detail(self, appid, scan_detail):
        # Get Scans Details
        self.scanId = str(scan_detail.get("static-analysis").get("version"))
        severity_count = {}
        for severity_item in scan_detail.get("severity"):
            for category_item in severity_item['category']:
                severity = category_item['severity']
                count = category_item['count']
                if severity in severity_count:
                    severity_count[severity] += count
                else:
                    severity_count[severity] = count
        highSeverity = 0
        if 'VERY_HIGH' or 'HIGH' in severity_count:
            highSeverity = severity_count.get('VERY_HIGH', 0) + severity_count.get('HIGH', 0)

        injectData = {
                    "appid": appid,
                    "scanId": self.scanId,
                    "scanFinishedOn": self.scanDate,
                    "highSeverity": highSeverity,
                    "mediumSeverity": severity_count.get('MEDIUM', 0),
                    "lowSeverity": severity_count.get('LOW', 0),
                    "infoSeverity": severity_count.get('INFORMATIONAL', 0)
                    }      
                              
        return injectData      
          

    def get_application_details(self, appName):

        #Get application GUID using appname
        self.logger.info("Fetching the application details ...")
        appUrl = (self.baseUrl + "appsec/v1/applications?name="+appName)       
        response = None   

        try:
            response = self.getResponse(appUrl, "GET", self.api_id, self.api_key, None, aType='HMAC')
        except Exception as e:
            if "404" in str(e):
                self.logger.error(
                    f"FLOWSOURCE_ERROR: Unable to reach project : "
                    + appUrl
                    + "\n"
                    + str(e)
                )
                return
            else:
                raise e

        # Check if the request was successful
        application = response.get("_embedded",{})
        # Fetch the GUID of the application
        if 'applications' in application and len(application['applications']) > 0:
            application_guid = application['applications'][0]['guid']
            return application_guid


    def process_catalog_data(self, catalogData):
        # Format the catalog data in kye:value pair
        # eg.{app_id_value:{'projectKey':projectKey_value}
        processedCatalogData = {}
        for catalog in catalogData:
            if catalog:
                processedCatalogData[catalog[0]] = {
                    "applicationName": catalog[1],
                }
        return processedCatalogData

    def update_tracking_data(self, scanDateTime, scanId, appid, appName):
        self.tracking[appid] = {"lastupdated": scanDateTime, "scanID": scanId, "appName": appName}


    def get_tracking_lastUpdate(self, appId):

        # Converting env startFromDate into required format
        startDate = datetime.strptime(self.startFromDate, "%Y-%m-%dT%H:%M:%S%z").strftime("%Y-%m-%d %H:%M:%S %Z")

        # fetch the scandate either from config.json or tracking file
        lastScanDate = self.tracking.get(appId, {}).get("lastupdated",startDate)
        lastScanDateEpoch = int(datetime.strptime(lastScanDate, "%Y-%m-%d %H:%M:%S %Z").timestamp())
        return lastScanDateEpoch