import azure.functions as func
import logging
import os
from SonarQubeAgent import SonarQubeAgent

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '0 */2 * * *')

@app.function_name('sonarqube_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=True, use_monitor=False)
def sonarqube_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = SonarQubeAgent(cloud_provider)
        agent.process()
        logging.info(f'SonarQube agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing SonarQube agent: {str(e)}')
        