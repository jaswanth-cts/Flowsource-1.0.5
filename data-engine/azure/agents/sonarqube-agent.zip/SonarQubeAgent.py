from datetime import datetime, timedelta
from dateutil import parser
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class SonarQubeAgent(BaseAgent):

    @flowsource_exception_handler
    def process(self):

        # Load configurations and initialize
        self.load_configuration()
        # Fetch catalog data
        catalogData = self.fetchCatalogData(self.select_query)
        # Fetch catalog data dictionary
        self.catalog_dict = self.process_catalog_data(catalogData)
        # Process and publish tools data and update tracking file
        self.process_tool_data()

    def load_configuration(self):
        # Retrieve credentials specific to the agent from config.json
        self.sonarqubeAuthToken = self.config.get(self.cloud_provider, "").get(
            "sonarqubeAuthToken", ""
        )
        self.select_query = self.config.get(self.cloud_provider, "").get(
            "catalogDataSelectQuery", ""
        )
        self.batchSize = self.config.get("batchSize", 1000)
        self.batchCollectDays = self.config.get("batchCollectDays", 30)

        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        # Check the length of startFromDate, if it is equal to 10 add time and zone
        if len(self.startFromDate) == 10:
            self.configStartDate = self.startFromDate + "T00:00:00+0000"

    def process_tool_data(self):

        self.logger.info("FLOWSOURCE_INFO: Processing tool data ...")

        # perform authorization
        self.perform_authorization()

        # fetch appId list
        catalogAppIdList = self.get_dict_keys(self.catalog_dict)

        # Iterate over the appId list
        for appId in catalogAppIdList:
            
            # Get the sonaqube project key
            projectKey = self.catalog_dict[appId]["projectKey"]

            # call project analyses api
            self.process_project_analyses(projectKey=projectKey, appId=appId)

            
    def process_project_analyses(self, projectKey, appId):

        # Initialize method variables
        pageIndex = 1
        pageSize = 100
        sonarQubeDataArray = []
        fileType = "Scan"

        # Get start and end date time
        startDatetime, endDateTime = self.get_tracking_lastUpdate(appId)
        
        nextPageResponse = True
        while nextPageResponse:

            # API endpoint to fetch the scan details, replace '+' with '%2B' for the rest call
            project_analyses_api_endpoint = f"/api/project_analyses/search?project={projectKey}&from={str(startDatetime).replace('+', '%2B')}&to={str(endDateTime).replace('+', '%2B')}&p={pageIndex}&ps={pageSize}"
            # Construct the full URL
            project_analyses_api_url = f"{self.baseUrl}{project_analyses_api_endpoint}"
            try:

                # Call the REST API
                project_analyses_api_response = self.getResponse(
                    project_analyses_api_url,
                    "GET",
                    None,
                    None,
                    None,
                    reqHeaders=self.req_headers,
                )

            except Exception as ex:
                if "404" in str(ex):
                    self.logger.error(f"FLOWSOUREC_SONARQUBE_AGENT_ERROR: Error fetching project key: {projectKey}: {ex}")
                    self.logger.info("FLOWSOURCE_INFO: Proceeding with next project key")
                    # return to fetch project analyses data for next appId in case of 404
                    return
                else:
                    raise ex
           
            # Fetch total number of records
            totalRecords = project_analyses_api_response["paging"]["total"]
            # Fetch 'analyses' array
            projectAnalysesArray = project_analyses_api_response["analyses"]

            # prepare map of analysesId and corresponding analysesDate
            projectAnalysesDateAndIdMap = self.prepare_analyses_id_and_date_map(
                projectAnalysesArray=projectAnalysesArray
            )

            if len(projectAnalysesDateAndIdMap) > 0:
                # Fetch violations for each projecy analyses id
                projectAnalysesIdList = self.get_dict_keys(projectAnalysesDateAndIdMap)
                # Iterate over analysesId list
                for analysesId in projectAnalysesIdList:
                    analysesDate = projectAnalysesDateAndIdMap.get(analysesId)
                    sonarqubeData = self.process_search_measure_history(
                        appId,
                        analysesId,
                        analysesDate,
                        projectKey,
                        fromDate=analysesDate,
                        toDate=analysesDate,
                    )
                    sonarQubeDataArray.append(sonarqubeData)

                    # Update tracking data and publishing data
                    self.logger.info(f"FLOWSOURCE_INFO: Updating tracking file")
                    self.update_tracking_data(endDateTime=endDateTime, appid=appId)
                    self.publishData(
                        sonarQubeDataArray,
                        fileType,
                        self.batchSize,
                        False,
                        self.tracking,
                    )
            else:
                # Updating tracking file without publishing the data as there is no data corresponding to the appId
                self.update_tracking_data(endDateTime=endDateTime, appid=appId)
                self.updateTrackingFile(self.tracking)

            if totalRecords < pageSize * pageIndex:
                nextPageResponse = False
            else:
                # Process for next Page
                pageIndex += 1

        # publish residual data if any
        if len(sonarQubeDataArray) > 0:
            self.publishData(
                sonarQubeDataArray, fileType, self.batchSize, True, self.tracking
            )

    def perform_authorization(self):
        # Get credentials for the tool
        authToken = self.keyValues[self.sonarqubeAuthToken]

        # create request headers
        self.req_headers = {
            "Authorization": f"Basic {authToken}",
            "Accept": "application/json",
        }

    def prepare_analyses_id_and_date_map(self, projectAnalysesArray):
        projectAnalysesDateAndIdMap = {}
        for projectAnalyses in projectAnalysesArray:
            analysesDate = projectAnalyses["date"]
            analysesId = projectAnalyses["key"]
            projectAnalysesDateAndIdMap[analysesId] = analysesDate
        return projectAnalysesDateAndIdMap

    def process_search_measure_history(
        self, appId, analysesId, analysesDate, projectKey, fromDate, toDate
    ):
        self.logger.info("FLOWSOURCE_INFO: Processing search measure history api ...")

        # Initialize method variables
        nextPageResponse = True
        pageIndex = 1
        pageSize = 100

        while nextPageResponse:

            # API endpoint to fetch bugs, code_smells and vuln, , replace '+' with '%2B' for the rest call
            search_measure_history_api_endpoint = f"/api/measures/search_history?component={projectKey}&metrics=major_violations,minor_violations,info_violations,critical_violations,blocker_violations&from={str(fromDate).replace('+','%2B')}&to={str(toDate).replace('+','%2B')}&p={pageIndex}&ps={pageSize}"
            # Construct the full URL
            search_measure_history_api_url = (
                f"{self.baseUrl}{search_measure_history_api_endpoint}"
            )
            # Call REST API
            search_measure_history_api_response = self.getResponse(
                search_measure_history_api_url,
                "GET",
                None,
                None,
                None,
                reqHeaders=self.req_headers,
            )

            # fetch the total records to check next page
            totalRecords = search_measure_history_api_response["paging"]["total"]
            # fetch 'measures' array
            measuresArray = search_measure_history_api_response["measures"]
            for metricsData in measuresArray:

                metricName = metricsData["metric"]
                # check for issues for each type of violations
                match (metricName):
                    case "critical_violations" | "blocker_violations":
                        historyDataArray = metricsData["history"]
                        highIssues = self.getMetricValue(historyDataArray, analysesDate)
                    case "major_violations":
                        historyDataArray = metricsData["history"]
                        mediumIssues = self.getMetricValue(
                            historyDataArray, analysesDate
                        )
                    case "minor_violations":
                        historyDataArray = metricsData["history"]
                        lowIssues = self.getMetricValue(historyDataArray, analysesDate)
                    case "info_violations":
                        historyDataArray = metricsData["history"]
                        infoIssues = self.getMetricValue(historyDataArray, analysesDate)

            # check if next page exists
            if totalRecords < pageSize * pageIndex:
                nextPageResponse = False
            else:
                # Process for next Page
                pageIndex += 1

        # split date and time from zone e.g: scanFinishedOn - 2024-12-05T12:33:22
        customAnalysesDate = analysesDate.split("+")[0]

        sonarqubeData = {
            "appid": appId,
            "scanId": analysesId,
            "scanFinishedOn": customAnalysesDate,
            "highSeverity": highIssues,
            "mediumSeverity": mediumIssues,
            "lowSeverity": lowIssues,
            "infoSeverity": infoIssues,
        }

        return sonarqubeData

    def getMetricValue(self, historyDataArray, analysesDate):
        # Retrieve the metric value for the given analyses date by checking if the date field matches the analysesDate
        return next(
            (
                historyData["value"]
                for historyData in historyDataArray
                if historyData["date"] == analysesDate
            ),
            None,
        )

    def process_catalog_data(self, catalogData):
        # Format the catalog data in kye:value pair
        # eg.{app_id_value:{'projectKey':projectKey_value}
        processedCatalogData = {}
        for catalog in catalogData:
            if catalog:
                processedCatalogData[catalog[0]] = {
                    "projectKey": catalog[1],
                }
        return processedCatalogData

    def update_tracking_data(self, endDateTime, appid):
        # set the required date format
        dateFormat = "%Y-%m-%dT%H:%M:%S%z"
        parsedDate = datetime.strptime(endDateTime, dateFormat)
        # Add one second for next iteration
        updateEndDateTime = parsedDate + timedelta(seconds=1)
        self.tracking[appid] = {"lastupdated": updateEndDateTime.strftime(dateFormat)}

    def get_dict_keys(self, dict):
        return list(dict.keys())

    def get_tracking_lastUpdate(self, appId):
        # fetch the startDate either from config.json or tracking file
        startDate = self.tracking.get(appId, {}).get("lastupdated", self.configStartDate)
        
        # set the required date format
        dateFormat = "%Y-%m-%dT%H:%M:%S%z"
        
        # get end time based on batchCollectDays
        endDateTime = self.getEndTime(startDate, self.batchCollectDays, dateFormat, "dateTime")
        # Parse the startDatetime using the correct date format
        startDatetime = datetime.strptime(startDate, dateFormat)
    
        # format the startDate
        updatedStartDateTime = startDatetime.strftime(dateFormat)
        return updatedStartDateTime, endDateTime