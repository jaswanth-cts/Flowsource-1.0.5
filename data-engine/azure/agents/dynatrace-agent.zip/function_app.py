import azure.functions as func
import logging
import os
from DynatraceAgent import DynatraceAgent

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '30 */2 * * *')

@app.function_name('dynatrace_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=False, use_monitor=False)
def dynatrace_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = DynatraceAgent(cloud_provider)
        agent.process()
        logging.info(f'Dynatrace agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing Dynatrace agent: {str(e)}')
        