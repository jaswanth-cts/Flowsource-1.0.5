import azure.functions as func
import logging
import os
from CheckmarxAgent import CheckmarxAgent

app = func.FunctionApp()

# Deafult timer is every 2 hr
TRIGGER_TIMER =  os.getenv('FN_TRIGGER_TIMER', '0 */2 * * *')

@app.function_name('checkmarx_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="checkmarxTimer", run_on_startup=False,
              use_monitor=False)
def checkmarx_agent(checkmarxTimer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        checkmarx_Agent = CheckmarxAgent(cloud_provider)
        checkmarx_Agent.process()
        logging.info('checkmarx agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing checkmarx agent {str(e)}')
