import azure.functions as func
import logging
import os
from GCPCloudBuild import GCPCloudBuild

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '0 */2 * * *')

@app.function_name('gcpcloudbuild_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=False, use_monitor=False)
def gcpcloudbuild_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = GCPCloudBuild(cloud_provider)
        agent.process()
        logging.info(f'GCPCloudBuild agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing GCPCloudBuild agent: {str(e)}')
        