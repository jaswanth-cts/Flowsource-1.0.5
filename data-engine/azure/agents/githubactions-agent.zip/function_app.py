import azure.functions as func
import logging
import os
from GithubActionsAgent import GithubActionsAgent

app = func.FunctionApp()

# Default timer is every 2 hr
TRIGGER_TIMER = os.getenv('FN_TRIGGER_TIMER', '40 */2 * * *')

@app.function_name('githubactions_agent')
@app.schedule(schedule=TRIGGER_TIMER, arg_name="timer", run_on_startup=False, use_monitor=False)
def githubactions_agent(timer: func.TimerRequest) -> None:
    try:
        cloud_provider = 'AZURE'
        agent = GithubActionsAgent(cloud_provider)
        agent.process()
        logging.info(f'GithubActions agent executed successfully ...')

    except Exception as e:
        logging.error(f'ERROR while executing GithubActions agent: {str(e)}')
        