from abc import ABC, abstractmethod


class IPipeline(ABC):

    # Execute data engine pipeline
    @abstractmethod
    def execute_pipeline(self):
        pass
