import traceback
from IDataEngine import IDataEngine
from utils.FlowsourceLogger import FlowsourceLogger
from PipelineFactory import PipelineFactory

class DataEngine(IDataEngine):

    def __init__(self, cloud_provider, tool_name, json_file_path):
        self.logger = FlowsourceLogger(tool_name.split('.')[1])
        self.tool_name = tool_name
        self.cloud_provider = cloud_provider
        self.json_file_path = json_file_path

    def processDataEngine(self):
        pipeline = None
        try:
            #process data engine
            self.logger.info('Processing data ...')
            pipelineFactory = PipelineFactory(self.cloud_provider, self.tool_name, self.json_file_path)
            
            # Create instance of the engine for specific tool
            pipeline = pipelineFactory.create_pipeline()

            # Create and process queries
            pipeline.execute_pipeline()
        except Exception as e:
            self.logger.exception(f"FLOWSOURCE_DATA_ENGINE_ERROR: Failed to process data engine {e}")
            error_message = traceback.format_exc()
            if pipeline is not None:
                pipeline.copy_file_to_dlq(error_message)
            raise e

