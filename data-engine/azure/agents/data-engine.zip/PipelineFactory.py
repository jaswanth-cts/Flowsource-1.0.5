from utils.ClassLoader import ClassLoader
from utils.FlowsourceLogger import FlowsourceLogger


class PipelineFactory:

    def __init__(self, cloud_provider, tool_name, json_file_path):
        # Splitting the tool name to get the category (Eg: alm)
        self.category = tool_name.split(".")[0]

        # Splitting the tool name to get the tool name (Eg: Jira)
        self.tool_name = tool_name.split('.')[1]

        self.logger = FlowsourceLogger(self.tool_name)
        self.cloud_provider = cloud_provider
        self.json_file_path = json_file_path

    def create_pipeline(self):
        try:
            self.logger.info(f"Creating Engine Pipeline for {self.tool_name}")

            # Setting the submodule name (Eg: JiraEngine)
            submodule = self.tool_name.title() + "Engine"

            # Create and instantiate pipeline class
            pipeline = ClassLoader(
                self.cloud_provider.lower() + ".pipeline." + self.category, submodule, self.tool_name
            ).get_classLoader_access()
            tool_pipeline = pipeline(self.cloud_provider, self.tool_name, self.json_file_path)
            return tool_pipeline
        except Exception as e:
            self.logger.exception(
                f"FLOWSOURCE_PIPELINE_ERROR: Failed to create pipeline {str(e)}"
            )
            raise e
