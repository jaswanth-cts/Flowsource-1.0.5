from abc import ABC, abstractmethod


class IDataEngine(ABC):

    # processDataEngine abstract method
    @abstractmethod
    def processDataEngine(self):
        pass
