import os
from utils.FlowsourceLogger import FlowsourceLogger
from utils.TimeUtils import TimeUtils


class DeadLetterQueue:
    def __init__(self, cloud_provider, tool_name, json_file_path, storage_access):
        self.logger = FlowsourceLogger(tool_name)
        self.cloud_provider = cloud_provider
        self.storage_name = os.environ["STORAGE_NAME"]
        self.json_file_path = json_file_path
        self.tool_name = tool_name
        self.storage_access = storage_access

    def upload_file_to_dlq(self, error_message):
        #Upload the Process Failed JSON and Error Message in Storage
        try:
            self.logger.info(f"Inside upload_deadletter_data_to_cloud_storage in DeadLetterProcessing")
            timeUtils = TimeUtils()
            timeStamp = timeUtils.get_current_date_month_year()
            deadLetterQueueFolder = "flowsource-agent-data/dead-letter-queue/"+timeStamp+"/"
            destination_json_file_name = self.get_destination_json_file_name(deadLetterQueueFolder)
            # copy json to text file from tool folder to dead-letter-queue folder
            self.storage_access.copy_storage_object(self.storage_name, self.json_file_path, destination_json_file_name)
            # put error message text file in dead-letter-queue folder
            error_file_path = self.get_error_file_path(destination_json_file_name, deadLetterQueueFolder)
            self.storage_access.write_json_to_storage(self.storage_name, error_file_path,
                                                error_message)
            self.logger.info(f"{self.tool_name}_ENGINE - Processed JSON and Exception Message uploaded to {deadLetterQueueFolder}")
        except Exception as e:
            self.logger.exception(f"{self.tool_name}_ENGINE - FLOWSOURCE_DEAD_LETTER_QUEUE_EXCEPTION: Exception occurred in upload_file_to_dlq {e}")
            raise e
    
    # Method to get the destination_key like flowsource-agent-data/dead-letter-queue/{current DD-MM-YY}/SNOW-Snow_Agent-Incident-1724394139257.txt
    def get_destination_json_file_name(self, deadLetterQueueFolder):
        self.logger.info(f"{self.tool_name}_ENGINE - Getting Destination Key...")
        # Extract the filename and modify the extension to .txt
        filename = os.path.splitext(os.path.basename(self.json_file_path))[0]+".txt"
        destination_key = f"{deadLetterQueueFolder}{filename}"
        self.logger.info(f"{self.tool_name}_ENGINE - Key is {self.json_file_path} and destination key is {destination_key}")
        return destination_key

    #Method to get the error_file_path as flowsource-agent-data/dead-letter-queue/{current DD-MM-YY}/SNOW-Snow_Agent-Incident-1724394139257_ERROR.txt
    def get_error_file_path(self, destination_key, deadLetterQueueFolder):
        text_file_name = os.path.splitext(os.path.basename(destination_key))[0]+"_ERROR.txt"
        error_file_path = f"{deadLetterQueueFolder}{text_file_name}"
        self.logger.info(f"{self.tool_name}_ENGINE - Error file path is {error_file_path}")
        return error_file_path