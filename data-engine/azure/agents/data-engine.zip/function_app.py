from utils.FlowsourceLogger import FlowsourceLogger
import azure.functions as func
from DataEngine import DataEngine

app = func.FunctionApp()
    
@app.function_name(name="azure_engine")
@app.blob_trigger(arg_name="blob", path="strg-flowsource-data-agents/flowsource-agent-data/{file}.json", connection="AzureWebJobsStorage")
def azure_engine(blob: func.InputStream):
    cloud_provider = 'AZURE'
    json_file_path = blob.name
    try:
        # Extract the file name using split
        file_name = json_file_path.split('/')[-1]
        tool_category = (file_name.lower()).split('-')[0]
        if tool_category == "catalog":
            tool_name = "system." + tool_category
        else:
            # Extract the first part of the file name before the first '-'
            tool_name = tool_category + "." + (file_name.lower()).split('-')[1]
        
        logger = FlowsourceLogger(tool_name.split('.')[1]) 
        logger.info(f"ENGINE - tool_name is {tool_name}")
        engine = DataEngine(cloud_provider,tool_name,json_file_path)
        
        # Process data engine
        engine.processDataEngine()
        
    except Exception as e:
        logger.exception(f"{tool_name}_ENGINE - FLOWSOURCE_ENGINE_EXCEPTION: Error Processing {cloud_provider} Data Engine {str(e)}")