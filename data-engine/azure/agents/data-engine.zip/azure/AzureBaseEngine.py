from dal.DataAccessLayer import DataAccessLayer
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
from utils.TimeUtils import TimeUtils
from DeadLetterQueue import DeadLetterQueue
import uuid


class AzureBaseEngine(object):
    @flowsource_exception_handler
    def __init__(self, cloud_provider, json_file_path, tool_name):

        self.cloud_provider = cloud_provider
        self.tool_name = tool_name
        self.logger = FlowsourceLogger(self.tool_name)
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = ""
        self.MAIN_TABLE_NAME = ""
        self.schema_name =  "flowsource"
        self.json_file_path = json_file_path
        self.json_folder_path = self.get_json_folder_path(json_file_path)

        # This operation is to get the container name and blob name -> Split the string at the first '/'
        json_path_parts = self.json_file_path.split('/', 1)
        
        # Assign the parts to variables
        self.container_name = json_path_parts[0]
        self.blob_name = json_path_parts[1]
        self.logger.info(
            f"{self.tool_name}_ENGINE - Container Name {self.container_name} && Blob Name {self.blob_name}")

        dal = DataAccessLayer(self.cloud_provider, self.tool_name)
        self.database_access = dal.get_database_access()
        self.storage_access = dal.get_storage_access()

    def processQuery(self, temp_table_name, parameters):
        # Execute commands based on the order provided
        try:
            self.json_data = self.get_json_data_from_blob()
            for parm in parameters:
                commands = parm.split(": ")
                match commands[0]:
                    case "INSERT_TO_MAIN_TABLE_QUERY" | "MERGE_QUERY":
                        self.logger.info(f"{self.tool_name}_ENGINE - Inside INSERT_TO_MAIN_TABLE_QUERY or MERGE_QUERY")
                        query = commands[1]
                        self.database_access.copy_json_data_to_db(
                            self.json_data, temp_table_name, query)
                        self.logger.info(f"{self.tool_name}_ENGINE - Copied to Temp Table -> Main Table Successfully!")
                    case _:
                        raise ValueError(f'1102 - FLOWSOURCE_ENGINE_QUERY_ERROR:{commands[0]} Command not found')

        except Exception as e:
            self.logger.exception(
                f"1101 - {self.tool_name}_ENGINE - FLOWSOURCE_ENGINE_QUERY_EXCEPTION: Failed to process processQuery {e}")
            raise e
        finally:
            self.database_access.delete_temp_table(temp_table_name)
            self.logger.info(
                f"Deleted temporary table successfully from database!")

    def get_json_data_from_blob(self):

        self.logger.info(f"{self.tool_name}_ENGINE - Getting JSON Data from Blob Storage...")
        json_data = self.storage_access.read_tool_json_from_storage(
            self.container_name, self.blob_name)
        return json_data

    def get_json_folder_path(self, json_file_path):

        # Get the path from the folder name eg:"strg-flowsource-data-agents/flowsource-agent-data/{agent_folder}/{file}.json" but need flowsource-agent-data/{agent_folder}/{file}.json
        first_part = json_file_path.split("/")
        extracted_string = first_part[1:]
        json_folder_path = "/".join(extracted_string)
        return json_folder_path

    def copy_file_to_dlq(self, error_message):

        # If any Exception/Error occurred upload the failed JSON and Error Message in Storage by DeadLetterQueue
        self.logger.info(f"{self.tool_name}_ENGINE - Processing DeadLetter Queue...")
        deadLetterDataProcessing = DeadLetterQueue(
            self.cloud_provider, self.tool_name, self.json_folder_path, self.storage_access)
        deadLetterDataProcessing.upload_file_to_dlq(error_message)
        self.logger.info(f"Processed DeadLetter Queue...")

    def format_insert_query(self, insert_query_temp, main_table_name, engineExecutionTime, temp_table_name):
        INSERT_TO_MAIN_TABLE_QUERY = insert_query_temp.format(
                    MAIN_TABLE=main_table_name,
                    ENGINE_EXECUTION_TIME=engineExecutionTime,
                    TEMP_TABLE=temp_table_name
            )

        return INSERT_TO_MAIN_TABLE_QUERY

    @flowsource_exception_handler
    def execute_pipeline(self):

        # Check whether all the required values are provided in the child class
        self.do_health_checks()

        engineExecutionTime = TimeUtils().get_current_time()
        main_table_name = f"{self.schema_name}.{self.MAIN_TABLE_NAME}"
        temp_table_name = f"temp_{self.tool_name}_{uuid.uuid4().hex}"
        self.logger.info(f"Main Table id is {main_table_name} and staging table id is {temp_table_name}")

        INSERT_TO_MAIN_TABLE_QUERY = self.format_insert_query(self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE, main_table_name, engineExecutionTime, temp_table_name)
        self.logger.info(f"Set data pipeline for {self.tool_name}")

        # Set the parameters to be executed in order
        parameters = [f"INSERT_TO_MAIN_TABLE_QUERY: {INSERT_TO_MAIN_TABLE_QUERY}"]

        self.processQuery(temp_table_name,parameters)
    
    def do_health_checks(self):

        # Check whether all the pipeline values are provided 
        if self.MAIN_TABLE_NAME == '':
            self.logger.error('1001 - FLOWSOURCE_BASEENGINE_ERROR: MAIN_TABLE_NAME should not be empty')
            raise ValueError('1001 - FLOWSOURCE_BASEENGINE_ERROR: MAIN_TABLE_NAME should not be empty')
        elif self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE == '':
            self.logger.error('1004 - FLOWSOURCE_BASEENGINE_ERROR: INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE should not be empty')
            raise ValueError('1004 - FLOWSOURCE_BASEENGINE_ERROR: INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE should not be empty')
        else:
            self.logger.info("All required values are provided")