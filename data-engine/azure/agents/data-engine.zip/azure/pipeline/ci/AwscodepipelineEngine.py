from IPipeline import IPipeline
from azure.AzureBaseEngine import AzureBaseEngine

class AwscodepipelineEngine(AzureBaseEngine, IPipeline):
     
    def __init__(self, cloud_provider, tool_name, json_file_path):
        
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "ci_prod_deployment_data"

        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        data->>'id' AS id,
                        data->>'appid' AS appid,
                        data->>'deployment_job' AS deployment_job,
                        data->>'short_description' AS short_description,
                        data->>'build_number' AS build_number,
                        data->>'build_status' AS build_status,
                        (data->>'build_timestamp')::BIGINT AS build_timestamp,
                        data->>'build_url' AS build_url,
                        (data->>'flowsourceTime')::BIGINT AS flowsource_time,
                        data->>'flowsourceTimeX' AS flowsource_timeX,
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {TEMP_TABLE};
                    """
         