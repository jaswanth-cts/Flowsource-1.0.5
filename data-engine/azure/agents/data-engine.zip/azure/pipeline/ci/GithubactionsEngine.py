from IPipeline import IPipeline
from azure.AzureBaseEngine import AzureBaseEngine

class GithubactionsEngine(AzureBaseEngine, IPipeline):
     
    def __init__(self, cloud_provider, tool_name, json_file_path):
        
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "ci_prod_deployment_data"

        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        data->>'id' AS id,
                        data->>'appid' AS appid,
                        data->>'workflowName' AS deployment_job,
                        data->>'runDisplayTitle' AS short_description, 
                        (data->>'runNumber')::BIGINT  AS build_number, 
                        data->>'runStatus' AS build_status,
                        (data->>'runStartedAt')::BIGINT  AS build_timestamp, 
                        data->>'jobsURL' AS build_url,
                        (data->>'flowsourceTime')::BIGINT  as flowsource_time,
                        data->>'flowsourceTimeX' as flowsource_timeX, 
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {TEMP_TABLE};
                    """
          