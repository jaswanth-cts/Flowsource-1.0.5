import uuid
from utils.TimeUtils import TimeUtils
from IPipeline import IPipeline
from azure.AzureBaseEngine import AzureBaseEngine
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class CatalogEngine(AzureBaseEngine, IPipeline):

    def __init__(self, cloud_provider, tool_name, json_file_path):

        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)

        self.MAIN_TABLE_NAME = "catalog_data"

       # Merge only for catalog rest all tables are columnar no updation required
        self.MERGE_SQL_TEMPLATE = """MERGE INTO {MAIN_TABLE} AS MAIN_TABLE USING (
                            SELECT * FROM ( SELECT 
                                data->>'appid' AS appid,
                                data->>'app_name' AS app_name,
                                data->>'annotations' AS annotations,
                                data->>'lob' AS lob,
                                data->>'is_critical' AS is_critical,
                                ROW_NUMBER() OVER (PARTITION BY data->>'appid' 
                                    ORDER BY data->>'appid') AS row_num
                                FROM {TEMP_TABLE} WHERE data->>'appid' IS NOT NULL
                            ) AS ranked_temp
                            WHERE row_num = 1) AS TEMP_TABLE
                            ON MAIN_TABLE.appid = TEMP_TABLE.appid
                            WHEN MATCHED THEN
                            UPDATE SET app_name = TEMP_TABLE.app_name,
                            annotations = TEMP_TABLE.annotations,
                            lob = TEMP_TABLE.lob,
                            is_critical = TEMP_TABLE.is_critical
                            WHEN NOT MATCHED THEN
                                INSERT (appid, app_name, annotations, lob, is_critical, engine_execution_time)
                                VALUES (TEMP_TABLE.appid, TEMP_TABLE.app_name, TEMP_TABLE.annotations, TEMP_TABLE.lob, TEMP_TABLE.is_critical, {ENGINE_EXECUTION_TIME});
                    """

    @flowsource_exception_handler
    def execute_pipeline(self):
        
        engineExecutionTime = TimeUtils().get_current_time()

        main_table_name = f"{self.schema_name}.{self.MAIN_TABLE_NAME}"
        temp_table_name = f"temp_{self.tool_name}_{uuid.uuid4().hex}"

        # Creating merge queries
        MERGE_QUERY = self.format_insert_query(self.MERGE_SQL_TEMPLATE, main_table_name, engineExecutionTime, temp_table_name)

        # Set the parameters to be executed in order
        parameters = [f"MERGE_QUERY: {MERGE_QUERY}"]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(temp_table_name,parameters)
