from IPipeline import IPipeline
from azure.AzureBaseEngine import AzureBaseEngine

class SonarqubeEngine(AzureBaseEngine, IPipeline):
     
    def __init__(self, cloud_provider, tool_name, json_file_path):
        
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "codequality_metrics_data"

        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT 
                        data->>'id' AS id,
                        data->>'appid' AS appid,
                        data->>'scanId' AS scan_id,
                        (data->>'highSeverity')::BIGINT AS high_issues,
                        (data->>'mediumSeverity')::BIGINT AS medium_issues,
                        (data->>'lowSeverity')::BIGINT AS low_issues,
                        (data->>'infoSeverity')::BIGINT AS info_issues,
                        data->>'scanFinishedOn' AS scan_date,
                        (data->>'flowsourceTime')::BIGINT AS flowsource_time,
                        data->>'flowsourceTimeX' AS flowsource_timeX,
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {TEMP_TABLE};
                    """
         
