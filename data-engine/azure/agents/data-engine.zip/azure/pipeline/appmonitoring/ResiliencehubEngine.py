from IPipeline import IPipeline
from azure.AzureBaseEngine import AzureBaseEngine

class ResiliencehubEngine(AzureBaseEngine, IPipeline):
     
    def __init__(self, cloud_provider, tool_name, json_file_path):
        
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "apm_resilience_data"

        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE =  """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        data->>'id' AS id,
                        data->>'appid' AS appid,
                        data->>'assessmentName' AS assessment_name,
                        (data->>'startTime')::BIGINT AS assessment_start_time,
                        data->>'resiliencyScore' AS resilience_score,
                        data->>'complianceStatus' AS compliance_status,
                        (data->>'flowsourceTime')::BIGINT AS flowsource_time,
                        data->>'flowsourceTimeX' AS flowsource_timeX,
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {TEMP_TABLE};
                    """
          
