from IPipeline import IPipeline
from azure.AzureBaseEngine import AzureBaseEngine

class AppdynamicsEngine(AzureBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):
        
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "apm_event_data"

        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        data->>'id',
                        data->>'appid',
                        data->>'eventId' AS event_id,
                        (data->>'eventOccurDateEpoch')::BIGINT AS event_date,
                        (data->>'recoverTimeInSec')::BIGINT AS recovery_time,
                        data->>'environment',
                        (data->>'flowsourceTime')::BIGINT AS flowsource_time,
                        data->>'flowsourceTimeX' AS flowsource_timeX,
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {TEMP_TABLE};
                    """