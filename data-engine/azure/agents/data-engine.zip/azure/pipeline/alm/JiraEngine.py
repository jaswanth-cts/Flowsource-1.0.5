from IPipeline import IPipeline
from utils.TimeUtils import TimeUtils
import uuid
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
from azure.AzureBaseEngine import AzureBaseEngine

class JiraEngine(AzureBaseEngine, IPipeline):
     
    def __init__(self, cloud_provider, tool_name, json_file_path):
        
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "alm_changes_data"
        self.LEADTIME_MAIN_TABLE_NAME = "scm_leadtime_data"

        self.INSERT_TO_MAIN_TABLE_FROM_TABLE_DICT = {
               "jira_scm": """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        data->>'id',
                        data->>'appid',
                        data->>'key' AS story_id,
                        commit_info->>'id' AS commit_id,
                        (commit_info->>'timestamp')::BIGINT AS commit_timestamp,
                        DATE_PART('day', TO_TIMESTAMP((data->>'lastUpdated')::BIGINT) - TO_TIMESTAMP((commit_info->>'timestamp')::BIGINT)) AS lead_time_in_days,
                        (data->>'lastUpdated')::BIGINT AS story_last_updated,
                        (data->>'flowsourceTime')::BIGINT AS flowsource_time,
                        data->>'flowsourceTimeX' AS flowsource_timeX,
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} AS engine_execution_time
                    FROM {TEMP_TABLE} slds
                    CROSS JOIN LATERAL jsonb_array_elements(data->'commits') AS commit_info;
                    """,
            "jira": """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        data->>'id' AS id,
                        data->>'appid' AS appid,
                        data->>'projectKey' AS project_key,
                        data->>'key' AS issue_key,
                        data->>'status' AS status,
                        (data->>'lastUpdated')::BIGINT AS done_date,
                        (data->>'flowsourceTime')::BIGINT AS flowsource_time,
                        data->>'flowsourceTimeX' AS flowsource_timeX,
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    from {TEMP_TABLE};
                    """
          }

    @flowsource_exception_handler
    def execute_pipeline(self):

        engineExecutionTime = TimeUtils().get_current_time()

        main_table_name = f"{self.schema_name}.{self.MAIN_TABLE_NAME}"
        temp_table_name = f"temp_{self.tool_name}_{uuid.uuid4().hex}"
        self.logger.info(f"{self.tool_name}_ENGINE - Main Table id is {main_table_name} and staging table id is {temp_table_name}")

        # Creating all the queries
        INSERT_TO_MAIN_TABLE_QUERY = self.format_insert_query(self.INSERT_TO_MAIN_TABLE_FROM_TABLE_DICT[self.tool_name], main_table_name, engineExecutionTime, temp_table_name)
            
        scm_main_table = f"{self.schema_name}.{self.LEADTIME_MAIN_TABLE_NAME}"
        SCM_INSERT_TO_MAIN_TABLE_QUERY = self.format_insert_query(self.INSERT_TO_MAIN_TABLE_FROM_TABLE_DICT[self.tool_name+"_scm"], scm_main_table, engineExecutionTime, temp_table_name)
        self.logger.info(f"{self.tool_name}_ENGINE - Set data pipeline for {self.tool_name}")
        
        # Set the parameters to be executed in order
        parameters = [f"INSERT_TO_MAIN_TABLE_QUERY: {INSERT_TO_MAIN_TABLE_QUERY}",f"INSERT_TO_MAIN_TABLE_QUERY: {SCM_INSERT_TO_MAIN_TABLE_QUERY}"]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(temp_table_name,parameters)