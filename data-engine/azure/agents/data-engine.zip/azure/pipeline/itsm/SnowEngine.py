from IPipeline import IPipeline
from azure.AzureBaseEngine import AzureBaseEngine

class SnowEngine(AzureBaseEngine, IPipeline):
     
    def __init__(self, cloud_provider, tool_name, json_file_path):
        
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "itsm_incident_data"

        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                   INSERT INTO {MAIN_TABLE}
                    SELECT 
                        data->>'id' AS id,
                        data->>'appid' AS appid,
                        data->>'incidentNumber' AS incident_number,
                        data->>'deploymentId' AS deployment_id,
                        data->>'priority' AS priority,
                        (data->>'openedDateEpoch')::BIGINT AS opened_date,
                        (data->>'closedDateEpoch')::BIGINT AS closed_date,
                        (data->>'flowsourceTime')::BIGINT AS flowsource_time,
                        data->>'flowsourceTimeX' AS flowsource_timeX,
                        data->>'toolName' AS tool_name,
                        {ENGINE_EXECUTION_TIME} AS engine_execution_time,
                        data->>'state' AS incident_state
                    FROM {TEMP_TABLE}
                    WHERE data->>'appid' IS NOT NULL
                    AND data->>'incidentNumber' IS NOT NULL
                    AND data->>'priority' IN ('High', 'Critical');
                    """
          

    