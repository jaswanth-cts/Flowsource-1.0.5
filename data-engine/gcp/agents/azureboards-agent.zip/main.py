from AzureBoardsAgent import AzureBoardsAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def azureboards_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = AzureBoardsAgent(cloud_provider)
        agent.process()  # Calling the import AzureBoardsAgent process
        logging.info(f'AzureBoardsAgent executed successfully ...')
        return "AzureBoardsAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing AzureBoardsAgent agent: {str(e)}')
