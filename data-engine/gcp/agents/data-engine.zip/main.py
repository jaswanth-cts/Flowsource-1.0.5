import json
from cloudevents.http import CloudEvent
from DataEngine import DataEngine
import functions_framework
from utils.FlowsourceLogger import FlowsourceLogger


@functions_framework.cloud_event
def dataengine_gcs(cloud_event: CloudEvent) -> tuple:
    data = cloud_event.data

    json_file_path = data["name"]
    if json_file_path.endswith('.json'):
        try:
            first_part = json_file_path.split('/') #extract the name by '/'to fetch tool_name from json_file_path in gcs say JIRA-JiraAgent-Issue-1722427405059.json to JIRA
            tool_category = first_part[2].split('-')[0].lower()
            if tool_category == "catalog":
                tool_name = "system." + tool_category
            else:
                tool_name = tool_category + "." + first_part[2].split('-')[1].lower()
            logger = FlowsourceLogger(tool_name.split('.')[1])
            logger.info(f"tool_name is {tool_name}")
            engine = DataEngine('GCP',tool_name,json_file_path)
            
            #Process data engine
            engine.processDataEngine()
            response = {
                "statusCode": 200,
                "body": json.dumps(
                    {"message": "GCP Data Engine Processing completed."}
                ),
            }
        except Exception as e:
            logger.exception(f"FLOWSOURCE_ENGINE_EXCEPTION: Error Processing Data Engine {str(e)}")
            response = {
                "statusCode": 500,
                "body": json.dumps({"message": "Internal server error.", "error": str(e)}),
            }
        logger.info(f'Response: {response}')
        logger.flush()
        return response