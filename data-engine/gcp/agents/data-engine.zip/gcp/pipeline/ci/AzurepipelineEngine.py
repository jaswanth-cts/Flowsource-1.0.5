from gcp.GCPBaseEngine import GCPBaseEngine
from IPipeline import IPipeline

class AzurepipelineEngine(GCPBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "ci_prod_deployment_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE} (jobName STRING, pipelineExecutionId BIGINT, shortDescription STRING, buildNumber STRING, result STRING, buildTimestamp BIGINT, buildUrl STRING, appid STRING,flowsourceTime BIGINT, flowsourceTimeX STRING,categoryName STRING, toolName STRING,id STRING,batchID STRING);
        """
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        id,
                        appid,
                        jobName AS deployment_job,
                        shortDescription AS short_description, 
                        buildNumber AS build_number, 
                        result AS build_status,
                        buildTimestamp AS build_timestamp, 
                        buildUrl AS build_url,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX, 
                        toolname AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                        FROM {STAGING_TABLE};
                    """