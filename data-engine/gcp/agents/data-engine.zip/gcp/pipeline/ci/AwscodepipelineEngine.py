from gcp.GCPBaseEngine import GCPBaseEngine
from IPipeline import IPipeline

class AwscodepipelineEngine(GCPBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "ci_prod_deployment_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE} (deployment_job STRING, short_description STRING, build_number STRING, build_status STRING, build_timestamp BIGINT, build_url STRING, appid STRING,flowsourceTime BIGINT, flowsourceTimeX STRING,categoryName STRING, toolName STRING,id STRING,batchID STRING);
        """
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        id,
                        appid,
                        deployment_job AS deployment_job,
                        short_description AS short_description, 
                        build_number AS build_number, 
                        build_status AS build_status,
                        build_timestamp AS build_timestamp, 
                        build_url AS build_url,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX, 
                        toolname AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                        FROM {STAGING_TABLE};
                    """