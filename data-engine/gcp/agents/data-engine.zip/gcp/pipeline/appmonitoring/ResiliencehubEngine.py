from gcp.GCPBaseEngine import GCPBaseEngine
from IPipeline import IPipeline

class ResiliencehubEngine(GCPBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "apm_resilience_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE}(appName STRING, startTime BIGINT, endTime BIGINT,processRunDateTime BIGINT,assessmentStatus STRING, assessmentName STRING,complianceStatus STRING,driftStatus STRING,resiliencyScore STRING,appid STRING,flowsourceTime BIGINT, flowsourceTimeX STRING,categoryName STRING, toolName STRING,id STRING,batchID STRING);
        """
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT 
                        id,
                        appid,
                        assessmentName as assessment_name,
						startTime as assesment_start_time,
						resiliencyScore as resilience_score,
						complianceStatus as compliance_status,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {STAGING_TABLE};
                    """