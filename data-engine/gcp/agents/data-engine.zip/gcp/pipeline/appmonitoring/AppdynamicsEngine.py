from gcp.GCPBaseEngine import GCPBaseEngine
from IPipeline import IPipeline

class AppdynamicsEngine(GCPBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "apm_event_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE}(eventId STRING,eventTags ARRAY<STRING>,recoverTimeInSec BIGINT,eventTitle STRING,eventStatus STRING,eventOccurDate STRING,eventOccurDateEpoch BIGINT,monitorId BIGINT,monitorName STRING,priority STRING,monitorTags ARRAY<STRING>,monitorCreated BIGINT,appid STRING,environment STRING,resourceMonitor STRING,serviceName STRING,flowsourceTime BIGINT,flowsourceTimeX STRING,categoryName STRING,toolName STRING,id STRING,batchID STRING);
        """
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT 
                        id,
                        appid,
                        eventId AS event_id,
                        eventOccurDateEpoch AS event_date,
                        recoverTimeInSec AS recovery_time,
                        environment,
                        flowsourceTime AS flowsource_time,
                        flowsourceTimeX AS flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {STAGING_TABLE};
                    """