from utils.FlowsourceLogger import FlowsourceLogger
from utils.TimeUtils import TimeUtils
from gcp.GCPBaseEngine import GCPBaseEngine
import uuid
from IPipeline import IPipeline
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class JiraEngine(GCPBaseEngine, IPipeline):

    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "alm_changes_data"
        self.LEADTIME_MAIN_TABLE_NAME = "scm_leadtime_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE}(key STRING, projectKey STRING, lastUpdated BIGINT,status STRING, commits ARRAY<STRUCT<id STRING,timestamp BIGINT>>,updated STRING,appid STRING, flowsourceTime BIGINT, flowsourceTimeX STRING,categoryName STRING, toolName STRING,id STRING,batchID STRING);
        """
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = {
            "jira_scm": """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                    slds.id,
                    slds.appid,
                    slds.key AS story_id,
                    commit_info.id AS commit_id,
                    commit_info.timestamp AS commit_timestamp,
                    slds.lastUpdated AS story_last_updated,
                    DATE_DIFF(TIMESTAMP_SECONDS(slds.lastUpdated), TIMESTAMP_SECONDS(commit_info.timestamp), DAY) AS lead_time_in_days,
                    slds.flowsourceTime as flowsource_time,
                    slds.flowsourceTimeX as flowsource_timeX,
                    slds.toolName AS tool_name,
                    {ENGINE_EXECUTION_TIME} as engine_execution_time
                    from {STAGING_TABLE} slds CROSS JOIN UNNEST(commits) AS commit_info;
                    """,
            "jira": """
                    INSERT INTO {MAIN_TABLE}
                    SELECT
                        id,
                        appid,
                        projectKey as project_key,
                        key as issue_key,
                        status,
                        lastUpdated AS done_date,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                        from {STAGING_TABLE};
                        """,
        }

    @flowsource_exception_handler
    def execute_pipeline(self):
        logger = FlowsourceLogger(self.tool_name)
        main_table_name = f"{self.bigquery_dataset_fqdn}.{self.MAIN_TABLE_NAME}"
        staging_table_name = f"{self.bigquery_dataset_fqdn}.{self.MAIN_TABLE_NAME}_staging_{uuid.uuid4().hex}"
        logger.info(
            f"Main Table id is {main_table_name} and staging table id is {staging_table_name}"
        )

        # Creating all the queries
        engineExecutionTime = TimeUtils().get_current_time()

        # Create Staging table for all the tools
        CREATE_STAGING_TABLE_QUERY = self.CREATE_STAGING_TABLE_TEMP.format(
            STAGING_TABLE=staging_table_name
        )

        # Formatting inserting query for scm_leadtime
        scm_main_table = f"{self.bigquery_dataset_fqdn}.{self.LEADTIME_MAIN_TABLE_NAME}"
        SCM_INSERT_MAIN_TABLE_STAGING_QUERY = self.format_query(
            self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE[self.tool_name + "_scm"],
            scm_main_table,
            engineExecutionTime,
            staging_table_name,
        )

        INSERT_MAIN_TABLE_FROM_STAGING_QUERY = self.format_query(
            self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE[self.tool_name],
            main_table_name,
            engineExecutionTime,
            staging_table_name,
        )

        # Set the parameters to be executed in order
        parameters = [
            f"CREATE_AND_LOAD_JSON_INTO_STAGING: {CREATE_STAGING_TABLE_QUERY}",
            f"INSERT_TO_MAIN_TABLE_FROM_STAGING_TABLE_QUERY: {INSERT_MAIN_TABLE_FROM_STAGING_QUERY}",
            f"INSERT_TO_MAIN_TABLE_FROM_STAGING_TABLE_QUERY: {SCM_INSERT_MAIN_TABLE_STAGING_QUERY}",
        ]

        # Execute the queries based on the order of parameters passed
        self.processQuery(staging_table_name, parameters)
