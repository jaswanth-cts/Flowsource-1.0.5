from gcp.GCPBaseEngine import GCPBaseEngine
from IPipeline import IPipeline

class SnowEngine(GCPBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "itsm_incident_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE}(incidentNumber STRING,batchID STRING, openedAt STRING, deploymentId STRING, closedAt STRING, state STRING, priority STRING, pipelineType STRING, openedDateEpoch BIGINT, closedDateEpoch BIGINT, appid STRING, flowsourceTime BIGINT,flowsourceTimeX STRING,categoryName STRING,toolName STRING,id STRING);
        """
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT 
                        id,
                        appid,
                        incidentNumber as incident_number,
                        deploymentId as deployment_id,
                        priority,
                        openedDateEpoch as opened_date,
                        closedDateEpoch as closed_date,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time,
                        state as incident_state
                    FROM {STAGING_TABLE}
                    WHERE appid IS NOT NULL
                    AND incidentNumber IS NOT NULL
                    AND priority IN ('High', 'Critical');
                    """