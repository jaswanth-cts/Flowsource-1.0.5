from gcp.GCPBaseEngine import GCPBaseEngine
from IPipeline import IPipeline

class CheckmarxEngine(GCPBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "codequality_metrics_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE}(scanId STRING,projectId BIGINT,highSeverity BIGINT, mediumSeverity BIGINT, lowSeverity BIGINT, infoSeverity BIGINT,statisticsCalculationDate STRING,scanFinishedOn STRING,appid STRING,flowsourceTime BIGINT, flowsourceTimeX STRING,categoryName STRING, toolName STRING,id STRING,batchID STRING);
        """
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE = """
                    INSERT INTO {MAIN_TABLE}
                    SELECT 
                        id,
                        appid,
                        scanId as scan_id,
                        highSeverity as high_issues,
						mediumSeverity as medium_issues,
						lowSeverity as low_issues,
						infoSeverity as info_issues,
                        scanFinishedOn as scan_date,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM {STAGING_TABLE};
                    """