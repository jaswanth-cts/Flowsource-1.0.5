from utils.FlowsourceLogger import FlowsourceLogger
from utils.TimeUtils import TimeUtils
from gcp.GCPBaseEngine import GCPBaseEngine
import uuid
from IPipeline import IPipeline
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class CatalogEngine(GCPBaseEngine, IPipeline):

    def __init__(self, cloud_provider, tool_name, json_file_path):
        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)
        self.MAIN_TABLE_NAME = "catalog_data"

        self.CREATE_STAGING_TABLE_TEMP = """create table {STAGING_TABLE}(appid STRING, app_name STRING,annotations JSON,lob STRING,is_critical STRING);
        """
        self.MERGE_SQL_TEMPLATE = """MERGE INTO {MAIN_TABLE} as MAIN_TABLE 
                    USING (SELECT * FROM (
                            SELECT *, ROW_NUMBER() OVER (PARTITION BY appid ORDER BY appid) AS row_num FROM {STAGING_TABLE} WHERE appid IS NOT NULL
                        ) AS deduplicated_staging WHERE row_num = 1
                    ) AS STAGING_TABLE ON  MAIN_TABLE.appid = STAGING_TABLE.appid
                    WHEN MATCHED THEN UPDATE SET app_name = STAGING_TABLE.app_name, annotations = TO_JSON_STRING(STAGING_TABLE.annotations), lob = STAGING_TABLE.lob, is_critical = STAGING_TABLE.is_critical
                    WHEN NOT MATCHED AND STAGING_TABLE.appid is not null THEN INSERT VALUES (STAGING_TABLE.appid, STAGING_TABLE.app_name, TO_JSON_STRING(STAGING_TABLE.annotations), STAGING_TABLE.lob, STAGING_TABLE.is_critical, {ENGINE_EXECUTION_TIME});
                    """

    @flowsource_exception_handler
    def execute_pipeline(self):
        logger = FlowsourceLogger(self.tool_name)
        main_table_name = f"{self.bigquery_dataset_fqdn}.{self.MAIN_TABLE_NAME}"
        staging_table_name = f"{self.bigquery_dataset_fqdn}.{self.MAIN_TABLE_NAME}_staging_{uuid.uuid4().hex}"
        logger.info(
            f"Main Table id is {main_table_name} and staging table id is {staging_table_name}"
        )

        # Creating all the queries
        engineExecutionTime = TimeUtils().get_current_time()

        # Create Staging table for all the tools
        CREATE_STAGING_TABLE_QUERY = self.CREATE_STAGING_TABLE_TEMP.format(
            STAGING_TABLE=staging_table_name
        )

        # Formatting merge query
        MERGE_QUERY = self.MERGE_SQL_TEMPLATE.format(
            MAIN_TABLE=main_table_name,
            STAGING_TABLE=staging_table_name,
            ENGINE_EXECUTION_TIME=engineExecutionTime,
        )
        # Set the parameters to be executed in order
        parameters = [
            f"CREATE_AND_LOAD_JSON_INTO_STAGING: {CREATE_STAGING_TABLE_QUERY}",
            f"MERGE_QUERY: {MERGE_QUERY}",
        ]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(staging_table_name, parameters)
