import os
import uuid
from dal.DataAccessLayer import DataAccessLayer
from utils.FlowsourceLogger import FlowsourceLogger
from DeadLetterQueue import DeadLetterQueue
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
from utils.TimeUtils import TimeUtils

class GCPBaseEngine(object):
    @flowsource_exception_handler
    def __init__(self, cloud_provider,json_file_path, tool_name):
        self.cloud_provider = cloud_provider
        self.tool_name = tool_name
        self.logger = FlowsourceLogger(self.tool_name)
        self.json_file_path = json_file_path

        # Initialize variables used in Child class
        self.CREATE_STAGING_TABLE_TEMP =""
        self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE=""
        self.MAIN_TABLE_NAME = ""

        # Initialize dal layer
        dal = DataAccessLayer(self.cloud_provider, self.tool_name)
        self.database_access = dal.get_database_access()
        self.storage_access = dal.get_storage_access()

        # Retrieve Environment variables
        self.bigquery_project_id = os.environ["BIGQUERY_PROJECT_ID"] 
        self.bigquery_dataset_id = os.environ["DATABASE_NAME"]

        # Format Bigquery table FQDN  
        self.bigquery_dataset_fqdn = f"{self.bigquery_project_id}.{self.bigquery_dataset_id}"

    def processQuery(self, staging_table_name,parameters):
        # Execute commands based on the order provided
        try:
            for parm in parameters:
                commands = parm.split(": ")
                match commands[0]:
                    case "CREATE_AND_LOAD_JSON_INTO_STAGING": #Creating Staging Table and Inserting Json to the staging table
                        storage_name = os.environ["STORAGE_NAME"]
                        gcs_uri = f"gs://{storage_name}/{self.json_file_path}"
                        self.execute_query(commands[1])
                        self.database_access.load_json_data_to_staging_table(gcs_uri, staging_table_name)
                        self.logger.info(f"Successfully Staging table Created {staging_table_name} and json data inserted in bigquery in Bigquery!")
                    case "INSERT_TO_MAIN_TABLE_FROM_STAGING_TABLE_QUERY" | "MERGE_QUERY": 
                        #Insert data from staging table to main table and delete staging table and Merge Data from staging table to main table and delete staging table
                        query = commands[1]
                        self.execute_query(query)
                        self.logger.info(f"Successfully executed INSERT_TO_MAIN_TABLE_FROM_STAGING_TABLE_QUERY or MERGE_QUERY!")
                    case _:
                        raise ValueError(f'1102 - FLOWSOURCE_ENGINE_QUERY_ERROR:{commands[0]} Command not found')

        except Exception as e:
            self.logger.exception(f"1101 - FLOWSOURCE_ENGINE_QUERY_EXCEPTION: Failed to process processQuery {e}")
            raise e
        finally:
            self.database_access.delete_staging_table(staging_table_name)
            self.logger.info(f"Deleted staging table successfully from bigquery!")

    

    def execute_query(self, query):
        self.database_access.execute_query_in_bigquery(query)
    
    def copy_file_to_dlq(self, error_message):
        #If any Exception/Error occurred upload the failed JSON and Error Message in Storage by DeadLetterQueue
        self.logger.info(f"Processing DeadLetter Queue...")
        deadLetterDataProcessing = DeadLetterQueue(self.cloud_provider, self.tool_name, self.json_file_path, self.storage_access)
        deadLetterDataProcessing.upload_file_to_dlq(error_message)
        self.logger.info(f"Processed DeadLetter Queue...")

    def format_query(self, insert_to_main_table_query, main_table_name, engineExecutionTime, staging_table_name):
        insert_to_main_table_from_staging_table_query = insert_to_main_table_query.format(
                    MAIN_TABLE=main_table_name,
                    ENGINE_EXECUTION_TIME=engineExecutionTime,
                    STAGING_TABLE=staging_table_name
                    )
        return insert_to_main_table_from_staging_table_query
    
    @flowsource_exception_handler
    def execute_pipeline(self):
        # Check whether all the required values are provided in the child class
        self.do_health_checks()

        #Create and Format Query for all the tools
        main_table_name = f"{self.bigquery_dataset_fqdn}.{self.MAIN_TABLE_NAME}"
        staging_table_name = f"{self.bigquery_dataset_fqdn}.{self.MAIN_TABLE_NAME}_staging_{uuid.uuid4().hex}"
        self.logger.info(f"Main Table id is {main_table_name} and staging table id is {staging_table_name}")

        engineExecutionTime = TimeUtils().get_current_time()

        #Create Staging table
        CREATE_STAGING_TABLE_QUERY = self.CREATE_STAGING_TABLE_TEMP.format(
                STAGING_TABLE=staging_table_name
            )
        
        #Insert into main table for all the tools
        INSERT_MAIN_TABLE_FROM_STAGING_QUERY = self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE.format(
                MAIN_TABLE=main_table_name,
                ENGINE_EXECUTION_TIME=engineExecutionTime,
                STAGING_TABLE=staging_table_name
            )
    
        # Set the parameters to be executed in order
        parameters = [f"CREATE_AND_LOAD_JSON_INTO_STAGING: {CREATE_STAGING_TABLE_QUERY}",f"INSERT_TO_MAIN_TABLE_FROM_STAGING_TABLE_QUERY: {INSERT_MAIN_TABLE_FROM_STAGING_QUERY}"]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(staging_table_name, parameters)

    def do_health_checks(self):
        if self.MAIN_TABLE_NAME == '':
            self.logger.error('1001 - FLOWSOURCE_BASEENGINE_ERROR: MAIN_TABLE_NAME should not be empty')
            raise ValueError('1001 - FLOWSOURCE_BASEENGINE_ERROR: MAIN_TABLE_NAME should not be empty')
        elif self.CREATE_STAGING_TABLE_TEMP == '':
            self.logger.error('1005 - FLOWSOURCE_BASEENGINE_ERROR: CREATE_STAGING_TABLE_TEMP should not be empty')
            raise ValueError('1005 - FLOWSOURCE_BASEENGINE_ERROR: CREATE_STAGING_TABLE_TEMP should not be empty')
        elif self.INSERT_TO_MAIN_TABLE_FROM_TEMP_TABLE == '':
            self.logger.error('1004 - FLOWSOURCE_BASEENGINE_ERROR: INSERT_TO_MAIN_TABLE_FROM_TABLE_TEMP should not be empty')
            raise ValueError('1004 - FLOWSOURCE_BASEENGINE_ERROR: INSERT_TO_MAIN_TABLE_FROM_TABLE_TEMP should not be empty')
        else:
            self.logger.info("All required values are provided")