from BlackduckAgent import BlackduckAgent
import functions_framework
import logging

# HTTP-triggered function
@functions_framework.http
def blackduck_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = BlackduckAgent(cloud_provider)
        agent.process()  # Calling the BlackduckAgent process
        logging.info(f'Blackduck Agent executed successfully ...')
        return "BlackduckAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Blackduck Agent: {str(e)}')