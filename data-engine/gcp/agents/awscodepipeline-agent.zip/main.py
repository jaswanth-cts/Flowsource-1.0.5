from AwsCodePipelineAgent import AwsCodePipelineAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def awscodepipeline_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = AwsCodePipelineAgent(cloud_provider)
        agent.process()  # Calling the import AwsCodePipelineAgent process
        logging.info(f'AwsCodePipelineAgent executed successfully ...')
        return "AwsCodePipelineAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing AwsCodePipeline agent: {str(e)}')
