from datetime import datetime
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class DatadogAgent(BaseAgent):

    @flowsource_exception_handler
    def process(self):
        self.logger.info('FLOWSOURCE_INFO: Inside DatadogAgent process func...')

        # Load configurations and initialize
        self.load_configurations()
        
        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)
    
        # Process tool data based on catalog data
        self.process_tool_data()


    def load_configurations(self):
        # Common- Retrieve configurations from config.json
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get("batchSize", 1000)
        self.batchCollectDays = self.config.get("batchCollectDays", 30)
        
        # Agent specific- Get required monitors tags from config file
        self.responseTemplate = self.getResponseTemplate()
        self.requiredMonitorTags = self.config.get(
            'dynamicTemplate', {}).get('monitorMetaData', {}).get("tags", [])

        # Adding timestamp in startFromDate
        if len(self.startFromDate) == 10:
            self.startFromDate = self.startFromDate + " 00:00:00"
        
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        
    def process_tool_data(self):
        self.logger.info('FLOWSOURCE_INFO: Inside process_tool_data func ...')

        # To create authorization header
        self.perform_authorization()
        
        for catalog in self.catalogData:
            appid = catalog[0]
            self.process_monitors(appid)


    def perform_authorization(self):
        # Getting datadog credentials from credential manager & implementing auth header
        self.api_Key = self.config.get(self.cloud_provider, '').get("apiKey", '')
        self.application_Key = self.config.get(self.cloud_provider, '').get("applicationKey", '')
        self.apiKey = self.keyValues[self.api_Key]
        self.applicationKey = self.keyValues[self.application_Key]
        self.json_headers = {"DD-API-KEY": self.apiKey, "DD-APPLICATION-KEY": self.applicationKey,
                             "Content-Type": "application/json", "Accept": "application/json"}
        
        
    def process_monitors(self, appid):
        startTimeEpoch, endTimeEpoch = self.get_tracking_last_update(appid)

        # Get monitor response template from config file
        monitorDataTemplate = self.responseTemplate.get('monitorDataTemplate', {})

        # Constructing all required monitors tags
        requiredTags = self.requiredMonitorTags.copy()
        requiredTags.append("appid:"+ appid)
        monitorTags = " AND ".join(requiredTags)

        # Constructing API to get all monitors associated with required tags
        monitorsUrl = self.baseUrl + \
            '/api/v1/monitor/search?query=tag:(' + monitorTags + ')'
        monitorsResponse = self.getResponse(
            monitorsUrl, 'GET', None, None, None, reqHeaders=self.json_headers)
        monitors = monitorsResponse['monitors']
        monitorsToProcess = []

        # Extracting required properties from monitor
        for monitor in monitors:
            injectData = {
                "monitorTags": monitor.get("tags", "")
            }
            # Adding required tags as a monitor property
            for requiredTag in injectData['monitorTags']:
                injectData.update(
                    {requiredTag.split(":")[0]: requiredTag.split(":")[1]})

            monitorObj = self.parseResponse(monitorDataTemplate, monitor, injectData)
            monitorsToProcess.append(monitorObj[0])
        if monitorsToProcess != []:
            for monitor in monitorsToProcess:
                # To process monitor's releated events
                self.process_events(monitor, startTimeEpoch, endTimeEpoch, appid)
        else:
            self.logger.info(f"FLOWSOURCE_INFO: No monitors found for appid- {appid}")


    def process_events(self, monitor, startTimeEpoch, endTimeEpoch, appid):
        self.logger.info('FLOWSOURCE_INFO: Inside processeEventsData func...')
        allEvents = []
        
        if endTimeEpoch > startTimeEpoch:
            # Constructing API to get all events associated with a monitor in specified time line (startTime is inclusive whereas endTime is exclusive)
            eventsUrl = self.baseUrl + '/api/v2/events?&filter[query]=@monitor_id:' + str(
                monitor["monitorId"]) + '&filter[from]=' + str(startTimeEpoch *1000) + '&filter[to]=' + str(endTimeEpoch *1000) + "&sort=timestamp&page[limit]=1000"

            fetchNextPage = True
            while fetchNextPage:
                eventsResponse = self.getResponse(
                    eventsUrl, 'GET', None, None, None, reqHeaders=self.json_headers)

                if (len(eventsResponse["data"]) != 0):
                    for event in eventsResponse["data"]:
                        eventAttributes = {}
                        eventAttributes = event.get(
                            "attributes", {}).get("attributes", {})

                        # Extracting required properties from monitor's event
                        # Response template not works for nested json obj properties
                        if (eventAttributes and event.get("attributes", {}).get("tags", None)):
                            data = {
                                "eventId": eventAttributes.get("evt", "").get("id", ""),
                                "eventTags": event.get("attributes", {}).get("tags", []),
                                "recoverTimeInSec": "" if not eventAttributes.get("duration", None) else eventAttributes.get("duration", "")//1000000000,
                                "eventTitle": eventAttributes.get("title", ""),
                                "eventStatus": eventAttributes.get("status", ""),
                                "recoveredEventOccurEpoch": "" if not eventAttributes.get("timestamp", None) else eventAttributes.get("timestamp", "")//1000
                            }
                            # Adding only those monitor events which contains recoverTime property
                            if data['recoveredEventOccurEpoch'] != "" and data['recoverTimeInSec'] != "":
                                data['eventOccurDateEpoch'] = int(data['recoveredEventOccurEpoch']) - int(data['recoverTimeInSec'])
                                data.update(monitor)
                                allEvents.append(data)
                                # Update endtTimeEpoch as lastUpdated for an appid in tracking file
                                self.update_tracking_data(endTimeEpoch, appid)
                                # Publish datadog monitor event data
                                self.publishData(allEvents,fileType="Event",batchSize=self.batchSize,is_residual=False,tracking=self.tracking)
                            else:
                                continue

                    if (len(eventsResponse["data"]) < 1000) or (not (eventsResponse.get("links", {}).get("next", None))):
                        fetchNextPage = False
                        break
                    else:
                        eventsUrl = eventsResponse.get("links", {}).get("next", "")
                else:
                    self.logger.info(f"4001 - FLOWSOURCE_INFO: No events found for appid- {appid}, monitorId- {monitor['monitorId']} between {startTimeEpoch} - {endTimeEpoch} timeframe.")
                    # Updating endTimeEpoch as lastupdated in tracking file for an appid
                    self.tracking[appid] = {'lastupdated' : endTimeEpoch}
                    self.updateTrackingFile(self.tracking)
                    fetchNextPage = False
                    break

            if (len(allEvents) > 0):
                # Publish residual datadog monitor event data
                self.publishData(allEvents,fileType="Event",batchSize=self.batchSize,is_residual=True,tracking=self.tracking)
        else:
            self.logger.error(f"FLOWSOURCE_ERROR: Might be there is duplicate appids- {appid} in catalogdata")


    def update_tracking_data(self, endTimeEpoch, appid):
        self.tracking[appid] = {'lastupdated' : endTimeEpoch}

    
    def get_tracking_last_update(self, appid):
        # Converting env startFromDate into startDateEpoch
        startDateEpoch = int(datetime.strptime(self.startFromDate, '%Y-%m-%d %H:%M:%S').timestamp()) 

        # If last updated epoch is not present in tracking file take startDateEpoch
        startDateTime = self.tracking.get(appid, {}).get('lastupdated', startDateEpoch) 

        endDateTime = self.getEndTime(startDateTime,self.batchCollectDays,timeFormat='%Y-%m-%d %H:%M:%S',type='epoch')
         
        return startDateTime, endDateTime
