import functions_framework
import logging
from DatadogAgent import DatadogAgent

@functions_framework.http
def datadog_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = DatadogAgent(cloud_provider)
        agent.process() 
        return "Datadog Agent Execution Completed Successfully ..."

    except Exception as e:
            logging.error(f'Error while processing datadog agent {str(e)}')
