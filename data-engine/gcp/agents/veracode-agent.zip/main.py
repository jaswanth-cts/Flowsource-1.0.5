from VeracodeAgent import VeracodeAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def veracode_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = VeracodeAgent(cloud_provider)
        agent.process()  # Calling the import VeracodeAgent process
        logging.info(f'Veracode executed successfully ...')
        return "VeracodeAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Veracode agent: {str(e)}')
