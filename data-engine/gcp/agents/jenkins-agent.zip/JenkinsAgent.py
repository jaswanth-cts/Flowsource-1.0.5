from time import mktime
from dateutil import parser
from datetime import datetime
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class JenkinsAgent(BaseAgent):  
        
    @flowsource_exception_handler    
    def process(self):
        self.logger.info('Inside JenkinsAgent process ...')

        # Load configurations and initialize
        self.load_configurations()

        # Fetch catalog data 
        self.catalogData = self.fetchCatalogData(self.select_query)

         # Process and publish tool data and update tracking file
        self.process_tool_data()

    
    
    def load_configurations(self):
        #load common agent config var
        #Retrieve the query to fetch catalog Data as per the cloud Provider 
        self.select_query= self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        # Set batch size for publishing
        self.batchSize = self.config.get('batchSize', 1000);
        #agent specific var
        #Retrieve configurations from config.json 
        self.jenkinsId = self.config.get(self.cloud_provider, '').get("jenkinsId", '')
        self.jenkinsPs = self.config.get(self.cloud_provider, '').get("jenkinsPs", '')
        
        # Fetch configurations(url,boolean values) from Config File 
        self.useAllBuildsApi = self.config.get("useAllBuildsApi", False)
        self.responseTemplate = self.getResponseTemplate()
        self.treeApiParams = self.buildApiParameters('', self.responseTemplate)

        #Add the hrs:mins:secs if the startFromDate has only date
        if len(self.startFromDate) == 10:  
            self.startFromDate += " 00:00:00"
        self.startFrom = (
            int(datetime.strptime(self.startFromDate,
                "%Y-%m-%d %H:%M:%S").timestamp()) * 1000
        )
         
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000


    def process_tool_data(self):
        # Get Jenkins credentials
        self.userid = self.keyValues[self.jenkinsId]
        self.cred = self.keyValues[self.jenkinsPs]
        
        #Process The Jobs in the CatalogData
        for catalog in self.catalogData:
            #Get the JobName and AppId
            jobName = catalog[1]
            appid = catalog[0]
            self.process_job(jobName, appid)

    # Method to process JOB
    def process_job(self, jobName, appid):
        self.logger.info("Fetching the jekins jobs For Production ...")

        # Initialize data list and set the Initial temporary Values
        self.dataObjects = []   #list to store the jobs to be published

        #Get the boolean value which is set in Load Config and get the Builds ApiName accordingly
        self.buildsApiName = "builds"
        if self.useAllBuildsApi:
            self.buildsApiName = "allBuilds"

        #Split the Job to get the proper url
        splitJobName = jobName.split("/")
        jobUrl = ""
        url = self.baseUrl

        #Append the job between each Splitted JobName
        for splitJob in splitJobName:
            jobUrl = jobUrl + 'job/' + splitJob + '/'
            
        #Fetch the Proper restUrl and get the response 
        restUrl = url + jobUrl + 'api/json'
        urlJob = url + jobUrl
        try:
            job = self.getResponse(
                    restUrl, 'GET', self.userid, self.cred, None)
        except Exception as e:
            if "404" in str(e):
                # If the Job Url is not accessable by the user break move to next Job
                self.logger.error(
                        "Flowsource_Jenkins_Agent_Exception: Job Url not found : " +"\n"+ str(e)
                )
                self.logger.info("Jenkins Agent , Proceeding to next Job...")
            else:
                raise e
        lastBuild = job.get('lastBuild', None)

        #Get the Job Details
        if lastBuild:
            jobName = job.get('name', None)
            self.logger.info('Processing job - {}'.format(jobName))
            lastBuildNumber = lastBuild.get('number', None)
            if lastBuildNumber:
                self.get_job_details(urlJob, lastBuildNumber, jobName, appid)

    def get_job_details(self, url, lastBuild, jobName, appid):
        self.logger.info('Fetching {} details ...'.format(jobName))
        #Set variables to Process and Publish the Jobs
        tillJobCount = 0
        injectData = {}
        injectData['jobName'] = jobName
        self.allBuilds=[]
        # Get Tracking details for specific URL
        # Check if there is a last build number for the given appid in the tracking data
        if self.tracking.get(appid, {}).get("lastBuildNumber"):
            # Get the count of jobs to process based on the last build number
            tillJobCount = self.get_tracking_last_update(appid, lastBuild)
            # If there are jobs to process, call the method to process build executions
            if tillJobCount > 0:
                self.get_all_build_details(url, tillJobCount, injectData, appid)
        else:
            # If there is no last build number, process build executions from the startFrom date
            self.get_all_build_details(url, tillJobCount, injectData, appid)

    def get_all_build_details(self, url, tillJobCount, injectData, appid):
        self.logger.info('Inside get_all_build_details ...')

        # Initialize variables
        start = 0
        buildsIdentified = True
        self.apibatchSize = 100

        while buildsIdentified:
            # Calculate the end for the current batch
            end = start + self.apibatchSize
            if tillJobCount > 0 and end > tillJobCount:
                end = tillJobCount

            # Construct the API URL
            restUrl = (
                f"{url}api/json?tree={self.buildsApiName}"
                f"{self.treeApiParams}{{{start},{end}}},name"
            )

            # Fetch builds via API
            try:
                jobDetails = self.getResponse(restUrl, 'GET', self.userid, self.cred, None)
            except Exception as e:
                self.logger.error(f"Error fetching job details: {e}")
                raise

            builds = jobDetails[self.buildsApiName]

            # Process builds in the current batch
            for build in builds:
                # Handle the `startFrom` condition for first-time processing
                if tillJobCount == 0 and self.startFrom is not None:
                    if build["timestamp"] < self.startFrom:
                        buildsIdentified = False
                        break

                # Skip builds with duration <= 0
                if build["duration"] <= 0:
                    continue

                # Add the build to the list for processing
                self.allBuilds.append(build)

            # Handle loop termination conditions
            if tillJobCount > 0 and (start >= tillJobCount or len(builds) < self.apibatchSize):
                buildsIdentified = False
            elif len(builds) < self.apibatchSize or (len(builds) == 0 and tillJobCount == 0):
                buildsIdentified = False

            # Increment start for the next batch
            if buildsIdentified:
                start += self.apibatchSize

        # Extract and publish build details
        if self.allBuilds:
            self.extract_build_details(self.allBuilds, injectData, appid, url)     

    def extract_build_details(self, allBuilds, injectData, appid, url):
        #Get the Build Details and add it to the Data Objects to publish it
        buildDetails = self.parseResponse(
            self.responseTemplate, allBuilds, injectData)
        for jsonObj in reversed(buildDetails):
            #Update the Tracking File with the highest build Id
            self.update_tracking_data(appid, url, jsonObj["number"])
            
            # Filter and publish only successful builds
            if jsonObj.get('result') == 'SUCCESS':
                jsonObj["fullDisplayName"] = jsonObj["fullDisplayName"].replace(
                    "»", "/").replace(" ", "").split("#")[0]
                if (appid != None):
                    jsonObj['appid'] = appid
                self.dataObjects.append(jsonObj)
                
                #Publish Data Objects to Storage
                self.publishData(self.dataObjects, 'Job', batchSize=self.batchSize, is_residual=False,
                    tracking=self.tracking)
                
        #Publish Residual Data
        if len(self.dataObjects)>0:
            self.publishData(self.dataObjects,'Job', batchSize=self.batchSize, is_residual=True,
                tracking=self.tracking)
            
        # If there are no data objects, update the tracking file to the latest build number
        if not self.dataObjects:
            self.updateTrackingFile(self.tracking)

    def update_tracking_data(self, appid, buildUrl, lastBuildNumber):
        self.logger.info('Updating the tracking details ...')
        currentTracking = self.tracking.get(
            appid, None)
        if currentTracking is None:
            currentTracking = {}
            self.tracking[appid] = currentTracking
        currentTracking["buildUrl"] = buildUrl
        currentTracking["lastBuildNumber"] = lastBuildNumber
        self.tracking[appid] = currentTracking

     # Method to get the tracking details for appId
    def get_tracking_last_update(self, appid, lastBuild):
        trackingNum = self.tracking.get(appid).get("lastBuildNumber")
        tillJobCount = lastBuild - int(trackingNum)
        return tillJobCount