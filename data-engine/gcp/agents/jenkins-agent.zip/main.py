from JenkinsAgent import JenkinsAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def jenkins_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = JenkinsAgent(cloud_provider)
        agent.process()  # Calling the JenkinsAgent process
        logging.info(f'Jenkins agent executed successfully ...')
        return "JenkinsAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Jenkins agent: {str(e)}')
