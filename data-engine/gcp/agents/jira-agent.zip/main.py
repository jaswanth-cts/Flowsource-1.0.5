from JiraAgent import Jira_Agent
import functions_framework
import logging
 
#HTTP-triggered function
@functions_framework.http
def jira_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = Jira_Agent(cloud_provider)
        agent.process()  # Calling the JiraAgent process
        logging.info(f'Jira agent executed successfully ...')
        return "JiraAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Jira agent: {str(e)}')