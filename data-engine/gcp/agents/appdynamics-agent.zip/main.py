from AppDynamicsAgent import AppDynamicsAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def appdynamics_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = AppDynamicsAgent(cloud_provider)
        agent.process()
        logging.info(f'AppDynamicsAgent executed successfully ...')
        return "AppDynamicsAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing AppDynamics agent: {str(e)}')
