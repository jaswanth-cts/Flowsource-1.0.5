from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
import base64
import datetime


class AppDynamicsAgent(BaseAgent):
    @flowsource_exception_handler
    def process(self):

        self.logger.info('FLOWSOURCE_INFO: Inside AppDynamicsAgent process func...')

        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process tool data based on catalog data
        self.process_tool_data()

    def load_configuration(self):

        # Common- Retrieve configurations from config.json
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get("batchSize", 1000)

        # Agent specific- variables
        self.responseTemplate = self.getResponseTemplate()
        self.appDynamicsClientId = self.config.get(self.cloud_provider, "").get("appDynamicsClientId", "")      
        self.appDynamicsPrivateKey = self.config.get(self.cloud_provider, "").get("appDynamicsPrivateKey", "")

        # Common- Adding timestamp in startFromDate
        if len(self.startFromDate) == 10:
            self.configStartDate = self.startFromDate + " 00:00:00"
        
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000
            
        # Collect the number of days data to process   
        self.batchCollectDays = self.config.get("batchCollectDays", 30)    

    def process_tool_data(self):
        self.logger.info('FLOWSOURCE_INFO: Inside process_tool_data func ...')
         
        # To create authorization header
        self.perform_authorization()

        self.allEvents = []
        for catalog in self.catalogData:
            
                appId= catalog[0]
                appName=catalog[1]
                # call problem api to fetch all policy violations 
                self.process_problems(appId,appName)
            
            
  
    def perform_authorization(self):
                
        # Get AppDynamics credentials from credential manager  & implementing auth header
        clientId = self.keyValues.get(self.appDynamicsClientId, '')
        privateKey = base64.b64decode(self.keyValues.get(self.appDynamicsPrivateKey, '')).decode("utf-8")

        # Generate API token with client id and privatekey
        appDynamicsApitoken = self.get_access_token(clientId,privateKey)

        # Set the Headers for the Api call for Problems
        self.json_headers = {
            "Authorization": f"Bearer " + appDynamicsApitoken,
            "Content-Type": "application/json",
        }

              
    def process_problems(self,appId,appName):

        # Get start and end date time 
        startTimeEpoch, endTimeEpoch  = self.get_tracking_last_update(appId,appName)
        if endTimeEpoch > startTimeEpoch:  
                   
            # Constructing API to get all problems associated in specified time line          
            problemUrl=(self.baseUrl
                    +"/controller/rest/applications/"
                    +appName
                    +"/problems/healthrule-violations?time-range-type=BETWEEN_TIMES"
                    +"&start-time="
                    +str(startTimeEpoch*1000)
                    +"&end-time="
                    +str(endTimeEpoch*1000)
                    +"&output=json")

            try:    
                problemResponse = self.getResponse(problemUrl, "GET", None, None, None, reqHeaders=self.json_headers) 
            except Exception as e:
                    if "error 400" in str(e):
                        # If the application is not available break, move to next application
                        self.logger.exception(
                            "FLOWSOURCE_APPDYNAMICS_AGENT_ERROR: Unable to reach application : " + appId +"\n"+ str(e)
                        )
                        return
                    else:
                       raise e       
            # Process only the resolved_incidents  

            resolvedIncidents = [violation for violation in problemResponse if violation['incidentStatus'] == 'RESOLVED'] 

            if len(problemResponse)>0 and resolvedIncidents:
                    if resolvedIncidents:
                        for policyViolation in resolvedIncidents:                    
                                startTime = policyViolation["startTimeInMillis"]
                                endTime = policyViolation["endTimeInMillis"]
                                recoveryTime = endTime - startTime
                                data = {
                                "appid":appId ,
                                "recoverTimeInSec": recoveryTime // 1000,
                                "eventOccurDateEpoch": startTime // 1000,
                                "recoveredEventOccurEpoch": endTime//1000,
                                "environment": "PROD"                      
                                }
                                problemData = self.parseResponse(self.responseTemplate, policyViolation, data)
                                self.allEvents.append(problemData[0])

                                # Update tracking data with last eventOccurDate
                                self.update_tracking_data(endTimeEpoch, appId,appName)

                                # Publish appdynamics problem data
                                self.publishData(
                                self.allEvents,
                                 fileType="Event",
                                 batchSize=self.batchSize,
                                 is_residual=False,
                                 tracking=self.tracking,
                                )
            else:          
                        # Update tracking time to current time if there are no problems in the response
                        self.logger.error(f"4001 - FLOWSOURCE_ERROR: No Problems for appids- {appId}")
                        self.tracking[appId]= {'lastupdated'+'_'+appName : endTimeEpoch}
                        self.updateTrackingFile(self.tracking)

        # publish residual data if any                
        if len(self.allEvents) > 0:
            # Publish AppDynamics problem data
            self.publishData(
                self.allEvents,
                fileType="Event",
                batchSize=self.batchSize,
                is_residual=True,
                tracking=self.tracking,
            )

    def update_tracking_data(self, endTimeEpoch,appId,appName):
        self.tracking[appId] = {'lastupdated'+'_'+appName : endTimeEpoch}
    
    def get_access_token(self, client_id, client_secret):
        # Generate API Token
        self.logger.info("Generate API Token using client id and private key")
        access_token_url = self.baseUrl + "/controller/api/oauth/access_token"
        
        headers = {
        "Content-Type": "application/x-www-form-urlencoded"
         }
        data = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
         }
        access_token_response = self.getResponse(access_token_url, 'POST', None, None, data=data, reqHeaders=headers)
        access_token = access_token_response.get('access_token')
        return access_token
    
     
    def get_tracking_last_update(self, appId,appName):

        # Convert configStartDate to Epoch format
        startDateEpoch = int(datetime.datetime.strptime(self.configStartDate, '%Y-%m-%d %H:%M:%S').timestamp())		
		
        # fetch the startDate either from config.json or tracking file	
        startTime = self.tracking.get(appId, {}).get('lastupdated'+'_'+appName, startDateEpoch)
       
        endTime = self.getEndTime(startTime,self.batchCollectDays,timeFormat= '%Y-%m-%d %H:%M:%S',type='epoch')
        
        return startTime, endTime
    
    