from CheckmarxAgent import CheckmarxAgent
import functions_framework
import logging
 
#HTTP-triggered function
@functions_framework.http
def checkmarx_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = CheckmarxAgent(cloud_provider)
        agent.process()  # Calling the CheckmarxAgent process
        logging.info(f'Checkmarx agent executed successfully ...')
        return "CheckmarxAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Checkmarx agent: {str(e)}')