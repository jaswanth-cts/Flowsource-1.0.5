from dateutil import parser
from datetime import datetime
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class CheckmarxAgent(BaseAgent):

    @flowsource_exception_handler
    def process(self):
        self.logger.info("Inside Checkmarx Agent process")

        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process projects and scans
        self.process_tool_data()

    def load_configuration(self):

        # load common agent config var
        self.dynamicTemplate = self.config.get("dynamicTemplate", {})
        self.select_query = self.config.get(self.cloud_provider, "").get(
            "catalogDataSelectQuery", ""
        )
        self.batchSize = self.config.get("batchSize", 1000)
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        # agent specific var
        # Fetching configurations
        self.clientId = self.config.get(self.cloud_provider, "").get("clientId", "")
        self.clientToken = self.config.get(self.cloud_provider, "").get(
            "clientToken", ""
        )
        self.userName = self.config.get(self.cloud_provider, "").get("userName", "")
        self.userToken = self.config.get(self.cloud_provider, "").get("userToken", "")

    # Process Checkmarx Details - Projects, Scans and ScanIssues
    def process_tool_data(self):
        self.logger.info("FLOWSOURCE_INFO: Inside process_tool_data func ...")

        # authorize and get access token
        self.access_token = self.perform_authorization()

        # Initialize scanData list and ResponseTemplate from dynamicTemplate in config.json
        self.scanData = []
        self.scanResponseTemplate = self.dynamicTemplate.get("scanResponseTemplate", {})

        # Get appId(catalog[0]) and projectId(catalog[1]) to process
        for catalog in self.catalogData:
            self.process_scan_details(catalog[0], catalog[1])

    def process_scan_details(self, appid, proj_name):
        project = self.get_project_details(proj_name)

        # check if project is invalid 
        if not project:
            return

        project_id = project.get("id", "")
        project_name = project.get("name", "")

        scanId = ""
        if project_id and project_name:
            projectTracking = self.tracking.get(appid, {})
            tracking_last_scan_id = projectTracking.get("lastScanID", None)
            # Get All Scans Details
            all_scans = self.get_all_scans(project_id, tracking_last_scan_id)
            if all_scans:
                # processing scans in a reverse order so that will get the non-latest scans in the top of the stack
                for scan in reversed(all_scans):
                    scanId = str(scan.get("id", ""))
                    scanFinishedOn = (
                        scan.get("dateAndTime", {}).get("finishedOn", "").split(".")[0]
                    )
                    injectData = {
                        "appid": appid,
                        "scanId": scanId,
                        "projectId": project_id,
                        "projectName": project_name,
                        "scanFinishedOn": scanFinishedOn,
                    }
                    # Get ScanIssues based on scanId
                    issues = self.get_scan_issues(scanId)

                    if issues:
                        # issues['appid'] = appid
                        self.scanData += self.parseResponse(
                            self.scanResponseTemplate, issues, injectData
                        )
                        self.update_tracking_data(appid, scanId, project_id)
                        self.publishData(
                            self.scanData,
                            fileType="Scan",
                            batchSize=self.batchSize,
                            is_residual=False,
                            tracking=self.tracking,
                        )
        else:
            self.logger.info("Project id or name is null")

        if len(self.scanData) > 0:
            # Publish remaining issue data
            self.publishData(
                self.scanData,
                fileType="Scan",
                batchSize=self.batchSize,
                is_residual=True,
                tracking=self.tracking,
            )

    def update_tracking_data(self, appId, scanId, project_id):

        # update tracking with scanId
        projectTracking = self.tracking.get(appId, {})
        projectTracking["lastScanID"] = str(scanId)
        projectTracking["projectId"] = str(project_id)
        self.tracking[appId] = projectTracking

    def get_scan_issues(self, scan_id):
        self.logger.info("Fetching the scan issues ...")
        issues_url = (
            self.baseUrl + f"/cxrestapi/help/sast/scans/{scan_id}/resultsStatistics"
        )
        headers = {"Authorization": f"Bearer {self.access_token}"}
        response = self.getResponse(
            issues_url, "GET", None, None, None, reqHeaders=headers
        )
        return response

    # Get Scan Data
    def get_all_scans(self, project_id, tracking_last_scan_id):
        self.logger.info("Fetching the scan for the project ...")
        scans_url = self.baseUrl + f"/cxrestapi/help/sast/scans?projectId={project_id}"

        headers = {"Authorization": "Bearer " + self.access_token}
        scans = None
        scans = self.getResponse(scans_url, "GET", None, None, None, reqHeaders=headers)
        scanData = []
        if scans:
            if not tracking_last_scan_id:
                startFromStr = self.startFromDate
                startFrom = parser.parse(startFromStr, ignoretz=True)
            else:
                startFrom = None
                # Get the last N new scans by using the last_scan_id index which tracked and fetched earlier
                scan_array = [
                    scan
                    for scan in scans
                    if str(scan.get("id")) > tracking_last_scan_id
                ]
                scans = scan_array

            for index in range(0, len(scans)):
                scan = scans[index]
                if scan["dateAndTime"] and scan["dateAndTime"]["finishedOn"]:
                    scan_date = scan["dateAndTime"]["finishedOn"].split(".")[0]
                    last_scan_date = datetime.strptime(scan_date, "%Y-%m-%dT%H:%M:%S")
                    if startFrom and startFrom > last_scan_date:
                        break
                    scanData.append(scan)

        return scanData

    def get_project_details(self, projectName):

        self.logger.info("Fetching the project details ...")
        projUrl = (
            self.baseUrl
            + "/cxrestapi/help/projects?projectName="
            + projectName
            + "&showAlsoDeletedProjects=false"
        )
        headers = {"Authorization": "Bearer " + self.access_token}
        response = None

        try:
            response = response = self.getResponse(
                projUrl, "GET", None, None, None, reqHeaders=headers
            )
        except Exception as e:
            if "404" in str(e):
                self.logger.error(
                    f"FLOWSOURCE_ERROR: Unable to reach project : "
                    + projectName
                    + "\n"
                    + str(e)
                )
                return
            else:
                raise e

        if len(response) == 1:
            return {"id": response[0].get("id"), "name": response[0].get("name")}

    def perform_authorization(self):
        self.logger.info("Fetching the token ...")

        # Get Checkmarx credentials from credential manager
        self.clientId = self.keyValues[self.clientId]
        self.clientToken = self.keyValues[self.clientToken]
        self.userName = self.keyValues[self.userName]
        self.userToken = self.keyValues[self.userToken]

        authUrl = self.baseUrl + "/CxRestAPI/auth/identity/connect/token"
        payload = {
            "client_id": self.clientId,
            "client_secret": self.clientToken,
            "grant_type": "password",
            "username": self.userName,
            "password": self.userToken,
        }
        response = None
        response = self.getResponse(authUrl, "POST", None, None, payload)
        access_token = response.get("access_token", "")
        if access_token is None:
            self.logger.info("4003 - FLOWSOURCE_ERROR: No access token received")
            raise ValueError("4003 - FLOWSOURCE_ERROR: Failed to Get Access Token ...")

        return access_token
