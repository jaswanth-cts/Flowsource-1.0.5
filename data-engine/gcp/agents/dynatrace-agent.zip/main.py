from DynatraceAgent import DynatraceAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def dynatrace_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = DynatraceAgent(cloud_provider)
        agent.process()
        logging.info(f'Dynatrace agent executed successfully ...')
        return "DynatraceAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Dynatrace agent: {str(e)}')
