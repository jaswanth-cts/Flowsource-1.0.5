import logging
import traceback
import os

class FlowsourceLogger:
    def __init__(self, tool_name):
        self.tool_name = tool_name.upper()
        log_level_str = os.getenv('LOG_LEVEL', 'INFO').upper()
        log_level = getattr(logging, log_level_str, logging.INFO)
        self.logger = logging.getLogger(self.tool_name)
        self.logger.setLevel(log_level)
        self.logger.propagate = True  # Prevent logs from propagating to the root logger

        #Add a console handler if there isn't one
        if not any(isinstance(handler, logging.StreamHandler) for handler in self.logger.handlers):
            if not self.logger.hasHandlers():
                console_handler = logging.StreamHandler()
                console_handler.setLevel(log_level)
                console_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
                console_handler.setFormatter(console_formatter)
                self.logger.addHandler(console_handler)

    def flush(self):
        for handler in self.logger.handlers:
            handler.flush()
    
    def debug(self, message):
        self.logger.debug(f"{self.tool_name} - {message}")

    def info(self, message):
        self.logger.info(f"{self.tool_name} - {message}")

    def exception(self, message):
        self.logger.error(f"{self.tool_name} - {message} - Stack trace: \n{traceback.format_exc()}")
        
    def warn(self, message):
       self.logger.warn(f"{self.tool_name} - {message}")

    def error(self, message):
       self.logger.error(f"{self.tool_name} - {message}")