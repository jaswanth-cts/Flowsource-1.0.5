from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
import os
import json
import logging

class FileUtils:
    def __init__(self) -> None:
        self.logger = logging.getLogger()
        pass

    
    @flowsource_exception_handler
    def loadFile(self,fileName):
        filePresent = os.path.isfile(fileName)
        config = None
        if filePresent:
            configFilePath = fileName
            with open(configFilePath, 'r') as config_file:
                config = json.load(config_file)
            return config
        if config == None:
            self.logger.error('3001 - FLOWSOURCE_FILE_ERROR: unable to load config JSON')
            raise ValueError('3001 - FLOWSOURCE_FILE_ERROR: unable to load config JSON')
        
    
    def extract_s3_key_path(self, key_url):
        # Split the URL by '/'
        parts = key_url.split('/')
        
        # Join the parts after the 's3://bucket-name/' part
        output_key = '/'.join(parts[3:])
        
        return output_key
    