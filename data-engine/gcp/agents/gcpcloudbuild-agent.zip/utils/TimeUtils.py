from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta

class TimeUtils:
    def get_current_time(self):
        timestamp_str = datetime.now(timezone.utc).isoformat()
        date_time = datetime.fromisoformat(timestamp_str)
        epoch_timestamp = date_time.timestamp()
        return int(epoch_timestamp)
    
    #format -> Day-Month-Year
    def get_current_date_month_year(self):
        current_date = datetime.now()
        current_day = current_date.day
        current_month = current_date.month
        current_year = current_date.year
        return f"{current_day}-{current_month}-{current_year}"

    #timeframe should be in days
    def get_relative_past_date(self, timeframe):
        startDate = str(datetime.now().date() - relativedelta(days=int(timeframe)))
        return startDate
    