from utils.FlowsourceLogger import FlowsourceLogger
import importlib


class ClassLoader:

    def __init__(self, module, submodule, tool_name):
        self.logger = FlowsourceLogger(tool_name)
        self.classLoader = self.get_instance(
             module, submodule)

    def get_instance(self, module, submodule):
        try:
            package = ".".join((module, submodule))
           
            # Dynamically import the module
            module = importlib.import_module(package)
            class_ = getattr(module, submodule)

        except Exception as e:
            raise ValueError(
                    f"1201 - FLOWSOURCE_CLASSLOADER_ERROR: module:{module}.{submodule} not found")

        return class_


    def get_classLoader_access(self):
        return self.classLoader