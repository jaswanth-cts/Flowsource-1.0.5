from functools import wraps
import logging
import os
from botocore.exceptions import (
    ClientError,
    EndpointConnectionError,
    HTTPClientError,
    UnknownServiceError
)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class AWSServiceException(Exception):
    def __init__(self, message, original_exception=None):
        self.message = message
        self.original_exception = original_exception
        super().__init__(self.message)

    def __str__(self):
        if self.original_exception:
            return f"{self.message} (caused by {str(self.original_exception)})"
        return self.message
        

def aws_service_exception_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            # Check if required environment variables are set
            required_env_vars = ['AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'AWS_REGION']
            for var in required_env_vars:
                if var not in os.environ:
                    raise AWSServiceException(f"FLOWSOURCE_AWS_ERROR: Environment variable {var} is not set")

            return func(*args, **kwargs)
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'UnrecognizedClientException':
                logger.exception(f"FLOWSOURCE_AWS_ERROR: ClientError Invalid credentials :  {error_code} - {str(e)}")
                raise AWSServiceException(f"FLOWSOURCE_AWS_ERROR: ClientError Invalid credentials :  {error_code}", e)
            else:
                logger.exception(f"FLOWSOURCE_AWS_ERROR: ClientError: {error_code} - {str(e)}")
            raise AWSServiceException(f"FLOWSOURCE_AWS_ERROR: ClientError occurred: {error_code}", e)
        except EndpointConnectionError as e:
            logger.exception(f"FLOWSOURCE_AWS_ERROR: EndpointConnectionError: {str(e)}")
            raise AWSServiceException("FLOWSOURCE_AWS_ERROR: EndpointConnectionError occurred", e)
        except HTTPClientError as e:
            logger.exception(f"FLOWSOURCE_AWS_ERROR: HTTPClientError: {str(e)}")
            raise AWSServiceException("FLOWSOURCE_AWS_ERROR: HTTPClientError occurred", e)
        except UnknownServiceError as e:
            logger.exception(f"FLOWSOURCE_AWS_ERROR: UnknownServiceError: {str(e)}")
            raise AWSServiceException("FLOWSOURCE_AWS_ERROR: UnknownServiceError occurred", e)
        except KeyError as e:
            logger.exception(f"3002 - FLOWSOURCE_AWS_ERROR: KeyError: {str(e)} - Environment variable not found")
            raise AWSServiceException(f"3002 - FLOWSOURCE_AWS_ERROR: Environment variable not found: {str(e)}", e)
        except Exception as e:
            logger.exception(f"FLOWSOURCE_AWS_ERROR: Unhandled exception: {str(e)}")
            raise AWSServiceException("FLOWSOURCE_AWS_ERROR: An unexpected error occurred", e)
    return wrapper