from functools import wraps
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class FlowsourceException(Exception):
    def __init__(self, message, original_exception=None):
        self.message = message
        self.original_exception = original_exception
        super().__init__(self.message)

    def __str__(self):
        if self.original_exception:
            return f"{self.message} (caused by {str(self.original_exception)})"
        return self.message


def flowsource_exception_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except FileNotFoundError as e:
            error_code = e.response["Error"]["Code"]
            logger.exception(
                f"3001 - FLOWSOURCE_FILE_ERROR: FileNotFoundError: {error_code} - {str(e)}"
            )
            raise FlowsourceException(
                f"3001 - FLOWSOURCE_FILE_ERROR: Error fetching file: {error_code}", e
            )
        except ValueError as e:
            raise FlowsourceException(f"FLOWSOURCE_CUSTOM_ERROR: An value error occurred: ", e)
        except KeyError as e:
            logger.exception(
                f"3002 - FLOWSOURCE_KEY_ERROR: {str(e)} - Environment variable not found"
            )
            raise FlowsourceException(
                f"3002 - FLOWSOURCE_KEY_ERROR:Environment variable not found: {str(e)}", e
            )
        except Exception as e:
            logger.exception(f"FLOWSOURCE_ERROR: {e}")
            raise FlowsourceException(f"FLOWSOURCE_ERROR:", e)

    return wrapper
