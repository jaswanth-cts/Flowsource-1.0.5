import logging
from functools import wraps
from google.auth.exceptions import DefaultCredentialsError
from google.api_core.exceptions import (
    GoogleAPIError,
    NotFound,
    BadRequest,
    Forbidden,
    Conflict,
    InternalServerError,
    ServiceUnavailable
)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class BigQueryConnectorException(Exception):
    def __init__(self, message, original_exception=None):
        self.message = message
        self.original_exception = original_exception
        super().__init__(self.message)

    def __str__(self):
        if self.original_exception:
            return f"{self.message} (caused by {str(self.original_exception)})"
        return self.message

def bigquery_exception_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except DefaultCredentialsError as e:
            logger.error(f"FLOWSOURCE_BIGQUERY_ERROR: Google Cloud credentials not set up: {str(e)}")
            raise BigQueryConnectorException("Google Cloud credentials not set up. Please authenticate.", e)
        except NotFound as e:
            logger.exception(f"3101 - FLOWSOURCE_BIGQUERY_ERROR: NotFound: {str(e)}")
            raise BigQueryConnectorException("3101 - FLOWSOURCE_BIGQUERY_ERROR: Resource not found in BigQuery", e)
        except BadRequest as e:
            logger.exception(f"FLOWSOURCE_BIGQUERY_ERROR: BadRequest: {str(e)}")
            raise BigQueryConnectorException("FLOWSOURCE_BIGQUERY_ERROR: Bad request error in BigQuery", e)
        except Forbidden as e:
            logger.exception(f"2004 -FLOWSOURCE_BIGQUERY_ERROR: Forbidden: {str(e)}")
            raise BigQueryConnectorException("FLOWSOURCE_BIGQUERY_ERROR: Forbidden error in BigQuery", e)
        except Conflict as e:
            logger.exception(f"FLOWSOURCE_BIGQUERY_ERROR: Conflict: {str(e)}")
            raise BigQueryConnectorException("FLOWSOURCE_BIGQUERY_ERROR: Conflict error in BigQuery", e)
        except InternalServerError as e:
            logger.exception(f"FLOWSOURCE_BIGQUERY_ERROR: InternalServerError: {str(e)}")
            raise BigQueryConnectorException("FLOWSOURCE_BIGQUERY_ERROR: Internal server error in BigQuery", e)
        except ServiceUnavailable as e:
            logger.exception(f"FLOWSOURCE_BIGQUERY_ERROR: ServiceUnavailable: {str(e)}")
            raise BigQueryConnectorException("FLOWSOURCE_BIGQUERY_ERROR: Service unavailable error in BigQuery", e)
        except GoogleAPIError as e:
            logger.exception(f"FLOWSOURCE_BIGQUERY_ERROR: GoogleAPIError: {str(e)}")
            raise BigQueryConnectorException("FLOWSOURCE_BIGQUERY_ERROR: Google API error in BigQuery", e)
        except Exception as e:
            logger.exception(f"FLOWSOURCE_BIGQUERY_ERROR: Unhandled exception: {str(e)}")
            raise BigQueryConnectorException("FLOWSOURCE_BIGQUERY_ERROR: An unexpected error occurred in BigQuery", e)
    return wrapper
