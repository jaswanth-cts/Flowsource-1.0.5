import logging
from functools import wraps
from redshift_connector.error import (
    InterfaceError,
    DatabaseError,
    OperationalError,
    ProgrammingError,
    InternalError,
    NotSupportedError,
    DataError,
    IntegrityError
)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class RedshiftConnectorException(Exception):
    def __init__(self, message, original_exception=None):
        self.message = message
        self.original_exception = original_exception
        super().__init__(self.message)

    def __str__(self):
        if self.original_exception:
            return f"{self.message} (caused by {str(self.original_exception)})"
        return self.message

def redshift_exception_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except InterfaceError as e:
            logger.exception(f"FLOWSOURCE_REDSHIFT_ERROR: InterfaceError: {str(e)}")
            raise RedshiftConnectorException("FLOWSOURCE_REDSHIFT_ERROR: Interface error occurred in Redshift", e)
        except OperationalError as e:
            logger.exception(f"FLOWSOURCE_REDSHIFT_ERROR: OperationalError: {str(e)}")
            raise RedshiftConnectorException("FLOWSOURCE_REDSHIFT_ERROR: Operational error occurred in Redshift", e)
        except ProgrammingError as e:
            logger.exception(f"2001 - FLOWSOURCE_REDSHIFT_ERROR: ProgrammingError: {str(e)}")
            raise RedshiftConnectorException("2001 - FLOWSOURCE_REDSHIFT_ERROR: Programming error occurred in Redshift", e)
        except InternalError as e:
            logger.exception(f"FLOWSOURCE_REDSHIFT_ERROR: InternalError: {str(e)}")
            raise RedshiftConnectorException("FLOWSOURCE_REDSHIFT_ERROR: Internal error occurred in Redshift", e)
        except NotSupportedError as e:
            logger.exception(f"FLOWSOURCE_REDSHIFT_ERROR: NotSupportedError: {str(e)}")
            raise RedshiftConnectorException("FLOWSOURCE_REDSHIFT_ERROR: Not supported error occurred in Redshift", e)
        except DataError as e:
            logger.exception(f"FLOWSOURCE_REDSHIFT_ERROR: DataError: {str(e)}")
            raise RedshiftConnectorException("FLOWSOURCE_REDSHIFT_ERROR: Data error occurred in Redshift", e)
        except IntegrityError as e:
            logger.exception(f"2002 - FLOWSOURCE_REDSHIFT_ERROR: IntegrityError: {str(e)}")
            raise RedshiftConnectorException("2002 - FLOWSOURCE_REDSHIFT_ERROR: Integrity error occurred in Redshift", e)
        except DatabaseError as e:
            logger.exception(f"FLOWSOURCE_REDSHIFT_ERROR: DatabaseError: {str(e)}")
            raise RedshiftConnectorException("FLOWSOURCE_REDSHIFT_ERROR: Database error occurred in Redshift", e)
        except Exception as e:
            logger.exception(f"FLOWSOURCE_REDSHIFT_ERROR: Unhandled exception: {str(e)}")
            raise RedshiftConnectorException("FLOWSOURCE_REDSHIFT_ERROR: An unexpected error occurred in Redshift", e)
    return wrapper
