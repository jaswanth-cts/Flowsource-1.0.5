from functools import wraps
import logging
from azure.core.exceptions import (
    AzureError,
    ClientAuthenticationError,
    ResourceNotFoundError,
    ServiceRequestError,
    ServiceResponseError,
    HttpResponseError,
    ResourceExistsError,
    ResourceModifiedError,
    ServiceRequestTimeoutError
)

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class AzureServiceException(Exception):
    def __init__(self, message, original_exception=None):
        self.message = message
        self.original_exception = original_exception
        super().__init__(self.message)

    def __str__(self):
        if self.original_exception:
            return f"{self.message} (caused by {str(self.original_exception)})"
        return self.message


def azure_service_exception_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ResourceModifiedError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: ResourceModifiedError: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Azure ResourceModifiedError occurred", e
            )
        except ServiceRequestTimeoutError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: ServiceRequestTimeoutError: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Azure ServiceRequestTimeoutError occurred", e
            )
        except ClientAuthenticationError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: ClientAuthenticationError: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Azure ClientAuthenticationError occurred", e
            )
        except ResourceExistsError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: ResourceExistsError: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Azure ResourceExistsError occurred", e
            )
        except ResourceNotFoundError as e:
            logger.exception(f"3101 - FLOWSOURCE_AZURE_ERROR: ResourceNotFoundError: {str(e)}")
            raise AzureServiceException(
                "3101 - FLOWSOURCE_AZURE_ERROR: Azure ResourceNotFoundError occurred", e
            )
        except ServiceRequestError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: ServiceRequestError: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Azure ServiceRequestError occurred", e
            )
        except ServiceResponseError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: ServiceResponseError: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Azure ServiceResponseError occurred", e
            )
        except HttpResponseError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: HttpResponseError: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Azure HttpResponseError occurred", e
            )
        except KeyError as e:
            logger.exception(
                f"3002 - FLOWSOURCE_AZURE_ERROR: KeyError: {str(e)} - Environment variable not found"
            )
            raise AzureServiceException(
                f"3002 - FLOWSOURCE_AZURE_ERROR: Environment variable not found: {str(e)}", e
            )
        except AzureError as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: Error while connecting to Azure ", e
            )
        except Exception as e:
            logger.exception(f"FLOWSOURCE_AZURE_ERROR: Unhandled exception: {str(e)}")
            raise AzureServiceException(
                "FLOWSOURCE_AZURE_ERROR: An unexpected error occurred", e
            )

    return wrapper
