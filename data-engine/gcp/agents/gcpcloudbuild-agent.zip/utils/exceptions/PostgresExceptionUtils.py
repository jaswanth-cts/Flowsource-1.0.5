import logging
from functools import wraps
from asyncpg import (
    InterfaceError,
    PostgresError,
    InternalServerError,
    FeatureNotSupportedError,
    DataError,
    IntegrityConstraintViolationError,
)

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class PostgresConnectorException(Exception):
    def __init__(self, message, original_exception=None):
        self.message = message
        self.original_exception = original_exception
        super().__init__(self.message)

    def __str__(self):
        if self.original_exception:
            return f"{self.message} (caused by {str(self.original_exception)})"
        return self.message


def postgres_exception_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except InterfaceError as e:
            logger.exception(f"FLOWSOURCE_POSTGRES_ERROR: InterfaceError: {str(e)}")
            raise PostgresConnectorException(
                "FLOWSOURCE_POSTGRES_ERROR: Interface error occurred in PostgreSQL", e
            )
        except InternalServerError as e:
            logger.exception(f"FLOWSOURCE_POSTGRES_ERROR: InternalServerError: {str(e)}")
            raise PostgresConnectorException(
                "FLOWSOURCE_POSTGRES_ERROR: Internal server error occurred in PostgreSQL",
                e,
            )
        except FeatureNotSupportedError as e:
            logger.exception(
                f"FLOWSOURCE_POSTGRES_ERROR: FeatureNotSupportedError: {str(e)}"
            )
            raise PostgresConnectorException(
                "FLOWSOURCE_POSTGRES_ERROR: Feature not supported error occurred in PostgreSQL",
                e,
            )
        except DataError as e:
            logger.exception(f"FLOWSOURCE_POSTGRES_ERROR: DataError: {str(e)}")
            raise PostgresConnectorException(
                "FLOWSOURCE_POSTGRES_ERROR: Data error occurred in PostgreSQL", e
            )
        except IntegrityConstraintViolationError as e:
            logger.exception(
                f"2002 - FLOWSOURCE_POSTGRES_ERROR: IntegrityConstraintViolationError: {str(e)}"
            )
            raise PostgresConnectorException(
                "2002 - FLOWSOURCE_POSTGRES_ERROR: Integrity constraint violation error occurred in PostgreSQL",
                e,
            )
        except PostgresError as e:
            logger.exception(f"FLOWSOURCE_POSTGRES_ERROR: {str(e)}")
            raise PostgresConnectorException(
                "FLOWSOURCE_POSTGRES_ERROR: Error while connecting to postgres", e
            )
        except Exception as e:
            logger.exception(f"FLOWSOURCE_POSTGRES_ERROR: Unhandled exception: {str(e)}")
            raise PostgresConnectorException(
                "FLOWSOURCE_POSTGRES_ERROR: An unexpected error occurred in PostgreSQL",
                e,
            )

    return wrapper
