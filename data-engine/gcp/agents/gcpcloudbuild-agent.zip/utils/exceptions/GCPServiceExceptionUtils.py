from functools import wraps
import logging
from google.api_core.exceptions import (
    GoogleAPIError,
    NotFound,
    Forbidden,
    Conflict,
    TooManyRequests,
    InternalServerError,
    ServiceUnavailable,
    BadRequest,
    Unauthorized
)
from google.auth.exceptions import GoogleAuthError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class GCPServiceException(Exception):
    def __init__(self, message, original_exception=None):
        self.message = message
        self.original_exception = original_exception
        super().__init__(self.message)

    def __str__(self):
        if self.original_exception:
            return f"{self.message} (caused by {str(self.original_exception)})"
        return self.message


def gcp_service_exception_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except GoogleAuthError as e:
            logger.error(f"FLOWSOURCE_GCP_ERROR: Authentication failed: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: Authentication failed", e
            )
        except NotFound as e:
            logger.exception(f"3101 - FLOWSOURCE_GCP_ERROR: NotFound: {str(e)}")
            raise GCPServiceException(
                "3101 - FLOWSOURCE_GCP_ERROR: GCP NotFound error occurred", e
            )
        except Forbidden as e:
            logger.exception(f"2004 -FLOWSOURCE_GCP_ERROR: Forbidden: {str(e)}")
            raise GCPServiceException(
                "3101 -FLOWSOURCE_GCP_ERROR: GCP Forbidden error occurred", e
            )
        except Conflict as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: Conflict: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: GCP Conflict error occurred", e
            )
        except TooManyRequests as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: TooManyRequests: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: GCP TooManyRequests error occurred", e
            )
        except InternalServerError as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: InternalServerError: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: GCP InternalServerError occurred", e
            )
        except ServiceUnavailable as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: ServiceUnavailable: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: GCP ServiceUnavailable error occurred", e
            )
        except BadRequest as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: BadRequest: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: GCP BadRequest error occurred", e
            )
        except Unauthorized as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: Unauthorized: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: GCP Unauthorized error occurred", e
            )
        except GoogleAPIError as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: Error while connecting to GCP", e
            )
        except Exception as e:
            logger.exception(f"FLOWSOURCE_GCP_ERROR: Unhandled exception: {str(e)}")
            raise GCPServiceException(
                "FLOWSOURCE_GCP_ERROR: An unexpected error occurred", e
            )

    return wrapper
