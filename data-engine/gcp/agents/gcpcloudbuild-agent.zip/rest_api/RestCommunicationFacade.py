import requests
import logging
import json
from requests.auth import HTTPBasicAuth
import hmac
import hashlib
import time
import os
from urllib.parse import urlparse

# from requests_ntlm import HttpNtlmAuth

class RestCommunicationFacade(object):
    headers = {"Accept":"application/json"}
    requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
    
    def __init__(self, sslVerify, responseType, enableValueArray):
        self.sslVerify = sslVerify
        self.responseType = responseType
        self.enableValueArray = enableValueArray

    def communicate(self, url, method, userName, cred, data, aType='BASIC', reqHeaders=None,responseTupple=None, proxies=None):
        auth = None
        response = None
        if aType=='BASIC':
            if(userName != None and cred != None):
                auth = HTTPBasicAuth(userName, cred)    

            if reqHeaders == None:
                reqHeaders = RestCommunicationFacade.headers
                
        elif aType=='HMAC':
            if reqHeaders == None:
                reqHeaders = {"Authorization": self.generate_hmac_header(userName, cred, url, method),
                              "Accept":"application/json"}
        
        try:
            if('GET' == method):
                response = requests.get(url, auth=auth, headers=reqHeaders, data=data, proxies=proxies, verify=self.sslVerify)
            elif('POST' == method):
                response = requests.post(url, auth=auth, headers=reqHeaders, data=data, proxies=proxies, verify=self.sslVerify)
        except Exception as e:
            raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: Error while connecting to endpoint') 
            
        if None == response:
            logging.error('FLOWSOURCE_RESTFACADE_ERROR: Null response')
        elif response.status_code not in [200, 201]:
            if 400 == response.status_code:
                raise ValueError('5001 - FLOWSOURCE_RESTFACADE_ERROR: Bad request error '+ str(response.status_code)+', url: '+url+', response received: '+ str(response.content, 'utf8'))
            elif 401 == response.status_code:
                raise ValueError('5002 - FLOWSOURCE_RESTFACADE_ERROR: Unauthorized error '+ str(response.status_code)+', url: '+url+', response received: '+ str(response.content, 'utf8'))    
            elif 403 == response.status_code:
                raise ValueError('5003 - FLOWSOURCE_RESTFACADE_ERROR: Forbidden error '+ str(response.status_code)+', url: '+url+', response received: '+ str(response.content, 'utf8'))   
            elif 404 == response.status_code:
                raise ValueError('5004 - FLOWSOURCE_RESTFACADE_ERROR: Requested webpage not found in server '+ str(response.status_code)+', url: '+url+', response received: '+ str(response.content, 'utf8'))
            elif 500 == response.status_code:
                raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: Internal server error '+ str(response.status_code)+', url: '+url+', response received: '+ str(response.content, 'utf8'))
            elif 503 == response.status_code:
                raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: Service unavailable error '+ str(response.status_code)+', url: '+url+', response received: '+ str(response.content, 'utf8'))
            else:
                raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: Error '+ str(response.status_code)+', url: '+url+', response received: '+ str(response.content, 'utf8'))

        if responseTupple != None:
            responseTupple['headers'] = response.headers
            responseTupple['cookies'] = response.cookies
        if len(response.content) > 0:
            if "Accept" in reqHeaders and reqHeaders["Accept"] == "text/csv":
                return response.content.decode('utf-8')
            elif self.responseType == 'JSON':
                return response.json()
            elif self.responseType == 'XML':
                return response.content
        else:
            return {}        
    
    def processResponse(self, template, response, injectData={}, useResponseTemplate=False):
        if template == None:
            raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: No parsingTemplate is provided')
        elif response == None:
            raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: No response is provided')
        else:
            pass
        
        dataArray = []
        if type(response) is list:
            for listItem in response:
                data = {};
                data.update(injectData)
                if useResponseTemplate:
                    self.parseResponse(template, listItem, data)
                else:                    
                    self.parseResponseWithXPath(listItem, data, None)
                dataArray.append(data)
        else:
            data = {};
            data.update(injectData)
            if useResponseTemplate:
                self.parseResponse(template, response, data)
            else:
                self.parseResponseWithXPath(response, data, None)
            dataArray.append(data)
        return dataArray
    
    def parseResponseWithXPath(self, responseObj, data, xpath):
        keyType = type(responseObj)
        if responseObj == None:
            return
        if keyType is dict:
            for key in responseObj:
                self.parseResponseWithXPath(responseObj.get(key, None), data, self.computeXPath(xpath, key))
        elif keyType is list:
            for index, item in enumerate(responseObj):
                self.parseResponseWithXPath(item, data, self.computeXPath(xpath, index))
        else:
            data[self.sanitizeKey(xpath)] = responseObj
    
    def sanitizeKey(self, key):
        return key.replace('/', '_')
    
    def computeXPath(self, xpath, key):
        newXpath = xpath
        if newXpath == None:
            newXpath = str(key)
        else:
            newXpath = xpath + '__' + str(key)
        return newXpath
    
    def parseResponse(self, templateObj, responseObj, data):
        keyType = type(templateObj)
        if responseObj == None:
            return
        dynamicName = None
        dynamicValue = None
        if keyType is dict:
            for key in templateObj:
                if '$' in key:
                    if '$name' in key:
                        dynamicName = responseObj.get(key.replace('$name$',''), None)
                    elif '$value' in key:
                        dynamicValue = responseObj.get(key.replace('$value$',''), None)
                else:
                    self.parseResponse(templateObj.get(key, None), responseObj.get(key, None), data)
        elif keyType is list:
            #Handle the multiple entries which are part of template object.
            for secTemplate in templateObj:
                secDataArray = []
                for item in responseObj:
                    if item:
                        secData = {};
                        self.parseResponse(secTemplate, item, secData)
                        if secData:
                            secDataArray.append(secData)
                for secData in secDataArray:
                    for secKey in secData:
                        prevValue = data.get(secKey, None)
                        if self.enableValueArray:
                            if prevValue and secData[secKey] not in prevValue:
                                prevValue.append(secData[secKey])
                            elif type(secData[secKey]) is list:
                                data[secKey] = " , ".join(secData[secKey])
                            else:
                                data[secKey] = [secData[secKey]]
                        else:
                            if prevValue:
                                data[secKey] = prevValue + "," + secData[secKey]
                            else:
                                data[secKey] = secData[secKey]
        elif keyType is str:
            responseObjType = type(responseObj)
            if responseObjType is dict:
                logging.error('Incorrect Dict object assignment is not allowed.')
                logging.error('Property Name: '+templateObj)
                logging.error('Property value: '+json.dumps(responseObj))
                raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: Unsupported dictionary data type found ') 
            else:
                data[templateObj] = responseObj
            
        else:
            raise ValueError('FLOWSOURCE_RESTFACADE_ERROR: Unsupported data type found '+str(keyType))
        
        if dynamicName:
            data[dynamicName] = dynamicValue

    def generate_hmac_header(self, api_id, api_key, api_url, method):
        AUTH_SCHEME = "VERACODE-HMAC-SHA-256"
        REQUEST_VERSION = "vcode_request_version_1"
        parsed_url = urlparse(api_url)
        host = parsed_url.hostname
        path = parsed_url.path
        if parsed_url.query:
            path += '?' + parsed_url.query

        # Generate 16-byte nonce
        nonce = os.urandom(16)
        timestamp = str(int(time.time() * 1000))

        # Construct the data string
        data = f"id={api_id}&host={host}&url={path}&method={method.upper()}"

        # Decode API key from hex
        key_bytes = bytes.fromhex(api_key)

        # HMAC chain
        def hmac256(data_bytes, key):
            return hmac.new(key, data_bytes, hashlib.sha256).digest()

        k_nonce = hmac256(nonce, key_bytes)
        k_date = hmac256(timestamp.encode('utf-8'), k_nonce)
        k_sig = hmac256(REQUEST_VERSION.encode('utf-8'), k_date)
        signature = hmac.new(k_sig, data.encode('utf-8'), hashlib.sha256).hexdigest()

        # Final HAMC header
        auth_param = f"id={api_id},ts={timestamp},nonce={nonce.hex()},sig={signature}"
        return f"{AUTH_SCHEME} {auth_param}"
    