from rest_api.RestCommunicationFacade import RestCommunicationFacade
class CommunicationFacade(object):
        
    def getCommunicationFacade(self, facadeType, sslVerify, responseType, enableValueArray):
        if 'REST' == facadeType:
            return RestCommunicationFacade(sslVerify, responseType, enableValueArray);
        else:
            raise ValueError('CommunicationFacade: Unsupported Facade Type '+facadeType)
