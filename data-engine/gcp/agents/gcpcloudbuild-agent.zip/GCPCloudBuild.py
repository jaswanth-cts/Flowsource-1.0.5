from datetime import datetime, timedelta
from dateutil import parser
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
from google.cloud.devtools import cloudbuild_v1
from google.api_core import client_options
import os
from google.oauth2 import service_account
import base64

class GCPCloudBuild(BaseAgent):

    @flowsource_exception_handler
    def process(self):

        # Load configurations and initialize
        self.load_configuration()
        
        # Fetch catalog data
        catalogData = self.fetchCatalogData(self.select_query)

        # Fetch catalog data dictionary
        self.catalog_dict = self.process_catalog_data(catalogData)
        
        # Process and publish tools data and update tracking file
        self.process_tool_data()


    def load_configuration(self):
        # Retrieve credentials specific to the agent from config.json
        self.select_query = self.config.get(self.cloud_provider, "").get(
            "catalogDataSelectQuery", ""
        )

        # set-up service account details for credentials
        self.init_auth_credentials()

        self.batchSize = self.config.get("batchSize", 1000)
        self.batchCollectDays = self.config.get("batchCollectDays", 30)

        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        # Check the length of startFromDate, if it is equal to 10 add time and zone
        if len(self.startFromDate) == 10:
            self.configStartDate = self.startFromDate + "T00:00:00"

    def init_auth_credentials(self):
        
        # Retrieve the service account details from the config.json and secret manager
        projectNumber = self.config.get(self.cloud_provider, "").get("projectNumber", "")
        projectId = self.config.get(self.cloud_provider, "").get("projectId", "")
        privateKeyId = self.config.get(self.cloud_provider, "").get("privateKeyId", "")
        privateKey = self.config.get(self.cloud_provider, "").get("privateKey", "")
        clientEmail = self.config.get(self.cloud_provider, "").get("clientEmail", "")
        clientId = self.config.get(self.cloud_provider, "").get("clientId", "")
        self.gcp_project_number = self.keyValues[projectNumber]
        
        # Read env variables
        authUri = os.environ["AUTH_URI"]
        tokenUri = os.environ["TOKEN_URI"]
        authProviderX509CertUrl = os.environ["AUTH_PROVIDER_X509_CERT_URL"]
        clientX509CertUrl = os.environ["CLIENT_X509_CERT_URL"]

        # Decode the private key
        decode_private_key = base64.b64decode(self.keyValues[privateKey]).decode("utf-8")
        
        # Replace the escape characters
        decode_private_key = decode_private_key.replace("\\n", "\n")

        # create service account dictonary
        self.service_account_dict = {
            "type": "service_account",
            "project_id": self.keyValues[projectId],
            "private_key_id": self.keyValues[privateKeyId],
            "private_key": decode_private_key,
            "client_email": self.keyValues[clientEmail],
            "client_id": self.keyValues[clientId],
            "auth_uri": authUri,
            "token_uri": tokenUri,
            "auth_provider_x509_cert_url": authProviderX509CertUrl,
            "client_x509_cert_url": clientX509CertUrl,
            "universe_domain": "googleapis.com",
        }


    def process_tool_data(self):

        self.logger.info("FLOWSOURCE_INFO: Processing tool data ...")
        
        # fetch appId list
        catalogAppIdList = self.get_dict_keys(self.catalog_dict)
        
        # Check if catalog data is empty
        if catalogAppIdList is None:
            self.logger.info("No catalog data found.")
            return
        
        for appId in catalogAppIdList:
    
            # Initialize client to None
            client = None
            credentials = service_account.Credentials.from_service_account_info(self.service_account_dict)
            
            # Get the gcp cloudbuild pipelines and region from the catalog data
            gcp_pipelines = self.catalog_dict[appId]["gcp_pipelines"]
            
            gcp_region = self.catalog_dict[appId]["gcp_region"]
            
            if gcp_region == "global":
                # if the GCP region is global
                self.logger.info("Created global client !!!")
                client = cloudbuild_v1.CloudBuildClient(credentials=credentials)    
            else:
                # if the GCP region is non-global
                self.logger.info("Created non-global client !!!")
                api_endpoint = f"{gcp_region}-cloudbuild.googleapis.com"
                client_opts = client_options.ClientOptions(api_endpoint=api_endpoint)
                client = cloudbuild_v1.CloudBuildClient(client_options=client_opts, credentials=credentials)

            # Get all trigger id and names in a map
            triggerNameAndIdMap = self.get_trigger_name_and_id_map(client)

            # check if the map is empty
            if not triggerNameAndIdMap:
                self.logger.info(f"No cloud build triggers found for project '{self.gcp_project_number}'.")
                continue
            
            self.process_gcp_pipeline(appId, client, gcp_pipelines, triggerNameAndIdMap)
                
            

    def process_gcp_pipeline(self, appId, client, gcp_pipelines, triggerNameAndIdMap):

        # Split the string into a list, if it contains multiple pipelines
        gcp_pipeline_list = gcp_pipelines.split(',') 

        # Trim whitespace around each element (if needed) 
        gcp_pipeline_list = [pipeline.strip() for pipeline in gcp_pipeline_list]

        for trigger_name in gcp_pipeline_list:
            # Fetch trigger if from the map
            trigger_id = triggerNameAndIdMap[trigger_name]
            # Check if trigger_id is None
            if trigger_id is None:
                self.logger.info(f"Trigger '{trigger_name}' not found.")
                continue

            # get start and end time as string
            start_time_str, end_time_str = self.get_tracking_lastUpdate(appId, trigger_name)

            # Get successful builds for the trigger
            self.get_builds(client, appId, trigger_id, trigger_name, start_time_str, end_time_str)


    # Get the trigger names and corresponding ids
    def get_trigger_name_and_id_map(self, client):
        # Retrieve the trigger ID for a given trigger name.
        request = cloudbuild_v1.ListBuildTriggersRequest(project_id=self.gcp_project_number)
        triggerNameAndIdMap = {}
        for response in client.list_build_triggers(request=request).pages:
            if response:
                for trigger in response.triggers:
                   triggerNameAndIdMap[trigger.name] = trigger.id
        return triggerNameAndIdMap

    # get the successful builds for a trigger id
    def get_builds(self, client, appId, trigger_id, trigger_name, start_time_str ,end_time_str):

        # Parse the start and end time strings to datetime objects
        start_time = datetime.fromisoformat(start_time_str)
        end_time = datetime.fromisoformat(end_time_str)

        # Retrieve all successful builds for a given trigger ID
        filter_query = (
            f'trigger_id="{trigger_id}" AND status="SUCCESS" AND '
            f'create_time>"{start_time.isoformat()}Z" AND create_time<"{end_time.isoformat()}Z"'
        )

        # define filetype to publish the data
        fileType='Job'

        request = cloudbuild_v1.ListBuildsRequest(project_id=self.gcp_project_number, filter=filter_query)
        builds = []
        for response in client.list_builds(request=request).pages:
            if response:
                for build in response.builds:
                    builds.append(build)

        # If there are no builds, update the tracking file with current end time and return.
        if(len(builds) == 0):
            self.logger.info(f"No builds found for trigger {trigger_name}.")
            self.update_tracking_data(endDateTime=end_time_str, appid=appId, trigger_name=trigger_name)
            self.updateTrackingFile(self.tracking)
            return
        
        successful_builds = []
        # reversing the builds array to publish builds and tracking in ascending order of time
        for build in reversed(builds):
            # date time object required for trackign file
            build_creation_time = (build.create_time).strftime("%Y-%m-%dT%H:%M:%S")
            
            # epoch time conversion required for DB
            creation_time_epoch = int((build.create_time).timestamp())

            build_data = {
                    "appid": appId,
                    "buildnumber": build.id,
                    "result": "SUCCESS",
                    "buildtimestamp": creation_time_epoch, #updated with epoch time
                    "buildurl": build.log_url,
                    "shortDescription": trigger_name,
                    "jobName": trigger_name,
                }
            successful_builds.append(build_data)

            # update tracking file
            self.update_tracking_data(endDateTime=build_creation_time, appid=appId, trigger_name=trigger_name)
            self.publishData(successful_builds, fileType, self.batchSize, False, self.tracking)

        if(len(successful_builds) > 0):
            self.publishData(successful_builds, fileType, self.batchSize, True, self.tracking)


    # process the catalog data to get the pipeline details
    def process_catalog_data(self, catalogData):
        # Format the catalog data in kye:value pair 
        # eg.{app_id_value:{"gcp_pipelines":gcp_pipelines_value, "gcp_region":gcp_region_value}}
        processedCatalogData = {}
        for catalog in catalogData:
            if catalog:
                processedCatalogData[catalog[0]] = {
                    "gcp_pipelines": catalog[1],
                    "gcp_region": catalog[2],
                }
        return processedCatalogData

    def update_tracking_data(self, endDateTime, appid, trigger_name):
        if appid not in self.tracking:
            self.tracking[appid] = {"lastupdated_" + trigger_name: endDateTime}   
        else:
            lastupdated_pipeline_name = "lastupdated_" + trigger_name
            self.tracking[appid][lastupdated_pipeline_name] = endDateTime

    def get_dict_keys(self, dict):
        return list(dict.keys())

    def get_tracking_lastUpdate(self, appId, trigger_name):
        
        # fetch the startDate either from config.json or tracking file
        startDate = self.tracking.get(appId, {}).get("lastupdated_" + trigger_name, self.configStartDate)
        
        # set the required date format
        dateFormat = "%Y-%m-%dT%H:%M:%S"
        
        # get end time based on batchCollectDays
        endDateTime = self.getEndTime(startDate, self.batchCollectDays, dateFormat, "dateTime")

        # format the startDate
        startDateTime = datetime.strptime(startDate, dateFormat).strftime(dateFormat)

        return startDateTime, endDateTime