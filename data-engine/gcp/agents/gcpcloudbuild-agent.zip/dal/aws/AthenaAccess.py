import os
import boto3
import time
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.AWSServiceExceptionUtils import aws_service_exception_handler


class AthenaAccess:

    @aws_service_exception_handler
    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.work_group=os.getenv("ATHENA_WORKGROUP", default = None)
        self.s3_data_catalog = os.getenv("ATHENA_S3_DATA_CATALOG", default = None)
        self.athena_db = os.getenv("ATHENA_DATABASE_NAME", default = None)
        self.athena_client = boto3.client("athena")

    @aws_service_exception_handler
    def execute_athena_query(self, query, output_location):
        self.logger.info(f"Executing athena UNLOAD query ...")

        # Start query execution
        response = self.athena_client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={"Database": self.athena_db},
            ResultConfiguration={"OutputLocation": output_location},
            WorkGroup=self.work_group,
        )

        # Get the QueryExecutionId
        query_execution_id = response["QueryExecutionId"]

        # Wait for the query to complete
        while True:
            query_status = self.athena_client.get_query_execution(
                QueryExecutionId=query_execution_id
            )

            status = query_status["QueryExecution"]["Status"]["State"]

            if status in ["SUCCEEDED", "FAILED", "CANCELLED"]:
                break
            self.logger.info(f"Waiting for query to complete...{query_status}")
            time.sleep(5)

        if status != "SUCCEEDED":
            self.logger.info(f"2003 - FLOWSOURCE_ATHENA_ERROR: UNLOAD command failed with status: {status}")
            raise ValueError(f"2003 - FLOWSOURCE_ATHENA_ERROR: UNLOAD command failed with status: {status}")

        self.logger.info(
            f"UNLOAD command completed successfully, execution id: {query_execution_id}"
        )
        return query_execution_id
