import json
import os
import boto3
import base64
from dal.IDataAccess import IConfigManager
from utils.FileUtils import FileUtils
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.AWSServiceExceptionUtils import aws_service_exception_handler


class AwsConfigManager(IConfigManager):

    @aws_service_exception_handler
    def __init__(self, provider, tool_name):
        self.logger = FlowsourceLogger(tool_name)
        self.fileUtils = FileUtils()
        self.config = self.fileUtils.loadFile('config.json')
        self.cloud_provider = provider
        self.aws_config_names = self.config.get(
            self.cloud_provider, '').get("configManager", [])
        # create boto3 client
        self.vpc_endpoint = os.environ["CREDENTIAL_MANAGER_ENDPOINT"]
        self.config_client = boto3.client(
            service_name=base64.b64decode(
                "c2VjcmV0c21hbmFnZXI=").decode('utf-8'),
            endpoint_url=self.vpc_endpoint
        )

    @aws_service_exception_handler
    def get_config_manager(self, aws_config_names):
        config_json_array = []
        config_json_object = {}
        for config_name in aws_config_names:
            self.logger.info(f"Fetching secrets for {config_name} ...")
            response = self.config_client.get_secret_value(
                SecretId=config_name)
            config_json_array.append(json.loads(response["SecretString"]))

        for config_json in config_json_array:
            config_json_object.update(config_json)

        return config_json_object

    @aws_service_exception_handler
    def check_secret_exists(self):
        try:
            for config_name in self.aws_config_names:
                self.config_client.get_secret_value(SecretId=config_name)
        except Exception as e:
            raise KeyError(
                "FLOWSOURCE_HEALTH_CHECK_ERROR: AWS Secret Manager Error: "+ e
            )

    # INTERFACE IMPL
    def get_key_values(self):
        self.configManager = self.get_config_manager(self.aws_config_names)
        return self.configManager
