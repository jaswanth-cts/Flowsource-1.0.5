import redshift_connector
import os
from dal.IDataAccess import IDatabaseAccess
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.RedshiftExceptionUtils import redshift_exception_handler


class RedshiftAccess(IDatabaseAccess):

    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.keyValues = keyValues
        self.database_name = os.environ["DATABASE_NAME"]

    def connect_to_redshift(self):
        conn = redshift_connector.connect(
            database=self.database_name,
            user=self.keyValues['DB_UN'],
            password=self.keyValues['DB_PS'],
            host=self.keyValues["host"],
            port=self.keyValues["port"],
        )
        return conn

    @redshift_exception_handler
    def execute_query_in_redshift(self, *queries):
        conn = None
        cursor = None
        try:
            conn = self.connect_to_redshift()
            cursor = conn.cursor()
            for query in queries:
                cursor.execute(query)
                conn.commit()
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    # INTERFACE IMPL
    @redshift_exception_handler
    def check_db_conn(self):
        conn = None
        try:
            conn = self.connect_to_redshift()
        except Exception as e:
            raise KeyError('Error connecting to Redshift: ' + e)
        finally:
            if conn:
                conn.close()

    # INTERFACE IMPL
    @redshift_exception_handler
    def fetch_catalog_data_from_db(self, select_query):
        self.logger.info("Fetching data from Redshift ...")
        result = ()
        conn = None
        cursor = None
        try:
            conn = self.connect_to_redshift()
            with conn.cursor() as cursor:
                cursor.execute(select_query)
                result = cursor.fetchall()
            return result
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    # INTERFACE IMPL
    def load_json_data_to_staging_table(self, gcs_uri, staging_table):
        pass

    # INTERFACE IMPL
    def delete_staging_table(self, staging_table):
        pass