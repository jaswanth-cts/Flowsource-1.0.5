import boto3
import json
from dal.IDataAccess import IStorageAccess
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.AWSServiceExceptionUtils import aws_service_exception_handler


class S3Access(IStorageAccess):

    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.keyValues = keyValues
        self.create_s3_client()

    @aws_service_exception_handler
    def create_s3_client(self):
        self.s3_client = boto3.client("s3")

    ########################## AGENT FUNCTIONS #########################

    @aws_service_exception_handler
    def upload_tool_json_to_storage(self, bucketName, key, data):
        self.logger.info(
            f"Uploading File to S3 bucket: {bucketName}, key: {key}")
        filedata = "\n".join(str(obj) for obj in data)
        byte_array = bytes(filedata, "utf-8")

        self.s3_client.put_object(Bucket=bucketName, Key=key, Body=byte_array)
        self.logger.info("Uploading File to S3 is done ...")

    # INTERFACE IMPL
    def is_file_exists(self, bucketName, key):
        # def is_s3_key_exists(self, bucketName, key):
        try:
            self.s3_client.head_object(Bucket=bucketName, Key=key)
            self.logger.info(f"Key: {key} Exists")
            return True  # The key exists
        except self.s3_client.exceptions.NoSuchKey:
            self.logger.exception(f"Key: {key} Not Found")
            return False  # The key does not exist
        except Exception as e:
            self.logger.warn(
                f"Failed to fetch bucketName: {bucketName} key: {key} ...")
            return False

    # INTERFACE IMPL
    @aws_service_exception_handler
    def write_json_to_storage(self, bucketName, key, data):
        self.logger.info(
            f"Updating JSON to S3 bucket: {bucketName}, key: {key}")
        # Serialize and encode the data to a JSON string
        json_string = json.dumps(data)
        byte_array = json_string.encode("utf-8")

        self.s3_client.put_object(Body=byte_array, Bucket=bucketName, Key=key)
        self.logger.info("Updating JSON to S3 is done ...")

    # INTERFACE IMPL
    @aws_service_exception_handler
    def read_json_from_storage(self, bucket, key):
        response = self.s3_client.get_object(Bucket=bucket, Key=key)
        content = response["Body"].read().decode("utf-8")
        json_content = json.loads(content)
        return json_content

    # INTERFACE IMPL
    @aws_service_exception_handler
    def is_storage_exists(self, bucket_name):
        try:
            self.s3_client.head_bucket(Bucket=bucket_name)
            return True
        except Exception as e:
            raise KeyError(
                "FLOWSOURCE_HEALTH_CHECK_ERROR: S3 Error: " + e
            )

    ########################## ENGINE FUNCTIONS #########################
    # INTERFACE IMPL
    @aws_service_exception_handler
    def copy_storage_object(self, bucket, key, destination_key):
        self.logger.info("copying s3 object key...")
        # Copy the file with updated name
        self.s3_client.copy_object(Bucket=bucket, Key=destination_key, CopySource={"Bucket": bucket, "Key": key})
        self.logger.info(f"In S3 File Copied and Renamed from {key} to {destination_key}")

    # INTERFACE IMPL
    @aws_service_exception_handler
    def delete_storage_object(self, bucket, key):
        self.s3_client.delete_object(Bucket=bucket, Key=key)

    
