from dal.IDataAccess import IConfigManager
from utils.FlowsourceLogger import FlowsourceLogger
from utils.FileUtils import FileUtils



class PCConfigManager(IConfigManager):

    
    def __init__(self, provider, tool_name):
        self.logger = FlowsourceLogger(tool_name)
        self.fileUtils = FileUtils()
        self.cloud_provider=provider
        self.config = self.fileUtils.loadFile('config.json')
    
    def check_secret_exists(self):
        pass

    # INTERFACE IMPL
    def get_key_values(self):
        key_values = self.config.get(self.cloud_provider, "")
        return key_values
