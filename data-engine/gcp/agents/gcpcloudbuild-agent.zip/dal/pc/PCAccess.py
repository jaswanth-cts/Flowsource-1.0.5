
import json
import os
from dal.IDataAccess import IStorageAccess
from utils.FlowsourceLogger import FlowsourceLogger



class PCAccess(IStorageAccess):

    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.keyValues = keyValues
      
    
    def upload_tool_json_to_storage(self, bucketName, key, data):
        self.logger.info("Writing data to file ...")
        with open(key, 'w') as outfile:
            json.dump(data, outfile, indent=4, sort_keys=True)

    # INTERFACE IMPL
    
    def is_file_exists(self, bucketName, key):
        if os.path.isfile(key):
            return True
        else:
            return False
    
    def write_json_to_storage(self, bucketName, key, data):
        self.logger.info("Writing data to file ...")
        # Extract the directory from the key
        directory = os.path.dirname(key)
        # Check if the directory exists, if not, create it
        if not os.path.exists(directory):
            os.makedirs(directory)
        # Write the data to the file
        with open(key, 'w') as outfile:
            json.dump(data, outfile, indent=4, sort_keys=True)

    # INTERFACE IMPL
   
    def read_json_from_storage(self, bucket, key):
        try:
            filePresent = os.path.isfile(key)
            if filePresent:
                self.configFilePath = key
                with open(self.configFilePath, 'r') as config_file:
                    json_content = json.load(config_file)
                return json_content

        except Exception as ex:
            raise ValueError(ex)

     # INTERFACE IMPL
    
    def copy_storage_object(self, bucket_name):
        pass

    # INTERFACE IMPL
    
    def delete_storage_object(self, bucket_name):
        pass

    # INTERFACE IMPL
    
    def is_storage_exists(self, bucket_name):
        pass
