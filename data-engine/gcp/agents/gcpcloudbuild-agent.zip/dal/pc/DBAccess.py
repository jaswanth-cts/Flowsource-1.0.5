
from dal.IDataAccess import IDatabaseAccess
from utils.FlowsourceLogger import FlowsourceLogger
from utils.FileUtils import FileUtils



class DBAccess(IDatabaseAccess):

    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.keyValues = keyValues
        self.fileUtils = FileUtils()
        self.config = self.fileUtils.loadFile('config.json')
      
    # INTERFACE IMPL
    
    def check_db_conn(self):
        pass

    # INTERFACE IMPL
    
    def delete_staging_table(self):
        pass

    # INTERFACE IMPL
    
    def load_json_data_to_staging_table(self):
        pass

    # INTERFACE IMPL
   
    def fetch_catalog_data_from_db(self, select_query):
        self.catalogData = self.config.get('PC', {}).get('catalogData', '')
        return self.catalogData
        
    