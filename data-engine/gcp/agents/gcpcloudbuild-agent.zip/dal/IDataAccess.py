from abc import ABC, abstractmethod


class IConfigManager(ABC):

    # HEALTH_CHECK
    @abstractmethod
    def check_secret_exists(self):
        pass

    @abstractmethod
    def get_key_values(self):
        pass


class IDatabaseAccess(ABC):

    # HEALTH_CHECK
    @abstractmethod
    def check_db_conn(self):
        pass

    @abstractmethod
    def fetch_catalog_data_from_db(self, select_query):
        pass

    @abstractmethod
    def load_json_data_to_staging_table(self, gcs_uri, staging_table):
        pass

    @abstractmethod
    def delete_staging_table(self, staging_table):
        pass


class IStorageAccess(ABC):

    # HEALTH_CHECK
    @abstractmethod
    def is_storage_exists(self, storage_name):
        pass

    @abstractmethod
    def is_file_exists(self, storage, file):
        pass

    @abstractmethod
    def read_json_from_storage(self, storage, file):
        pass

    @abstractmethod
    def write_json_to_storage(self, storage, file, data):
        pass

    @abstractmethod
    def copy_storage_object(self, container_name, source_object_name, destination_container_name):
        pass

    @abstractmethod
    def delete_storage_object(self, container_name, source_object_name):
        pass
