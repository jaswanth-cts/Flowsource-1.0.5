from utils.ClassLoader import ClassLoader


class DataAccessLayer:
    def __init__(self, cloud_provider, tool_name):
        
        class_map = {
            'AZURE_CONFIG_ACCESS':  'AzureConfigManager',
            'AWS_CONFIG_ACCESS':  'AwsConfigManager',
            'GCP_CONFIG_ACCESS': 'GCPConfigManager',
            'PC_CONFIG_ACCESS': 'PCConfigManager',
            'AZURE_DATABASE_ACCESS': 'PostgresqlAccess',
            'AWS_DATABASE_ACCESS':  'RedshiftAccess',
            'GCP_DATABASE_ACCESS': 'BigQueryAccess',
            'PC_DATABASE_ACCESS': 'DBAccess',
            'AZURE_STORAGE_ACCESS': 'BlobAccess',
            'AWS_STORAGE_ACCESS':  'S3Access',
            'GCP_STORAGE_ACCESS': 'GCSAccess',
            'PC_STORAGE_ACCESS': 'PCAccess',
            # Engine related classes
            'AZURE_ENGINE_QUERY_ACCESS':  'QueryAccess',
            'AWS_ENGINE_QUERY_ACCESS':  'AthenaAccess',
            'GCP_ENGINE_QUERY_ACCESS':  'GCPQueryAccess',
            'PC_ENGINE_QUERY_ACCESS': 'QueryAccess'
            }
        
        module = 'dal.'+ cloud_provider.lower()
        
        # Constructors of ClassLoader(module, submodule, toolname) are passed to get the corresponding class
        # Eg: ClassLoader('dal.aws', AwsConfigManager, Jira)
        configManager_obj = ClassLoader(module, class_map.get(cloud_provider + '_CONFIG_ACCESS'), tool_name).get_classLoader_access()
        self.configManager_access = configManager_obj(cloud_provider, tool_name)
        self.configKeyValues = self.configManager_access.get_key_values()
        
        storage_obj = ClassLoader(module, class_map.get(cloud_provider + '_STORAGE_ACCESS'), tool_name).get_classLoader_access()
        self.storage_access = storage_obj(tool_name, self.configKeyValues)

        database_obj = ClassLoader(module, class_map.get(cloud_provider + '_DATABASE_ACCESS'), tool_name).get_classLoader_access()
        self.database_access = database_obj(tool_name, self.configKeyValues)

        engineQuery_obj = ClassLoader(module, class_map.get(cloud_provider + '_ENGINE_QUERY_ACCESS'), tool_name).get_classLoader_access()
        self.engineQuery_access = engineQuery_obj(tool_name, self.configKeyValues)
     
    def get_config_manager_access(self):
        return self.configManager_access

    def get_config_key_values(self):
        return self.configKeyValues

    def get_database_access(self):
        return self.database_access

    def get_storage_access(self):
        return self.storage_access
    
    def get_engineQuery_access(self):
        return self.engineQuery_access