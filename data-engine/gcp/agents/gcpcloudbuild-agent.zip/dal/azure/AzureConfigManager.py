import os
from azure.keyvault.secrets import SecretClient
from azure.identity import ManagedIdentityCredential
from dal.IDataAccess import IConfigManager
from utils.FileUtils import FileUtils
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.AzureServiceExceptionUtils import azure_service_exception_handler

class AzureConfigManager(IConfigManager):
    @azure_service_exception_handler
    def __init__(self, provider, tool_name):
        self.logger = FlowsourceLogger(tool_name)
        self.fileUtils = FileUtils()
        self.config = self.fileUtils.loadFile('config.json')
        self.cloud_provider = provider
        client_id = os.environ['AZURE_CLIENT_ID']
        self.credential = ManagedIdentityCredential(client_id=client_id)
        self.client = SecretClient(
            vault_url=os.environ['CREDENTIAL_MANAGER_ENDPOINT'],
            credential=self.credential)

    def get_azure_config_manager(self):
        secrets = self.client.list_properties_of_secrets()
        config_json = {}
        for secret_properties in secrets:
            secret = self.client.get_secret(secret_properties.name)
            config_json[secret_properties.name] = secret.value
        return config_json

    @azure_service_exception_handler
    def check_secret_exists(self):
        try:
            self.client.list_properties_of_secrets()
        except Exception as e:
            raise KeyError(
                "FLOWSOURCE_HEALTH_CHECK_ERROR: AZURE Secret Manager Error: " + e
            )

    # INTERFACE IMPL
    @azure_service_exception_handler
    def get_key_values(self):
        self.configManager = self.get_azure_config_manager()
        return self.configManager
