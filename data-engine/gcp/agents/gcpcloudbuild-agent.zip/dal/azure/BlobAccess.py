from base64 import encode
from azure.storage.blob import BlobServiceClient
from azure.identity import ManagedIdentityCredential
from dal.IDataAccess import IStorageAccess
from azure.core.exceptions import AzureError
from utils.FlowsourceLogger import FlowsourceLogger
import json
import os
from utils.exceptions.AzureServiceExceptionUtils import azure_service_exception_handler


class BlobAccess(IStorageAccess):
    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        client_id = os.environ['AZURE_CLIENT_ID']
        account_url = keyValues['STORAGE-ACCOUNT-URL']
        self.create_blob_client(account_url, client_id)
        
    @azure_service_exception_handler
    def create_blob_client(self, account_url, client_id):
        try:
            credential = ManagedIdentityCredential(client_id=client_id)
            self.blob_service_client = BlobServiceClient(account_url=account_url, credential=credential)
        except AzureError as e:
            self.logger.exception(f"Authentication failed: {e}")
            raise e
        except Exception as e:
            return None

    ########################## AGENT FUNCTIONS #########################
    # For agent to upload JSON Data
    @azure_service_exception_handler
    def upload_tool_json_to_storage(self, container_name, blob_name, byte_data):
        container_client = self.blob_service_client.get_container_client(
            container_name)
        blob_client = container_client.get_blob_client(blob_name)
        formatted_data = "\n".join(json.dumps(item) for item in byte_data)
        byte_array = formatted_data.encode("utf-8")
        blob_client.upload_blob(byte_array, overwrite=True)

    # INTERFACE IMPL
    @azure_service_exception_handler
    def is_file_exists(self, container_name, blob_name):
        try:
            container_client = self.blob_service_client.get_container_client(
                container_name)
            blob_client = container_client.get_blob_client(blob_name)
            return blob_client.exists()
        except Exception as e:
            self.logger.exception(f"FLOWSOURCE_AZURE_ERROR:Azure invalid container name: \'{container_name}\'")
            raise e

    # INTERFACE IMPL
    # For agent to read tracking JSON 
    @azure_service_exception_handler
    def read_json_from_storage(self, container_name, blob_name):
        container_client = self.blob_service_client.get_container_client(
            container_name)
        blob_client = container_client.get_blob_client(blob_name)
        byte_data = blob_client.download_blob().readall()
        jsonData = json.loads(byte_data)
        return jsonData

    # INTERFACE IMPL
    # For agent to update tracking JSON 
    @azure_service_exception_handler
    def write_json_to_storage(self, container_name, blob_name, byte_data):
        container_client = self.blob_service_client.get_container_client(
            container_name)
        blob_client = container_client.get_blob_client(blob_name)
        byte_array = json.dumps(byte_data).encode("utf-8")
        blob_client.upload_blob(data=byte_array, overwrite=True)

    # INTERFACE IMPL
    @azure_service_exception_handler
    def is_storage_exists(self, container_name):
        self.blob_service_client.get_container_client(container_name)
        return True
    
    ########################## ENGINE FUNCTIONS ######################### 
    # Specially for engine to download JSON Data
    @azure_service_exception_handler
    def read_tool_json_from_storage(self, container_name, blob_name):
        container_client = self.blob_service_client.get_container_client(
            container_name)
        blob_client = container_client.get_blob_client(blob_name)
        #readall() is not supporting encode so decode then encode the data
        json_data = blob_client.download_blob().readall()
        self.logger.info("JSON DATA DOWNLOADED FROM BLOB STORAGE!")
        return json_data
    
    # INTERFACE IMPL
    @azure_service_exception_handler
    def copy_storage_object(self, source_container_name, source_blob_name, destination_blob_name):
        source_blob_client = self.blob_service_client.get_blob_client(container=source_container_name, blob=source_blob_name)
        destination_blob_client = self.blob_service_client.get_blob_client(container=source_container_name, blob=destination_blob_name)
        destination_blob_client.start_copy_from_url(source_blob_client.url)            
        self.logger.info(f"In Azure Blob Storage, file copied and renamed from {source_blob_name} to {destination_blob_name}")
       
    # INTERFACE IMPL
    @azure_service_exception_handler
    def delete_storage_object(self, container_name, blob_name):
        blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)
        blob_client.delete_blob()
        self.logger.info(f"Deleted Azure Blob Storage object: {blob_name}")
