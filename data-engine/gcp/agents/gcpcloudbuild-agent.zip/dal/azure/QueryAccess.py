class QueryAccess:
    
    def __init__(self, tool_name, keyValues):
        pass
