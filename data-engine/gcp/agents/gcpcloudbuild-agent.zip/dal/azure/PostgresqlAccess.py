import asyncio
import io
from sqlite3 import connect
import asyncpg
import os
from dal.IDataAccess import IDatabaseAccess
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.PostgresExceptionUtils import postgres_exception_handler


class PostgresqlAccess(IDatabaseAccess):
    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.tool_name = tool_name
        self.keyValues = keyValues
        self.database_name = os.environ["DATABASE_NAME"]

    async def connect_to_postgresql(self):
        conn = await asyncpg.connect(user=self.keyValues['DB-UN'],
                                     password=self.keyValues['DB-PS'],
                                     database=self.database_name,
                                     host=self.keyValues['DB-HOST'])
        return conn

    async def run(self, query):
        conn = None
        try:
            conn = await self.connect_to_postgresql()
            result = await conn.fetch(query)
            return result
        except Exception as e:
            raise e
        finally:
            if conn:
                await conn.close()

    def format_record_from_postgres(self, records):
        result = []
        for record in records:
            values = list(record.values())
            result.append(values)
        return result

    # INTERFACE IMPL
    @postgres_exception_handler
    def check_db_conn(self):
        conn = None
        try:
            conn = self.connect_to_postgresql()
        except Exception as e:
            raise KeyError('Error connecting to Postgresql: ' + e)
        finally:
            if conn:
                conn.close()

    # INTERFACE IMPL
    @postgres_exception_handler
    def fetch_catalog_data_from_db(self, select_query):
        self.logger.info('Fetch data from Postgresql ...')
        records = asyncio.run(self.run(select_query))
        result = self.format_record_from_postgres(records)
        return result

    # Engine side queries to be executed in postgresql
    @postgres_exception_handler
    def execute_query_in_postgresql(self, query):
        self.logger.info("Executing queries in PostgreSQL...")
        try:
            asyncio.run(self.run(query))
            self.logger.info(f"Successfully Executed Query!")
        except Exception as e:
            self.logger.exception(f"Error executing query: {e}")
            raise e

    @postgres_exception_handler
    def copy_json_data_to_db(self, json_data, temp_table_name,  query):
        self.logger.info('Copying JSON data to Database...')
        asyncio.run(self._copy_json_data_to_db_async(
            json_data, temp_table_name, query))

    async def _copy_json_data_to_db_async(self, json_data, temp_table_name, query):
        conn = None
        try:
            self.logger.info(f"Temporary Table Name - {temp_table_name}")
            # Use an in-memory file-like object
            json_file_like = io.BytesIO(json_data)
            conn = await self.connect_to_postgresql()
            await conn.execute(f''' CREATE TEMP TABLE {temp_table_name} (
                data JSONB)USING COLUMNAR
            ''')
            self.logger.info("Temporary Table Created Successfully")
            await conn.copy_to_table(f"{temp_table_name}", source=json_file_like, format='text')
            self.logger.info("Copied to Temp Table Successfully!")
            await conn.execute(query)
            self.logger.info("Inserted/Merged to Main Table Successfully!")
        except Exception as e:
            self.logger.exception(f"Exception occurred in copying {e}")
            raise e
        finally:
            self.logger.info("Closing the connection...")
            if conn:
                await conn.close()

    @postgres_exception_handler
    def delete_temp_table(self, temp_table):
        self.logger.info(f"Deleting Temp table {temp_table}...")
        try:
            asyncio.run(self._delete_temp_table_async(temp_table))
        except Exception as e:
            self.logger.exception(
                f"FLOWSOURCE_POSTGRESQL_ACCESS_EXCEPTION: Error deleting table {temp_table}: {e}")
            raise e

    async def _delete_temp_table_async(self, temp_table):
        conn = None
        try:
            conn = await self.connect_to_postgresql()
            await conn.execute(f"DROP TABLE IF EXISTS {temp_table}")
            self.logger.info(f"Table {temp_table} deleted successfully.")
        except Exception as e:
            raise e
        finally:
            if conn:
                await conn.close()

    # INTERFACE IMPL
    def load_json_data_to_staging_table(self, json_data, temp_table):
        pass

    # INTERFACE IMPL
    def delete_staging_table(self, temp_table):
        pass
