from google.cloud import storage
from google.auth.exceptions import GoogleAuthError
import json
from dal.IDataAccess import IStorageAccess
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.GCPServiceExceptionUtils import gcp_service_exception_handler

class GCSAccess(IStorageAccess):
    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.keyValues = keyValues
        self.create_gcs_client()
    
    @gcp_service_exception_handler
    def create_gcs_client(self):
        try:
            self.client = storage.Client()
        except GoogleAuthError as e:
            self.logger.exception(f"Authentication failed: {e}")
            raise e
        except Exception as e:
            return None
    
    ########################## AGENT FUNCTIONS #########################
    @gcp_service_exception_handler
    def upload_tool_json_to_storage(self, bucket_name, object_name, data):
        self.logger.info(f"Uploading File to GCS bucket: {bucket_name}, object: {object_name}")
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(object_name)
        filedata = "\n".join(str(obj) for obj in data)
        byte_array = bytes(filedata, "utf-8")
        blob.upload_from_string(byte_array)
        self.logger.info("Uploading File to GCS is done ...")
    
    # INTERFACE IMPL
    @gcp_service_exception_handler
    def is_file_exists(self, bucket_name, object_name):
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(object_name)
        exists = blob.exists()
        if exists:
            self.logger.info(f"Object: {object_name} Exists")
        else:
            self.logger.error(f"FLOWSOURCE_GCS_ACCESS_ERROR: Object: {object_name} Not Found")
        return exists
    
    # INTERFACE IMPL
    @gcp_service_exception_handler
    def read_json_from_storage(self, bucket_name, object_name):
        if not self.is_file_exists(bucket_name, object_name):
            data = {}  # An empty dictionary (JSON object)
            self.write_to_storage(bucket_name, object_name, data)
        tracking_info = self.get_gcs_object(bucket_name, object_name)
        self.logger.info(f"Data read from GCS bucket: {bucket_name}, object: {object_name}, data: {tracking_info}")
        return tracking_info
    
    # INTERFACE IMPL
    @gcp_service_exception_handler
    def write_json_to_storage(self, bucket_name, object_name, data):
        self.logger.info(f"Updating JSON in GCS bucket: {bucket_name}, object: {object_name}")
        json_string = json.dumps(data)
        byte_array = json_string.encode("utf-8")
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(object_name)
        blob.upload_from_string(byte_array)
        self.logger.info("Updating JSON in GCS is done ...")
    
    # INTERFACE IMPL
    @gcp_service_exception_handler
    def is_storage_exists(self, bucket_name):
        bucket = self.client.bucket(bucket_name)
        exists = bucket.exists()
        if not exists:
            raise KeyError(f"FLOWSOURCE_GCS_ACCESS_ERROR: Bucket: {bucket_name} does not exist")
        return exists
    
    ########################## ENGINE FUNCTIONS ######################### 
    # INTERFACE IMPL
    @gcp_service_exception_handler
    def copy_storage_object(self, bucket_name, source_object_name, destination_object_name):
        self.logger.info("Copying GCS object...")
        source_bucket = self.client.bucket(bucket_name)
        source_blob = source_bucket.blob(source_object_name)
        destination_bucket = self.client.bucket(bucket_name)
        destination_generation_match_precondition = 0
        source_bucket.copy_blob(source_blob, destination_bucket, destination_object_name, if_generation_match=destination_generation_match_precondition, )
        self.logger.info(f"In GCS, file copied and renamed from {source_object_name} to {destination_object_name}")

    # INTERFACE IMPL
    @gcp_service_exception_handler
    def delete_storage_object(self, bucket_name, object_name):
        self.logger.info("Deleting GCS object...")
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(object_name)
        blob.delete()
        self.logger.info(f"Deleted GCS object: {object_name}")

    @gcp_service_exception_handler 
    def get_gcs_object(self, bucket_name, object_name):
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(object_name)
        content = blob.download_as_text()
        json_content = json.loads(content)
        return json_content