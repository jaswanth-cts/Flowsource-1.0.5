from google.cloud import bigquery
from dal.IDataAccess import IDatabaseAccess
import os
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.BigQueryExceptionUtils import bigquery_exception_handler

class BigQueryAccess(IDatabaseAccess):
    def __init__(self, tool_name, keyValues):
        self.logger = FlowsourceLogger(tool_name)
        self.keyValues = keyValues
        self.dataset_id = os.environ["DATABASE_NAME"]

    @bigquery_exception_handler
    def create_bigquery_client(self):
        return bigquery.Client()

    #Engine side Queries to be execute in bigquery 
    @bigquery_exception_handler
    def execute_query_in_bigquery(self, query):
        bigquery_client = None
        try:
            bigquery_client = self.create_bigquery_client()
            query_job = bigquery_client.query(query)
            query_job.result()
        except Exception as e:
            self.logger.exception(f"Error executing query: {e}")
            raise e
        finally:
            if bigquery_client:
                bigquery_client.close()

    # INTERFACE IMPL
    @bigquery_exception_handler
    def load_json_data_to_staging_table(self, gcs_uri, staging_table):
        self.logger.info(f"Inserting json data to staging table {staging_table}")
        bigquery_client = None
        try:
            bigquery_client = self.create_bigquery_client()
            job_config = bigquery.LoadJobConfig(
            source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
            ignore_unknown_values = True
            )
            load_job = bigquery_client.load_table_from_uri(
                gcs_uri,
                staging_table,
                job_config=job_config
                ) 
            load_job.result()
        except Exception as e:
            self.logger.exception(f"FLOWSOURCE_BIG_QUERY_ACCESS_EXCEPTION: Exception occurred while inserting data to staging table {e}")
        finally:
            if bigquery_client:
                bigquery_client.close()

    # INTERFACE IMPL
    @bigquery_exception_handler
    def delete_staging_table(self, staging_table):
        bigquery_client = None
        try:
            bigquery_client = self.create_bigquery_client()
            bigquery_client.delete_table(staging_table, not_found_ok=True)
            self.logger.info(f"Table {staging_table} deleted successfully.")
        except Exception as e:
            self.logger.exception(f"FLOWSOURCE_BIG_QUERY_ACCESS_EXCEPTION: Error deleting table {staging_table}: {e}")
        finally:
            if bigquery_client:
                bigquery_client.close()

    # INTERFACE IMPL
    @bigquery_exception_handler
    def check_db_conn(self):
        bigquery_client = None
        try:
            bigquery_client = self.create_bigquery_client()
        except Exception as e:
            raise KeyError(f"Error connecting to BigQuery: {e}")
        finally:
            if bigquery_client:
                bigquery_client.close()
        
    # INTERFACE IMPL
    @bigquery_exception_handler
    def fetch_catalog_data_from_db(self, select_query):
        self.logger.info("Fetching data from BigQuery ...")
        bigquery_client = None
        try:
            bigquery_client = self.create_bigquery_client()
            result = []
            formatted_query = select_query.format(DATASET_ID=self.dataset_id)
            query_job = bigquery_client.query(formatted_query)
            for row in query_job.result():
                values = list(row)
                result.append(values)
            return result
        except Exception as e:
            self.logger.exception(f"Error fetching data from BigQuery: {e}")
            raise e
        finally:
            if bigquery_client:
                bigquery_client.close()
