class GCPQueryAccess:
    
    def __init__(self, tool_name, keyValues):
        pass
