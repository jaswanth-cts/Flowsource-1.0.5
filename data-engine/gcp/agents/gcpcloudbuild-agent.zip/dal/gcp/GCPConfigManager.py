import os
from google.cloud import secretmanager
from dal.IDataAccess import IConfigManager
from utils.FileUtils import FileUtils
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.GCPServiceExceptionUtils import gcp_service_exception_handler

class GCPConfigManager(IConfigManager):
    @gcp_service_exception_handler
    def __init__(self, provider, tool_name):
        self.logger = FlowsourceLogger(tool_name)
        self.fileUtils = FileUtils()
        self.config = self.fileUtils.loadFile('config.json')
        self.cloud_provider = provider
        self.project_id = os.environ["GCP_PROJECT_ID"]
        self.secret_manager_client = secretmanager.SecretManagerServiceClient()
        self.gcp_sec_names = self.config.get(
            self.cloud_provider, {}).get("configManager", [])
    
    @gcp_service_exception_handler
    def get_gcp_config_manager(self):
        config_json = {}
        for sec_name in self.gcp_sec_names:
            self.logger.info(f"Fetching fields for {sec_name} ...")
            sec_path = f"projects/{self.project_id}/secrets/{sec_name}/versions/latest"
            response = self.secret_manager_client.access_secret_version(request={"name": sec_path})
            sec_data = response.payload.data.decode("utf-8")
            config_json.update({sec_name: sec_data})
        return config_json
    
    @gcp_service_exception_handler
    def check_secret_exists(self):
        try:
            for sec_name in self.gcp_sec_names:
                sec_path = f"projects/{self.project_id}/secrets/{sec_name}/versions/latest"
                self.secret_manager_client.access_secret_version(request={"name": sec_path})
        except Exception as e:
            raise KeyError(
                "FLOWSOURCE_HEALTH_CHECK_ERROR: GCP Secret Manager Error: " + str(e)
            )
    
    # INTERFACE IMPL
    def get_key_values(self):
        self.configManager = self.get_gcp_config_manager()
        return self.configManager