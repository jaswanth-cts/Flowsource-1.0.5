import os
import json
from datetime import datetime,timezone,timedelta
import pytz 
from rest_api.CommunicationFacade import CommunicationFacade
from rest_api.RestCommunicationFacade import RestCommunicationFacade
import uuid
from utils.TimeUtils import TimeUtils
from utils.FileUtils import FileUtils
from dal.DataAccessLayer import DataAccessLayer
from utils.FlowsourceLogger import FlowsourceLogger
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class BaseAgent(object):
    def __init__(self, cloud_provider):
        self.cloud_provider = cloud_provider
        self.initializeBaseAgent()
        self.folderPath = self.config.get('folderPath', '')
        self.agentTrackFile = self.config.get('agentTrackPath', '')
        self.trackKey = f'{self.folderPath}/{self.agentTrackFile}'
        # Load tracking file
        self.tracking = self.loadTrackingFile(self.storageName, self.trackKey)
        self.updateTrackingFile(self.tracking)
        self.agentDataFile = f"{self.config.get('toolCategory', '')}{'-'}{self.config.get('toolName', '')}{'-'}{self.config.get('agentId', '')}{'-'}"
        self.flowsourceTimeZone = pytz.timezone('UTC')
        self.toolsTimeZone = pytz.timezone(self.config.get('toolsTimeZone'))
        self.isEpochTime = self.config.get('isEpochTimeFormat', False)
        self.loadCommunicationFacade()

    @flowsource_exception_handler
    def initializeBaseAgent(self):
        self.fileUtils = FileUtils()
        self.config = self.fileUtils.loadFile('config.json')
        self.tool_name = self.config.get('toolName', '')
        dal = DataAccessLayer(self.cloud_provider, self.tool_name)
        self.config_manager = dal.get_config_manager_access()
        self.keyValues = dal.get_config_key_values()
        self.storage_access = dal.get_storage_access()
        self.database_access = dal.get_database_access()
        self.logger = FlowsourceLogger(self.tool_name)
        self.heathChecks()
        timeUtils = TimeUtils()
        # Get relative date from the timeframe given in months
        self.startFromDate  = timeUtils.get_relative_past_date(self.days_to_collect)
        

    def heathChecks(self):
        cred_manager_endpoint = os.environ['CREDENTIAL_MANAGER_ENDPOINT']
        database_name = os.environ['DATABASE_NAME']
        self.baseUrl = os.environ['BASE_URL']
        self.storageName = os.environ['STORAGE_NAME']
        self.days_to_collect = os.environ['DAYS_TO_COLLECT']
        if int(self.days_to_collect) <= 0:
            self.logger.error('FLOWSOURCE_BASEAGENT_ERROR: DAYS_TO_COLLECT should not be 0 or any -ve value')
            raise ValueError('FLOWSOURCE_BASEAGENT_ERROR: DAYS_TO_COLLECT should not be 0 or any -ve value')
        self.config_manager.check_secret_exists()
        self.storage_access.is_storage_exists(self.storageName)
        self.database_access.check_db_conn()
        self.logger.info("FLOWSOURCE_INFO: All health checks passed ...")

    def loadCommunicationFacade(self):
        self.logger.info('FLOWSOURCE_INFO: Inside loadCommunicationFacade ...')
        communicationFacade = CommunicationFacade()
        config = self.config.get('communication', {})
        facadeType = config.get('type', None)
        sslVerify = config.get('sslVerify', True)
        self.responseType = config.get('responseType', 'JSON')
        enableValueArray = self.config.get('enableValueArray', False)
        self.proxies = {}
        enableProxy = self.config.get("enableProxy", False)
        if enableProxy:
            self.proxies = self.config.get("proxies", {})
        else:
            self.proxies = None
        self.communicationFacade = communicationFacade.getCommunicationFacade(facadeType, sslVerify, self.responseType,
                                                                              enableValueArray)

    def getCommunicationFacade(self, facadeType, sslVerify, responseType, enableValueArray):
        if 'REST' == facadeType:
            return RestCommunicationFacade(sslVerify, responseType, enableValueArray)
        else:
            self.logger.error('FLOWSOURCE_BASEAGENT_ERROR: CommunicationFacade: Unsupported Facade Type '+ facadeType)
            raise ValueError(
                'FLOWSOURCE_BASEAGENT_ERROR: CommunicationFacade: Unsupported Facade Type '+facadeType)

    def getResponse(self, url, method, usr, cred, data, aType='BASIC', reqHeaders=None, responseTupple=None,
                    proxiesParam=None):
        return self.communicationFacade.communicate(url, method, usr, cred, data, aType, reqHeaders,
                                                    responseTupple, proxies=self.proxies)

    def parseResponse(self, template, response, injectData={}):
        return self.communicationFacade.processResponse(template, response, injectData,
                                                        self.config.get('useResponseTemplate', False))

    def getCredential(self, key):
        return self.config.get(key, None)

    def getResponseTemplate(self):
        return self.config.get('dynamicTemplate', {}).get('responseTemplate', None)

    def buildApiParameters(self, keyName, valueObject):
        valueType = type(valueObject)
        urlToken = None
        if valueType is dict:
            urlToken = keyName + '['
            for key in valueObject:
                urlToken += self.buildApiParameters(key,
                                                    valueObject[key]) + ','
            urlToken = urlToken[:-1] + ']'
        elif valueType is list:
            urlToken = self.buildApiParameters(keyName, valueObject[0])
        elif valueType is str:
            urlToken = keyName
        return urlToken

    def publishToolsData(self, data, fileType=None):
        self.logger.info("FLOWSOURCE_INFO: Publishing tools data ...")
        
        if data:
            self.addTimeStampField(data)
            epoch_time = int(datetime.now().timestamp()*1000)
            file_name = f"{self.folderPath}/{self.agentDataFile}{fileType}{'-'}{str(epoch_time)}.json"
            self.storage_access.upload_tool_json_to_storage(
                self.storageName, file_name, data)

    def getRemoteDateTime(self, time):
        if time.tzinfo is None:
            self.logger.warn("FLOWSOURCE_BASEAGENT_WARNING: Time zone info is null hence replacing it with UTC")
            time = time.replace(tzinfo=timezone.utc)
        utc_time = time.astimezone(timezone.utc)
        response = {
            'epochTime': int(utc_time.timestamp()),            
            'utcDatetime': utc_time.strftime('%Y-%m-%dT%H:%M:%SZ')
        }
        return response

    def loadTrackingFile(self, storageName, agentTrackFile):
        if (self.storage_access.is_file_exists(storageName, agentTrackFile) is False):
            data = {}  # An empty dictionary (JSON object)
            self.storage_access.write_json_to_storage(
                storageName, agentTrackFile, data)
        trackingInfo = self.storage_access.read_json_from_storage(
            storageName, agentTrackFile)
        self.logger.info(
            f"FLOWSOURCE_INFO: Data written to Storage: {storageName}, file: {agentTrackFile} data: {trackingInfo}")
        return trackingInfo

    def publishData(self,data,fileType=None,batchSize=None,is_residual=False,tracking=None):
         if len(data) >= batchSize or is_residual:
            self.publishToolsData(data, fileType=fileType)
            self.updateTrackingFile(tracking)
            data.clear()
    
    def updateTrackingFile(self,tracking):
        self.storage_access.write_json_to_storage(
        self.storageName, self.trackKey, tracking
        )

    def fetchCatalogData(self, select_query):
        self.logger.info('FLOWSOURCE_INFO: Fetching the Catalog Data ...')
        catalogData = self.database_access.fetch_catalog_data_from_db(
            select_query)
        if (len(catalogData) == 0):
            self.logger.error('4002 - FLOWSOURCE_BASEAGENT_ERROR: fetch_catalog_data: No records found in catalog table ...')
            raise ValueError('4002 - FLOWSOURCE_BASEAGENT_ERROR: fetch_catalog_data: No records found in catalog table ...')
        return catalogData

    def addTimeStampField(self, data):
        
        timeStampField = self.config.get('timeStampField', '')
        batchID = str(uuid.uuid4())
        for jsonObj in data:
            eventTime = jsonObj.get(timeStampField, '')                
            if eventTime != None:
                timeResponse = None
                if self.isEpochTime:
                    eventTime = str(eventTime)
                    eventTime = int(eventTime[:10])
                    timeResponse = self.getRemoteDateTime(
                    datetime.fromtimestamp(eventTime, tz=timezone.utc))
                else:
                    timeStampFormat = self.config.get('timeStampFormat')
                    timeResponse = self.getRemoteDateTime(
                        datetime.strptime(eventTime, timeStampFormat))
            else:
                timeResponse = self.getRemoteDateTime(datetime.now())

            jsonObj['flowsourceTime'] = timeResponse['epochTime']
            jsonObj['flowsourceTimeX'] = timeResponse['utcDatetime']
            jsonObj['categoryName'] = self.config.get('toolCategory')
            jsonObj['toolName'] = self.config.get('toolName')
            jsonObj['id'] = str(uuid.uuid4())
            jsonObj['batchID'] = batchID

    def getEndTime(self,startTime,batchCollectDays,timeFormat= '%Y-%m-%d %H:%M:%S',type='epoch'):
        currentTime = datetime.now(self.toolsTimeZone).strftime(timeFormat)
        if type == 'dateTime':
            startTimeDate = datetime.strptime(startTime, timeFormat)
            # Calculate the difference in days between lastUpdated current date
            currentTimeDate=datetime.strptime(currentTime, timeFormat)
            day_difference = (currentTimeDate - startTimeDate).days 
            # Get end date from startTime with batchCollectDays
            if day_difference > batchCollectDays and batchCollectDays > 0 :
                endTime = (startTimeDate + timedelta(days=batchCollectDays)).strftime(timeFormat)
            else:
                endTime = currentTime
        elif type == 'epoch':
            # Converting tracking lastUpdatedEpoch to startDateObj
            startTime = startTime if len(str(startTime)) == 10 else startTime // 1000
            startDateObj = datetime.fromtimestamp(startTime)
            # Calculate the days difference between current date & tracking lastUpdated
            currentTimeDate=datetime.strptime(currentTime, timeFormat)
            daysDifference = (currentTimeDate - startDateObj).days 
            # Calculate endTimeEpoch 
            if daysDifference > batchCollectDays and batchCollectDays > 0 :
                endTime = int((startDateObj + timedelta(days=batchCollectDays)).timestamp())
            else:
                endTime = int(datetime.strptime(currentTime, timeFormat).timestamp())

        return endTime