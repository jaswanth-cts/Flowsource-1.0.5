from GCPCloudBuild import GCPCloudBuild
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def gcpcloudbuild_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = GCPCloudBuild(cloud_provider)
        agent.process()  # Calling the import GCPCloudBuild process
        logging.info(f'GCPCloudBuild executed successfully ...')
        return "GCPCloudBuildAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing GCPCloudBuild agent: {str(e)}')
