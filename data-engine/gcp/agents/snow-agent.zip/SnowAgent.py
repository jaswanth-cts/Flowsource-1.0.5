from datetime import datetime,timedelta
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class SnowAgent(BaseAgent):

    @flowsource_exception_handler
    def process(self):
        self.logger.info('Inside  process ...')

        # Load configurations and initialize
        self.loadConfiguration()

        # Fetch catalog data 
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tool data and update tracking file
        self.process_tool_data() 

    def loadConfiguration(self):
        #load common agent config variables
        #Retrieve the query to fetch catalog Data as per the cloud Provider 
        self.select_query= self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        # Set batch size for publishing
        self.batchSize = self.config.get('batchSize', 1000)
        self.inputTimeFormat = "%Y-%m-%d %H:%M:%S"
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        self.batchCollectDays = self.config.get("batchCollectDays", 30)
        
        #agent specific variables
        # Retrieve configurations
        self.snowId = self.config.get(self.cloud_provider, "").get("snowId", "")
        self.snowPs = self.config.get(self.cloud_provider, "").get("snowPs", "") 
        # Fetch URLs from config
        self.IN_Url = self.config.get("IN_Url", '')
        self.IN_label_url = self.config.get("IN_label_url", '')
        self.enableChangeRequest = self.config.get("enableChangeRequest", '')
        #load responseTemplate from dynamicTemplate in config.json
        self.responseTemplate = self.getResponseTemplate()
        self.incidentDataTemplate = self.responseTemplate.get('incidentDataTemplate', {})

       
        if len(self.startFromDate) == 10:  # Only date is provided
            self.startFromDate += " 00:00:00"

    def process_tool_data(self):
        self.logger.info('FLOWSOURCE_INFO: Inside process_tool_data func ...')
        
        # Get ServiceNow credentials
        self.username = self.keyValues[self.snowId]
        self.cred = self.keyValues[self.snowPs]

        # Extract app IDs from catalog data
        self.appids = [row[0] for row in self.catalogData]  

        # Process incident data
        self.process_incident_data()

    def process_incident_data(self):
        self.logger.info('Inside process_incident_data ...')

        # Initialize data structures
        self.incidentResponse = []
        
        # Get start and end time 
        self.startTime,self.end_time = self.get_tracking_last_update()
        
        # Filter incidents based on app IDs
        self.filter_incidents_by_app_ids()

    def get_tracking_last_update(self):

        if "incident" not in self.tracking:
            self.tracking["incident"] = {"lastUpdated": None}

        # Get the last updated time for incidents from the tracking dictionary
        startTime = self.tracking.get("incident", {}).get("lastUpdated", None)

        # If the start time is not found, use the default startFromDate
        if not startTime:
            startTime = self.startFromDate

        # Get end date from startTime with batchCollectDays
        endTime = self.getEndTime(startTime,self.batchCollectDays,timeFormat= '%Y-%m-%d %H:%M:%S',type='dateTime')

        # Return both start and end time
        return startTime,endTime

    
    def filter_incidents_by_app_ids(self):
        self.logger.info("Inside filter_incidents_by_app_ids method ...")
        # Filter incidents based on appids and time range
        base_url = f"{self.baseUrl}{self.IN_label_url}%27{self.startTime}%27)%40javascript%3Ags.dateGenerate(%27{self.end_time}%27)"
        max_url_length = 1800

        # The part of the URL after the '?' which will remain constant
        base_query_part = base_url[base_url.index("?"):]  # Calculated once

        #the constant part of the url
        constant_length = len(base_query_part)
        # List to hold current keys
        current_keys = []

        for key in self.appids:
            if not current_keys:
                # For the first key, don't add ^OR
                new_query_part = f"^label.name%3Dappid%3A{key}"
            else:
                # For subsequent keys, use ^ORsys_id
                new_query_part = f"^ORlabel.name%3Dappid%3A{key}"

            # Check if adding the new part exceeds the length limit
            if constant_length + len(''.join(current_keys)) + len(new_query_part) > max_url_length:
                # Make the API call with the current keys
                query = f"{base_url}{''.join(current_keys)}"   
                # Example built URL:
                # Assuming startTime: '2024-01-01 00:00:00'
                # Assuming endTime: '2024-06-27 12:00:00'
                # Example appid_query:
                # "label.name=appid:TicketBooking^ORlabel.name=appid:Petclinic"
                # https://<BASE_URL>/api/now/table/label_entry?sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_query=sys_updated_onBETWEENjavascript:gs.dateGenerate('2024-01-01 00:00:00')%40javascript:gs.dateGenerate('2024-06-27 12:00:00')^label.name=appid:TicketBooking^ORlabel.name=appid:Petclinic
        
                IN_filter_response = self.getResponse(query, 'GET', self.username, self.cred, None)

                # Extract table keys and retrieve incident information
                table_keys = self.extract_table_keys(IN_filter_response)
                self.retrieve_incident_details(table_keys)

                # Start a new batch with the current appid
                current_keys = [f"^label.name%3Dappid%3A{key}"]  
            else:
                current_keys.append(new_query_part)  # Add to the current batch

        # Final API call for any remaining keys
        if current_keys:
            query = f"{base_url}{''.join(current_keys)}"
            IN_filter_response = self.getResponse(query, 'GET', self.username, self.cred, None)
            # Extract table keys from the filtered incidents
            table_keys = self.extract_table_keys(IN_filter_response)
            self.retrieve_incident_details(table_keys)

        # Final tracking update after processing all batches to ensure end_time is updated,
        # and we capture any missed data that might not have been handled in previous batches.
        self.update_tracking_data()
        self.updateTrackingFile(self.tracking)

    def extract_table_keys(self, data):
        # Extract table keys from incident response
        return [entry['table_key'] for entry in data['result']]

    def retrieve_incident_details(self, table_keys):
        self.logger.info("Inside retrieve_incident_details method ...")

        # Base incident detail URL with static parameters
        # Priority is set to 1 and 2, representing high and critical incidents. (Ex. priorityIN1,2)
        # For debugging, you can change it to 3 or 4, where 3 represents medium and 4 represents low priority incidents.
        base_url = f"{self.baseUrl}{self.IN_Url}%27{self.startTime}%27)%40javascript%3Ags.dateGenerate(%27{self.end_time}%27)^ORclosed_atBETWEENjavascript%3Ags.dateGenerate(%27{self.startTime}%27)%40javascript%3Ags.dateGenerate(%27{self.end_time}%27)^priorityIN1,2"
        max_url_length = 1800

        # The part of the URL after the '?' which will remain constant
        base_query_part = base_url[base_url.index("?"):]  # Calculated once

        #the constant part length (excluding dynamic sys_id keys)
        constant_length = len(base_query_part)
        # List to hold current keys
        current_keys = []

        for key in table_keys:
            if not current_keys:
                # For the first key, don't add ^OR
                new_query_part = f"^sys_id%3D{key}"
            else:
                # For subsequent keys, use ^ORsys_id
                new_query_part = f"^ORsys_id%3D{key}"

            # Check if adding the new part exceeds the length limit
            if constant_length + len(''.join(current_keys)) + len(new_query_part) > max_url_length:
                # Make the API call with the current keys
                query = f"{base_url}{''.join(current_keys)}"
                incident_detail_response = self.getResponse(query, 'GET', self.username, self.cred, None)
                self.extract_incident_details(incident_detail_response)

                # Reset current keys; if current_keys is empty, start fresh with new_query_part
                # current_keys = [new_query_part] if not current_keys else [new_query_part]
                # Reset current keys; start fresh with the first sys_id for the new batch
                current_keys = [f"^sys_id%3D{key}"]  # Always start with sys_id
            else:
                current_keys.append(new_query_part)  # Add to the current batch

        # Final API call for any remaining keys
        if current_keys:
            query = f"{base_url}{''.join(current_keys)}"
            incident_detail_response = self.getResponse(query, 'GET', self.username, self.cred, None)
            self.extract_incident_details(incident_detail_response)
    

    def extract_incident_details(self,in_detail_response):
        self.logger.info("Inside extract_incident_details method ...")

        # Process and publish incident data for the current batch
        for data in in_detail_response['result']:
            self.incidentData = {}
            eventTime = datetime.strptime(data['opened_at'],self.inputTimeFormat)

            # Collect incident data
            injectData = {
                'openedDateEpoch': int(eventTime.timestamp()),
                'priority': data.get('priority', "").split("-")[1].strip()
            }
            
            # Handle closed_at field if present
            if data.get('closed_at'):
                closedtime = datetime.strptime(data['closed_at'], self.inputTimeFormat)
                injectData['closedDateEpoch'] = int(closedtime.timestamp())

            # Parse tags for additional information
            if data.get("sys_tags"):
                # Split the sys_tags string by commas to get individual tags
                for tag in data.get("sys_tags").split(','):
                    # Check if the tag contains a colon
                    if ":" in tag:
                        # Split the tag into key and value parts
                        key_value = tag.split(":")
                        # Ensure there are exactly two parts after splitting (key and value)
                        if len(key_value) == 2:
                            key, value = key_value
                            # Iterate over the tags defined in the incidentDataTemplate
                            for template_key, inject_key in self.incidentDataTemplate.get('tags', {}).items():
                                # Check if the key from the tag matches the template key
                                if template_key == key.strip():
                                    # Assign the value to the corresponding key in injectData
                                    injectData[inject_key] = value.strip()
                                    # Break the loop once a match is found
                                    break


            self.incidentData = self.parseResponse(self.incidentDataTemplate, data, injectData)
            self.incidentResponse.append(self.incidentData[0])
            self.update_tracking_data()
            self.publishData(self.incidentResponse, 'Incident', self.batchSize, False, self.tracking)
            # Check if incident needs a "New" state record
            if data['closed_at'] and self.is_within_period(data['opened_at'], self.startTime, self.end_time):
                new_incident_data = self.incidentData[0].copy()
                new_incident_data['state'] = 'New'
                new_incident_data['closedAt'] = ''
                del new_incident_data['closedDateEpoch']
                self.incidentResponse.append(new_incident_data)
                self.update_tracking_data()
                self.publishData(self.incidentResponse, 'Incident', self.batchSize, False, self.tracking) #This publish is called to ensure the batching size remians consistent for the new record added
 # Publish remaining incident data
        if len(self.incidentResponse) > 0:
            self.publishData(self.incidentResponse, 'Incident', batchSize=self.batchSize, is_residual=True, tracking=self.tracking)

    
    def update_tracking_data(self):
        #This function is intended to be called at the end of the batch processing to ensure that any missed data or cases where no data was available in certain batches are still captured.
        #`self.end_time` here represents the current time
        self.tracking["incident"]["lastUpdated"] = self.end_time
    
    def is_within_period(self, date_str, start_time, end_time):
        #Check if a date is within the specified period.
        date_format = '%Y-%m-%d %H:%M:%S'
        date = datetime.strptime(date_str.split('.')[0], date_format)
        start = datetime.strptime(start_time.split('.')[0], date_format)
        end = datetime.strptime(end_time.split('.')[0], date_format)
        return start <= date <= end
    