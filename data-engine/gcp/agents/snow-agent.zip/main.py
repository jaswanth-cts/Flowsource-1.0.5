from SnowAgent import SnowAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def snow_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = SnowAgent(cloud_provider)
        agent.process()  # Calling the SnowAgent process
        logging.info(f'Snow agent executed successfully ...')
        return "SnowAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Snow agent: {str(e)}')
