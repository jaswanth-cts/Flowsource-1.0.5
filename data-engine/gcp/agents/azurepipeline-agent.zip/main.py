from AzurePipelineAgent import AzurePipelineAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def azurepipeline_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = AzurePipelineAgent(cloud_provider)
        agent.process()  # Calling the import AzurePipelineAgent process
        logging.info(f'AzurePipelineAgent executed successfully ...')
        return "AzurePipelineAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing AzurePipeline agent: {str(e)}')
