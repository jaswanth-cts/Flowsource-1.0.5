from SonarQubeAgent import SonarQubeAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def sonarqube_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = SonarQubeAgent(cloud_provider)
        agent.process()  # Calling the import SonarQubeAgent process
        logging.info(f'SonarQube executed successfully ...')
        return 'SonarQubeAgent process executed'

    except Exception as e:
        logging.error(f'ERROR while executing SonarQube agent: {str(e)}')
