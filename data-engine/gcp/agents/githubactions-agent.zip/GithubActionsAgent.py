from jose import jwt
import time
import base64
from datetime import datetime, timezone
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
import re

class GithubActionsAgent(BaseAgent):

    @flowsource_exception_handler    
    def process(self):
        self.logger.info('Inside GitHubActionsAgent process ...')

        # Load configurations and initialize
        self.load_configurations()

        # Fetch catalog data 
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tool data and update tracking file
        self.process_tool_data()

    def load_configurations(self):
        #load common agent config variables
        # Retrieve the query to fetch catalog Data as per the cloud Provider
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get('batchSize', 1000)
        self.inputTimeFormat = "%Y-%m-%dT%H:%M:%S%z"
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000
            
        #agent specific variables
        # Retrieve configurations 
        self.gitHubActionsToken = self.config.get(self.cloud_provider, '').get("gitHubActionsToken", '')
        self.gitHubActionsClientId = self.config.get(self.cloud_provider, "").get("gitHubActionsClientId", "")      
        self.gitHubActionsPrivateKey = self.config.get(self.cloud_provider, "").get("gitHubActionsPrivateKey", "")
        #load responseTemplate from dynamicTemplate in config.json
        self.responseTemplate = self.getResponseTemplate()
        self.runsResponseTemplate = self.responseTemplate.get('runsResponseTemplate', {})

        if len(self.startFromDate) == 10:  # Only date is provided
            self.startFromDate += " 00:00:00"
        dt = datetime.strptime(self.startFromDate, "%Y-%m-%d %H:%M:%S")
        self.startFromDate = dt.strftime("%Y-%m-%dT%H:%M:%SZ")

    def process_tool_data(self):
        self.logger.info("Inside process_tool_data method")
        self.perform_authorization()
        # Process each catalog entry and fetch the corresponding workflows
        for catalog in self.catalogData:
            appid = catalog[0]
            git_owner = catalog[1]
            git_repo = catalog[2]

            # Workflow names from the catalog data, cleaned up
            workflow_names = [name.strip() for name in catalog[3].split(",")]
            self.process_workflows(appid,git_owner, git_repo, workflow_names)

    def perform_authorization(self):
        # Getting githubactions credentials from credential manager & implementing auth headers
        # Assign values from keyValues
        # Retrieve the Client ID and Private Key, or token for authentication
        self.clientId = self.keyValues.get(self.gitHubActionsClientId, '')
        self.privateKey = self.keyValues.get(self.gitHubActionsPrivateKey, '')
        self.privateKey = base64.b64decode(self.privateKey).decode("utf-8")
        # Determine the appropriate authentication method
        if self.clientId.strip() and self.privateKey.strip():      # Check if all required values are present and non-empty
            self.logger.info("Authenticating using client id and private key")
            self.token = self.initialize_github_app()
        else:
            self.logger.info("Authenticating using access token")
            self.token = self.keyValues.get(self.gitHubActionsToken, '')
        # Prepare headers for API requests
        self.headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/json'
        }

    def process_workflows(self,appid, git_owner, git_repo, workflow_names):
        workflows = self.get_workflows(git_owner, git_repo) 
        if not workflows:
            # If no workflows are found, return early as there is nothing to process
            # This could indicate an issue with fetching workflows or simply that there are no workflows available
            return
        # Filter workflows based on names from the catalog
        matching_workflows = self.filter_workflows(workflows, workflow_names)
        # For each matching workflow, fetch the workflow runs
        for workflow in matching_workflows:
            workflow_id = workflow['id']
            workflow_url = workflow['url']
            workflow_name = workflow['name']
            last_run_number, created_after_time = self.get_tracking_last_update(appid, workflow_name)
            if not created_after_time:
                created_after_time = self.startFromDate

            workflow_runs = self.get_workflow_runs(git_owner, git_repo, workflow_id, workflow_name, created_after_time, last_run_number)

            if not workflow_runs:
                # No workflow runs found for this workflow, skipping to the next workflow
                continue

            self.extract_runs_data(workflow_runs, appid, workflow_name, workflow_url)

    def get_workflows(self, git_owner, git_repo):
        try: 
            # Fetch the workflows for a given repository.
            workflowsURL = f"{self.baseUrl}{git_owner}/{git_repo}/actions/workflows"
            githubActionsWorkFlows = self.getResponse(workflowsURL, 'GET', None, None, None, reqHeaders=self.headers)
            return githubActionsWorkFlows.get('workflows', [])
        except Exception as e: 
            if "404" in str(e): 
                self.logger.error(f"Error fetching workflow for {git_repo} repository: {e}") 
                self.logger.info("Proceeding with next workflow") 
                return [] 
            else: 
                raise e

    def filter_workflows(self, workflows, workflow_names): 
        return [w for w in workflows if w['name'] in workflow_names]
    
    def filter_new_runs(self, workflow_runs, last_run_number): 
        return [run for run in workflow_runs if self.is_run_new(run, last_run_number)]
    
    def get_workflow_runs(self, git_owner, git_repo, workflow_id, workflow_name, created_after_time, last_processed_run_number): 
        try: 
            # Fetch the workflow runs for a given workflow.
            # Handles pagination if there are more than 100 runs.
            runsURL = f"{self.baseUrl}{git_owner}/{git_repo}/actions/workflows/{workflow_id}/runs?created=>{created_after_time}"
            all_runs = []
            page = 1
            per_page = 100  # You can set this to a maximum of 100

            while True:
                paginated_url = f"{runsURL}&page={page}&per_page={per_page}"
                githubActionsRuns = self.getResponse(paginated_url, 'GET', None, None, None, reqHeaders=self.headers)
                runs = githubActionsRuns.get('workflow_runs', [])
                if not runs:
                    break
                # Filter runs based on the presence of last_processed_run_number
                if last_processed_run_number == 0:
                    # No tracking, filter based on run_started_at
                    filtered_runs = [
                        run for run in runs 
                        if run.get('run_started_at') > self.startFromDate
                    ]
                else:
                    # Tracking, filter based on run_number
                    filtered_runs = [
                        run for run in runs 
                        if run.get('run_number') and run['run_number'] > last_processed_run_number
                    ]
                all_runs.extend(filtered_runs)
                page += 1

            return all_runs
        except Exception as e: 
            if "404" in str(e): 
                self.logger.error(f"Error fetching runs for workflow {workflow_name}: {e}")
                self.logger.info("Proceeding to fetch next run")
                return [] 
            else: 
                raise e
            
    def get_tracking_last_update(self, appid, workflow_name): 
        # Extract last_run_number and created_after_time from tracking data
        last_run_number = self.tracking.get(appid, {}).get(workflow_name, {}).get("lastRunNumber", 0)
        created_after_time = self.tracking.get(appid, {}).get(workflow_name, {}).get("created_at", "")
        return last_run_number, created_after_time
    
    def is_run_new(self, run, last_run_number):
        # Check if a workflow run is new based on the last run number or start date.
        if last_run_number == 0:                # If tracking is empty or we are running for the first time
            run_started_at = datetime.strptime(run['run_started_at'], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            return run_started_at > self.startFromDate
        else:                    # For subsequent runs, compare based on the run number only
            return run['run_number'] > last_run_number 


    def update_tracking_data(self, appid, workflow_name, workflow_url, highest_run_number, created_at):
        # Update the tracking data with the highest run number for each workflow under an app ID.
        if appid not in self.tracking:
            self.tracking[appid] = {}
            self.logger.info(f"Initialized tracking for appid: {appid}")

        if workflow_name not in self.tracking[appid]:
            self.tracking[appid][workflow_name] = {
                "lastRunNumber": highest_run_number,
                "workflowUrl": workflow_url,
                "created_at": created_at
            }
            self.logger.info(f"Initialized tracking for workflow: {workflow_name} under appid: {appid}")
        else:
            current_last_run = self.tracking[appid][workflow_name]["lastRunNumber"]
            if highest_run_number > current_last_run:
                self.tracking[appid][workflow_name]["lastRunNumber"] = highest_run_number
                self.tracking[appid][workflow_name]["created_at"] = created_at
                self.logger.info(f"Updated lastRunNumber for workflow: {workflow_name} under appid: {appid} to {highest_run_number}")
            else:
                self.logger.info(f"No update required for workflow: {workflow_name} under appid: {appid}, current lastRunNumber is {current_last_run}")

    def extract_runs_data(self, workflowRuns, appid, name, url):
        # Process and publish data related to workflow runs.
        if len(workflowRuns) == 0:
            self.logger.info("4001 - FLOWSOURCE_ERROR: No GitHub Actions Workflows available")
        self.runnersDataResponse = []

        # Reversing the list to process runs in ascending order by run number
        for run in reversed(workflowRuns):
            # Update tracking data every time 
            self.update_tracking_data(appid, name, url, run['run_number'], run['created_at'])

            # Check if the conclusion of the run is 'success'
            if run.get('conclusion') == 'success':
                self.runnersData = {}
                run['conclusion'] = 'SUCCESS'
                runCreatedAt = run.get('created_at', None)
                runUpdatedAt = run.get('updated_at', None)
                createdAt = datetime.strptime(runCreatedAt, "%Y-%m-%dT%H:%M:%SZ")
                updatedAt = datetime.strptime(runUpdatedAt, "%Y-%m-%dT%H:%M:%SZ")
                totalDurationInSeconds = (updatedAt - createdAt).total_seconds()
                displayTitle = run.get('display_title', '')
                # Escape double quotes in the display title to avoid JSON parsing issues
                runDisplayTitle = re.sub(r'\"',r'\\"', displayTitle)
                eventTime = datetime.strptime(run['run_started_at'],self.inputTimeFormat)

                injectData = {
                    "runDisplayTitle" : runDisplayTitle,
                    "runStartedAt" : int(eventTime.timestamp()),
                    "runNumber": str(run['run_number']),
                    "totalDurationInSeconds": totalDurationInSeconds,
                    "appid": appid
                }

                self.runnersData = self.parseResponse(self.runsResponseTemplate, run, injectData)
                self.runnersDataResponse.append(self.runnersData[0])
                # Publish runners data
                self.publishData(self.runnersDataResponse, 'Run', batchSize=self.batchSize, is_residual=False, tracking=self.tracking)


        # Publish remaining runners data
        if len(self.runnersDataResponse) > 0:
            self.publishData(self.runnersDataResponse, 'Run', batchSize=self.batchSize, is_residual=True, tracking=self.tracking)

        # If there are no runners data objects, update the tracking file to the latest run number
        if not self.runnersDataResponse:
            self.updateTrackingFile(self.tracking)

    def initialize_github_app(self):
        # Initialize the GitHub App authentication flow by generating a JWT and retrieving an installation access token.

        # Generate JWT using Client ID and Private Key
        jwt_token = self.generate_jwt(self.clientId, self.privateKey)

        # Get installation token using the generated JWT
        installation_token = self.get_installation_token(jwt_token)

        return installation_token

    def generate_jwt(self, client_id, private_key):

        # Generate a JWT token for GitHub App authentication.  
        expiration_time = int(time.time()) + 600  # 10 minutes
        payload = {
            'iat': int(time.time()),  # Issued at time
            'exp': expiration_time,   # Expiration time
            'iss': client_id             # Client ID
        }
        return jwt.encode(payload, private_key, algorithm='RS256')

    def get_installation_token(self, jwt_token):

        # Get the installation token for the GitHub App by calling the installation API.
        installations_url = "https://api.github.com/app/installations"
        headers = {
            'Authorization': f'Bearer {jwt_token}',
            'Accept': 'application/json'
        }

        # Fetch installations
        response = self.getResponse(installations_url, 'GET', None, None, None, reqHeaders=headers)
        installations = response

        if not installations:
            raise Exception('No installations found for this GitHub App')

        installation_id = installations[0]['id']

        # Get installation token
        access_token_url = f"https://api.github.com/app/installations/{installation_id}/access_tokens"
        access_token_response = self.getResponse(access_token_url, 'POST', None, None, None, reqHeaders=headers)
        access_token = access_token_response.get('token')

        if not access_token:
            raise Exception('4003 - FLOWSOURCE_ERROR: Failed to get installation access token')

        return access_token