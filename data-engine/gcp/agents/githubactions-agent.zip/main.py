from GithubActionsAgent import GithubActionsAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def githubactions_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = GithubActionsAgent(cloud_provider)
        agent.process()  # Calling the import GithubActionsAgent process
        logging.info(f'GithubActions executed successfully ...')
        return "GithubActionsAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing GithubActions agent: {str(e)}')
