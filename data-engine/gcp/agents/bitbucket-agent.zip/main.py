from BitbucketAgent import BitbucketAgent
import functions_framework
import logging

#HTTP-triggered function
@functions_framework.http
def bitbucket_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = BitbucketAgent(cloud_provider)
        agent.process()  # Calling the import BitbucketAgent process
        logging.info(f'Bitbucket executed successfully ...')
        return "BitbucketAgent process executed"

    except Exception as e:
        logging.error(f'ERROR while executing Bitbucket agent: {str(e)}')
