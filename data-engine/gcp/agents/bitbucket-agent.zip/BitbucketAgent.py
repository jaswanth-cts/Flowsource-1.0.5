import base64
from datetime import datetime
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class BitbucketAgent(BaseAgent):

    @flowsource_exception_handler    
    def process(self):
        self.logger.info('Inside BitbucketAgent process ...')

        # Load configurations and initialize
        self.load_configurations()

        # Fetch catalog data 
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tool data and update tracking file
        self.process_tool_data()

    def load_configurations(self):
        # load common agent config variables
        # Retrieve the query to fetch catalog Data as per the cloud Provider
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get('batchSize', 1000)
        self.batchCollectDays = self.config.get("batchCollectDays", 30)
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000
            
        # agent specific variables
        # Retrieve configurations 
        self.bitbucketToken = self.config.get(self.cloud_provider, '').get("bitbucketToken", '')

        # load responseTemplate from dynamicTemplate in config.json
        self.responseTemplate = self.getResponseTemplate()

        # Check the length of startFromDate, if it is equal to 10 add time and zone
        if len(self.startFromDate) == 10:
            self.startFromDate = self.startFromDate + "T00:00:00Z"


    def process_tool_data(self):
        self.logger.info("Inside process_tool_data method")
        self.init_authorization()

        self.allPipelines = []
        # Process each catalog entry and fetch the corresponding pipelines
        for catalog in self.catalogData:
            appid = catalog[0]
            repo_owner = catalog[1]
            repo_name = catalog[2]
            pipeline_patterns = catalog[3]

            self.process_pipelines(appid,repo_owner, repo_name, pipeline_patterns)

    def init_authorization(self):
        # Get bitbucket credentials from credential manager
        self.bitbucketToken = base64.b64decode(self.keyValues.get(self.bitbucketToken, '')).decode("utf-8")

        # Set the Headers for the Api call for bitbucket pipelines
        self.json_headers = {
            "Authorization": f"Bearer " + self.bitbucketToken,
            "Accept": "application/json",
        }

    def process_pipelines(self, appid, repo_owner, repo_name, pipeline_patterns):
        # Split the pipeline patterns and process each pattern
        selector_patterns = pipeline_patterns.split(",")
        
        for selector_pattern in selector_patterns:
            # Get the last build number from tracking data
            last_build_number = self.get_tracking_last_update(appid, selector_pattern)

            pipelines = self.get_pipelines(repo_owner, repo_name, last_build_number, selector_pattern)

            if pipelines:
                for pipeline in pipelines:
                    # Extract the required fields from the response
                    completedOn = pipeline.get('completed_on', '').split('.')[0] + 'Z'
                    buildUrl = pipeline.get('links', {}).get('self', {}).get('href', '')
                    buildNumber = pipeline.get('build_number', 0)
                    completedOnEpoch = int(datetime.strptime(completedOn, '%Y-%m-%dT%H:%M:%SZ').timestamp())
                    
                    injectData = {
                        "buildTimestamp": completedOnEpoch,
                        "appid": appid,
                        "shortDescription": selector_pattern
                    }

                    pipelineData = self.parseResponse(
                        self.responseTemplate, pipeline, injectData)
                    self.allPipelines.append(pipelineData[0])

                    # Update tracking data with build number and created_on time
                    self.update_tracking_data(appid, selector_pattern, buildUrl, buildNumber)
                    # Publish bitbucket pipeline build data
                    self.publishData(
                        self.allPipelines,
                        fileType="Pipeline",
                        batchSize=self.batchSize,
                        is_residual=False,
                        tracking=self.tracking,
                    )
            else:
                # Update tracking time to current time and last buildnumber if there are no pipelines in the response
                self.logger.error(f"4001 - FLOWSOURCE_ERROR: No builds for pipeline {selector_pattern} under appid- {appid}")
                self.updateTrackingFile(self.tracking)
            
        if len(self.allPipelines) > 0:
            # Publish bitbucket pipeline build data
            self.publishData(
                self.allPipelines,
                fileType="Pipeline",
                batchSize=self.batchSize,
                is_residual=True,
                tracking=self.tracking,
            )
                

    def get_pipelines(self, repo_owner, repo_name, last_build_number, selector_pattern):
        try:
            page = 1
            pageLength = 100
            # Fetch the pipelines for a given repository.
            bitbucketUrl = f"{self.baseUrl}{repo_owner}/{repo_name}/pipelines?status=PASSED&sort=created_on&target.selector.pattern={selector_pattern}"
            pipelines = []
            while True:
                paginated_url = f"{bitbucketUrl}&pagelen={pageLength}&page={page}"
                bitbucketPipelines = self.getResponse(paginated_url, 'GET', None, None, None, reqHeaders=self.json_headers)
                page_pipelines = bitbucketPipelines.get('values', [])
                # If it reaches the end of the pipelines, break the loop
                if not page_pipelines:
                    break

                # Filter pipelines based on the presence of last_build_number
                if last_build_number == 0:
                    # No tracking, filter based on created_on time
                    filtered_builds = [
                        build for build in page_pipelines 
                        if build.get('created_on') > self.startFromDate
                    ]
                else:
                    # Tracking, filter based on build number
                    filtered_builds = [
                        build for build in page_pipelines
                        if build.get('build_number') and build['build_number'] > last_build_number
                    ]
                pipelines.extend(filtered_builds)
                page += 1
            return pipelines
        except Exception as e: 
            if "404" in str(e): 
                self.logger.error(f"Error fetching pipeline for {repo_name} repository: {e}") 
                self.logger.info("Proceeding with next repository") 
                return [] 
            else: 
                raise e
            
    def get_tracking_last_update(self, appid, selector_pattern): 
        # Extract last_build_number from tracking data
        last_build_number = self.tracking.get(appid, {}).get(selector_pattern, {}).get("lastBuildNumber", 0)
        return last_build_number
    
    
    def update_tracking_data(self, appid, selectorPattern, buildUrl, highestBuildNumber):
        # Update the tracking data with the highest build number for each pipeline under the appid.
        if appid not in self.tracking:
            self.tracking[appid] = {}
            self.logger.info(f"Initialized tracking for appid: {appid}")
        
        if selectorPattern not in self.tracking[appid]:
            self.logger.info(f"Initialized tracking for triggerName: {selectorPattern}")
            self.tracking[appid][selectorPattern] = {
                "lastBuildNumber": highestBuildNumber,
                "buildUrl": buildUrl
            }
            self.logger.info(f"Initialized tracking for appid: {appid}")
        else:
            currentLastBuild = self.tracking[appid][selectorPattern]["lastBuildNumber"]
            if highestBuildNumber > currentLastBuild:
                self.tracking[appid][selectorPattern]["lastBuildNumber"] = highestBuildNumber
                self.logger.info(f"Updated lastBuildNumber for pipeline pattern {selectorPattern} under appid: {appid} to {highestBuildNumber}")
            else:
                self.logger.info(f"No update required for pipeline pattern {selectorPattern} appid: {appid}, current lastBuildNumber is {currentLastBuild}")

