from datetime import datetime as time
from datetime import datetime
import time
import boto3
import os
from core.BaseAgent import BaseAgent
from calendar import timegm
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class AwsResilienceHubAgent(BaseAgent):
    
    @flowsource_exception_handler    
    def process(self):
        self.logger.info('FLOWSOURCE_INFO: Inside AwsResilienceHubAgent process ...')
        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tool data and update tracking file           
        self.process_tool_data()

    def load_configuration(self):
        
        # Retrieve common agent properties 
        self.select_query= self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get('batchSize', 1000)  
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        # Retrieve agent specific properties 
        self.dynamicTemplate = self.config.get("dynamicTemplate", {})
        self.historicalBatchCount = self.config.get(
            "historicalBatchCount", 0)
        self.currentBatchCount = self.config.get("currentBatchCount", 0)
        self.appResponseTemplate = self.dynamicTemplate.get(
            "appResponseTemplate", {})
        self.assessmentResponseTemplate = self.dynamicTemplate.get(
            "assessmentResponseTemplate", {})
        self.regionName = os.environ['REGION_NAME'] 

        
        if len(self.startFromDate) == 10: # Only date is provided
            startFromDate = self.startFromDate + "00:00:00"
        utc_time = time.strptime(startFromDate, "%Y-%m-%d%H:%M:%S")
        self.startDateEpoch = timegm(utc_time)

   

    def process_tool_data(self):
        self.logger.info('FLOWSOURCE_INFO: In process_tool_data')   

        #authorizate the headers
        self.perform_authorization()        

        for catalog in self.catalogData:
            appId = catalog[0]
            appName = catalog[1]
            self.process_resilienceHub_data(appId, appName)

    # Method to perform authentication on headers
    def perform_authorization(self):

        # Retrieve configurations from AWS Manager
        self.resilienceHubId = self.config.get(self.cloud_provider, '').get("resilienceHubId", '')
        self.resilienceHubPs = self.config.get(self.cloud_provider, '').get("resilienceHubPs", '')
        self.accessKey = self.keyValues[self.resilienceHubId]
        self.keyID = self.keyValues[self.resilienceHubPs] 

        self.client = boto3.client('resiliencehub',
                                   aws_access_key_id=self.accessKey,
                                   aws_secret_access_key=self.keyID,
                                   region_name=self.regionName)
        

    def process_resilienceHub_data(self, appId, appName):
        
        self.assessmentData = []
        injectData = dict()

        self.batch = self.get_batch_count_from_tracking(appId, appName)

        appsList = self.client.list_apps(name=appName)
        
        if(len(appsList["appSummaries"]) > 0):
                                            
            for app in appsList["appSummaries"]:
                    appArn = app.get('appArn', None)
                    appName = app.get('name', None)

                    tillBatchComplete = True
                    nextToken = None
                    # Fetch a historical sync till all the records are fetched by batch
                    while (tillBatchComplete):
                        assessments = self.client.list_app_assessments(
                                appArn=appArn,
                                maxResults=self.batch,
                                reverseOrder=True,
                                **({nextToken: nextToken} if nextToken else {}))
                        
                        for assessment in reversed(assessments['assessmentSummaries']):
                            assessmenStartTime = self.convertTimeToEpoch(assessment.get('startTime', None))
                            assessmenEndTime = self.convertTimeToEpoch(assessment.get('endTime', None))
                            if (assessmenStartTime < self.tracking[appId]['lastUpdated_'+appName]):
                                tillBatchComplete = False
                                continue
                            injectData = {
                                "appName": appName,  # Have to inject appName here, because its a constraint in relationship
                                "startTime": assessmenStartTime,
                                "endTime": assessmenEndTime,
                                "processRunDateTime": assessmenStartTime,
                                'appid': appId
                            }
                            tillBatchComplete = True
                            dataObj = self.parseResponse(self.assessmentResponseTemplate, assessment, injectData)
                            if (self.tracking[appId]['lastUpdated_'+appName] < assessmenStartTime):
                                self.assessmentData.append(dataObj[0])
                                self.update_tracking_data(assessmenStartTime, appName, appId)
                                self.publishData(self.assessmentData,"Assessment",batchSize=self.batchSize,is_residual=False,tracking=self.tracking)
                        if (tillBatchComplete and 'nextToken' in assessments):
                            nextToken = assessments.get('nextToken', None)
                        else:
                            tillBatchComplete = False
        else:
            self.logger.info(f"4001 - FLOWSOURCE_INFO: No data found for appid - {appId}, appName- {appName}")
            currentDate = datetime.now(self.toolsTimeZone).strftime('%Y-%m-%d %H:%M:%S')
            currentTime = int(datetime.strptime(currentDate, '%Y-%m-%d %H:%M:%S').timestamp())
            self.tracking[appId]['lastUpdated_'+appName] = currentTime
            self.updateTrackingFile(self.tracking)
                    
               
            
        # Publish remaining Assessment data
        if len(self.assessmentData)>0:
            self.publishData(self.assessmentData,"Assessment",batchSize=self.batchSize,is_residual=True,tracking=self.tracking)
        self.logger.info('FLOWSOURCE_INFO: Published a final set of Assesment Data')    
            
            
    def update_tracking_data(self, assessmenStartTime, appName, appId):
        self.tracking[appId]['lastUpdated_'+appName] = assessmenStartTime


    def convertTimeToEpoch(self, pTime):
        timePattern = '%Y-%m-%dT%H:%M:%S'
        regularTimeFormat = pTime.strftime('%Y-%m-%dT%H:%M:%S')
        epochTime = int(time.mktime(
            time.strptime(regularTimeFormat, timePattern)))
        return epochTime   

    # Determine the batch count for listing app_assessment data based on the tracking data 
    def get_batch_count_from_tracking(self, appId, appName):
        if appId not in self.tracking:
            self.tracking[appId] = {'lastUpdated_'+appName: self.startDateEpoch}
        elif appId in self.tracking and 'lastUpdated_'+appName not in self.tracking[appId]:
            self.tracking[appId] = {'lastUpdated_'+appName: self.startDateEpoch} 

        if (self.tracking[appId]['lastUpdated_'+appName] == self.startDateEpoch):
            self.batch = self.historicalBatchCount
        else:
            self.batch = self.currentBatchCount
        return self.batch