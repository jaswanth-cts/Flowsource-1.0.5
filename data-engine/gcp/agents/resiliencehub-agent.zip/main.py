import functions_framework
import logging
from AwsResilienceHubAgent import AwsResilienceHubAgent

@functions_framework.http
def resilienceHub_agent(request):
    try:
        cloud_provider = 'GCP'
        agent = AwsResilienceHubAgent(cloud_provider)
        agent.process() 
        return "ResilienceHub Agent Execution Completed Successfully ..."

    except Exception as e:
            logging.error(f'ERROR while executing ResilienceHub agent {str(e)}')
