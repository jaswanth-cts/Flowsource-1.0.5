import json
from JenkinsAgent import JenkinsAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        jenkins_Agent = JenkinsAgent(cloud_provider)
        jenkins_Agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Jenkins Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Jenkins Agent", "error": str(e)
            })
        }
