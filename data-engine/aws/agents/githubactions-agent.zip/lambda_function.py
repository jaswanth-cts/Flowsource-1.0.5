import json
from GithubActionsAgent import GithubActionsAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = GithubActionsAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "GithubActions Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing GithubActions Agent", "error": str(e)
            })
        }