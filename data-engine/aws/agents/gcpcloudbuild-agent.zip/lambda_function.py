import json
from GCPCloudBuild import GCPCloudBuild

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = GCPCloudBuild(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "GCPCloudBuild Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing GCPCloudBuild Agent", "error": str(e)
            })
        }