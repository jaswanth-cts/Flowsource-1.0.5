import json
from AwsResilienceHubAgent import AwsResilienceHubAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        awsResilienceHub_Agent = AwsResilienceHubAgent(cloud_provider)
        awsResilienceHub_Agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "ResilienceHub Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing ResilienceHub Agent", "error": str(e)
            })
        }