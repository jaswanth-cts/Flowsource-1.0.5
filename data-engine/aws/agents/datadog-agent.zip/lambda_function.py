import json
from DatadogAgent import DatadogAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        datadog_Agent = DatadogAgent(cloud_provider)
        datadog_Agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Datadog Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Datadog Agent", "error": str(e)
            })
        }