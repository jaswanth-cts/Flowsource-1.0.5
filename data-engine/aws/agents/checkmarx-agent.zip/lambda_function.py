import json
from CheckmarxAgent import CheckmarxAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        checkmarx_Agent = CheckmarxAgent(cloud_provider)
        checkmarx_Agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Checkmarx Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Checkmarx Agent", "error": str(e)
            })
        }