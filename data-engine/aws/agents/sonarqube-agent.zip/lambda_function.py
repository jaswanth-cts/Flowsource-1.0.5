import json
from SonarQubeAgent import SonarQubeAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = SonarQubeAgent(cloud_provider)
        agent.process()
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'SonarQube Agent Execution Completed Successfully ...',
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error while processing SonarQube Agent', 'error': str(e)
            })
        }