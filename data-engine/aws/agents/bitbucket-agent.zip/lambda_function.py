import json
from BitbucketAgent import BitbucketAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = BitbucketAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Bitbucket Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Bitbucket Agent", "error": str(e)
            })
        }