import json
from AzurePipelineAgent import AzurePipelineAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = AzurePipelineAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "AzurePipeline Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing AzurePipeline Agent", "error": str(e)
            })
        }