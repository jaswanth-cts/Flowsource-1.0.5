from time import mktime
from dateutil import parser
import datetime
import json
from datetime import datetime as dateTime, timedelta, timezone
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class Jira_Agent(BaseAgent):

    @flowsource_exception_handler
    def process(self):
        self.logger.info("Inside  process ...")

        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        catalogData = self.fetchCatalogData(self.select_query)
        self.catalog_dict = self.process_catalog_data(catalogData)

        # Process and publish tool data and update tracking file
        self.process_tool_data()

    def load_configuration(self):

        # load common agent config var
        self.select_query = self.config.get(self.cloud_provider, "").get(
            "catalogDataSelectQuery", ""
        )
        self.batchSize = self.config.get("batchSize", 1000)
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000
        self.batchCollectDays = self.config.get("batchCollectDays", 30)

        # agent specific var
        # Retrieve configurations from config.json
        self.apiOutTimeFormat = "%Y-%m-%dT%H:%M:%S.%f%z"
        self.apiInTimeFormat = "%Y-%m-%d %H:%M"
        self.fetchCount = self.config.get("fetchCount", 100)
        self.jiraId = self.config.get(self.cloud_provider, "").get("jiraId", "")
        self.jiraPs = self.config.get(self.cloud_provider, "").get("jiraPs", "")
        self.selectedProjectList = self.config.get("dynamicTemplate", "GET").get(
            "selectedProject", None
        )

        # load responseTemplate from dynamicTemplate in config.json
        self.responseTemplate = self.getResponseTemplate()

        if len(self.startFromDate) == 10:  # Only date is provided
            self.startFromDate = self.startFromDate + " 00:00"

    def process_tool_data(self):
        self.logger.info("FLOWSOURCE_INFO: Inside process_tool_data func ...")

        # Get Jira credentials from credential manager
        self.userid = self.keyValues[self.jiraId]
        self.cred = self.keyValues[self.jiraPs]

        # Constructing project key list from catalog data
        self.catalogProjectKey = list(self.catalog_dict.keys())

        self.fields = self.extract_fields(self.responseTemplate)

        # Get appId to process
        for catalog in self.catalogProjectKey:
            appId = catalog
            self.process_issue(appId)

    def process_issue(self, appId):

        projectKey = self.catalog_dict[appId]["projectKey"]
        finalDoraStatus = self.catalog_dict[appId]["dora_jira_final_status"]
        projectData = True
        total = 1
        maxResults = 0
        startAt = 0
        nextPageToken = None
        isLast = False

        # Getting lastUpdated for specific project from tracking
        startTime, endTime = self.get_tracking_last_update(appId)

        # Initialize Issue API template with prKey
        jiraIssuesUrlPrKey = self.baseUrl + "?jql=project='prKey' "

        # Including optional filter-field if present to the JQL
        if (
            "filter-field-key" in self.catalog_dict[appId]
            and "filter-field-value" in self.catalog_dict[appId]
        ):
            filterFieldKey = self.catalog_dict[appId]["filter-field-key"]
            filterFieldValue = self.catalog_dict[appId]["filter-field-value"]
            filterFieldValLoad = filterFieldValue.split(",")
            jiraIssuesUrlPrKey = (
                jiraIssuesUrlPrKey
                + " AND '"
                + filterFieldKey
                + "'  IN ("
                + ", ".join([f'"{value}"' for value in filterFieldValLoad])
                + ") "
            )

        # Including optional jql to the jiraIssuesUrlPrKey if filter-Id is present
        if "jira-filter-Id" in self.catalog_dict[appId]:
            filterUrlModified = self.baseUrl.replace("search", "filter", 1)
            filterURL = filterUrlModified + self.catalog_dict[appId]["jira-filter-Id"]
            response = self.getResponse(
                filterURL,
                "GET",
                self.userid,
                self.cred,
                None,
            )
            responceJQL = response.get("jql", None)
            if responceJQL:
                jiraIssuesUrlPrKey = jiraIssuesUrlPrKey + " AND " + responceJQL

        jiraIssuesUrl = (
            jiraIssuesUrlPrKey
            + " AND updated>='"
            + startTime
            + "' AND updated<'"
            + endTime
            + "' AND status='"
            + finalDoraStatus
            + "' ORDER BY updated ASC&maxResults="
            + str(self.fetchCount)
            + "&fields="
            + self.fields
        )

        # Initialize data list
        self.data = []

        while not isLast:

            # Construct the URL with nextPageToken if available
            jiraIssuesUrlModified = jiraIssuesUrl.replace("prKey", projectKey, 1)
            if nextPageToken:
                jiraIssuesUrlModified += "&nextPageToken=" + nextPageToken

            try:
                response = self.getResponse(
                    jiraIssuesUrlModified,
                    "GET",
                    self.userid,
                    self.cred,
                    None,
                )
            except Exception as e:
                if "error 400" in str(e):
                    # If the Project is not accessable by the user break move to next Project
                    self.logger.exception(
                        "FLOWSOURCE_JIRA_AGENT_ERROR: Unable to reach project : "
                        + projectKey
                        + "\n"
                        + str(e)
                    )
                    projectData = False
                    return
                else:
                    raise e
            jiraIssues = response["issues"]

            if jiraIssues:

                for issue in jiraIssues:
                    eventTime = dateTime.strptime(
                                            issue.get("fields", {}).get("updated", ""),
                                            self.apiOutTimeFormat
                                        )
                    id = issue.get("id")
                    injectData = {
                        "commits": self.get_all_issue_commits(id),
                        "lastUpdated" : int(eventTime.timestamp()),
                        "appid": appId
                    }
                    parsedIssue = self.parseResponse(
                        self.responseTemplate, issue, injectData
                    )
                    self.data += parsedIssue

                    # Update tracking with latest data
                    self.update_tracking_data(
                        appId, projectKey, parsedIssue[0]["updated"]
                    )
                    # Publish jira data
                    self.publishData(
                        self.data,
                        "Issue",
                        batchSize=self.batchSize,
                        is_residual=False,
                        tracking=self.tracking,
                    )

            else:
                # Update tracking time to current time if there are no problems in the response
                projectTracking = self.tracking.get(appId, {})
                projectTracking["projectKey"] = projectKey
                projectTracking["lastupdated"] = endTime
                self.tracking[appId] = projectTracking
                self.updateTrackingFile(self.tracking)

            nextPageToken = response.get("nextPageToken")
            isLast = response.get("isLast", True)
        if not projectData:
            return
        if len(self.data) > 0:
            # Publish remaining issue data
            self.publishData(
                self.data,
                "Issue",
                batchSize=self.batchSize,
                is_residual=True,
                tracking=self.tracking,
            )

    def get_all_issue_commits(self, id):

        # Initialize Commits list
        commits = []
        issueCommitsUrl = self.baseUrl.replace(
            "api/3/search/jql",
            "dev-status/latest/issue/detail?issueId="
            + id
            + "&applicationType=GitHub&dataType=repository",
        )
        commitResponse = self.getResponse(
            issueCommitsUrl, "GET", self.userid, self.cred, None
        )
        if "detail" in commitResponse:
            # Collect Commit data Repository wise
            for detail_item in commitResponse["detail"]:
                if "repositories" in detail_item:
                    for repository in detail_item["repositories"]:
                        if "commits" in repository:
                            for commit in repository["commits"]:
                                commit_id = commit.get("id")
                                author_timestamp = dateTime.strptime(
                                            commit.get("authorTimestamp"),
                                            self.apiOutTimeFormat
                                        )
                                if commit_id and author_timestamp:
                                    epoch_time = int(author_timestamp.timestamp())
                                    commits.append(
                                        {
                                            "id": commit_id,
                                            "timestamp": epoch_time,
                                        }
                                    )

        return commits

    def get_tracking_last_update(self, appId):
        # Returns lastUpdated for appId in parameter from tracking
        startTime = self.tracking.get(appId, {}).get("lastupdated", self.startFromDate)
        # Get end date from startTime with batchCollectDays
        endTime = self.getEndTime(
            startTime,
            self.batchCollectDays,
            timeFormat= self.apiInTimeFormat,
            type="dateTime",
        )

        return startTime, endTime

    def process_catalog_data(self, catalogData):
        # Format the catalog data in kye:value pair
        # eg.{app_id_value:{"projectKey":projectKey_value, "dora_jira_final_status":dora_jira_final_status_value,
        # "filter-field-key":filter-field-key,"filter-field-value":filter-field-value,"jira-filter-Id":jira-filter-Id}}
        processedCatalogData = {}
        for catalog in catalogData:
            if catalog:

                if catalog[2] is not None and catalog[2] != "":
                    # Take dora-alm-final-status as final status
                    finalStatus = catalog[2]
                elif catalog[3] is not None and catalog[3] != "":
                    # Take dora-jira-final-status as final status
                    finalStatus = catalog[3]

                processedCatalogData[catalog[0]] = {
                    "projectKey": catalog[1],
                    "dora_jira_final_status": finalStatus,
                }
                if (catalog[4] is not None and catalog[4] != "") and (
                    catalog[5] is not None and catalog[5] != ""
                ):
                    processedCatalogData[catalog[0]].update(
                        {
                            "filter-field-key": catalog[4],
                            "filter-field-value": catalog[5],
                        }
                    )
                if catalog[6] is not None and catalog[6] != "":
                    processedCatalogData[catalog[0]].update(
                        {"jira-filter-Id": catalog[6]}
                    )
        return processedCatalogData

    def update_tracking_data(self, appId, projectKey, updatetimestamp):
        # update tracking with the last issue updatedTime
        dt = parser.parse(updatetimestamp)
        fromDateTime = dt + datetime.timedelta(minutes=0o1)
        fromDateTime = fromDateTime.strftime(self.apiInTimeFormat)
        self.tracking[appId] = {"projectKey": projectKey, "lastupdated": fromDateTime}

    def extract_fields(self, responseTemplate):
        fieldsJson = responseTemplate.get("fields", None)
        fieldsParam = ""
        if fieldsJson:
            for field in fieldsJson:
                fieldsParam += field + ","
        fieldsParam = fieldsParam[:-1]
        if self.config.get("sprintField", None):
            fieldsParam += "," + self.config.get("sprintField")
        return fieldsParam
