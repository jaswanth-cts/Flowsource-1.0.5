import json
from JiraAgent import Jira_Agent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        jira_Agent = Jira_Agent(cloud_provider)
        jira_Agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Jira Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing jira Agent", "error": str(e)
            })
        }