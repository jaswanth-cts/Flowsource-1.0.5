import json
from BlackduckAgent import BlackduckAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = BlackduckAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Blackduck Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Blackduck Agent", "error": str(e)
            })
        }