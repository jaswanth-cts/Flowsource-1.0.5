import json
from AwsCodePipelineAgent import AwsCodePipelineAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = AwsCodePipelineAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "AwsCodePipeline Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing AwsCodePipeline Agent", "error": str(e)
            })
        }