from datetime import datetime 
import time
import boto3
import os
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler

class AwsCodePipelineAgent(BaseAgent):
    @flowsource_exception_handler
    def process(self):
        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tool data and update tracking file
        self.process_tool_data()

    def load_configuration(self):
        
        # Retrieve common agent properties
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get('batchSize', 1000)
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000

        # Retrieve agent specific properties
        self.dynamicTemplate = self.config.get("dynamicTemplate", {})
        if len(self.startFromDate) == 10:
            self.configStartDate = self.startFromDate + "T00:00:00+0000"

    def process_tool_data(self):

        self.logger.info('FLOWSOURCE_INFO: In process_tool_data')
        # Authorize the headers
        self.perform_authorization()

        for catalog in self.catalogData:
            appId = catalog[0]
            regionName = catalog[1]

            # Collect list of pipelines
            pipelineNames = [name.strip() for name in catalog[2].split(",")]
            
            # Initialize the AWS CodePipeline client for the specific region using temporary credentials
            client = boto3.client(
            'codepipeline',
            aws_access_key_id=self.accessKey,
            aws_secret_access_key=self.keyID,
            aws_session_token=self.sessionToken,
            region_name=regionName
        )

            #Collect data for the available pipelines
            for pipelineName in pipelineNames:
                startDate = self.get_lastupdated_from_tracking(appId, pipelineName)
                self.process_awsCodePipeline_data(appId, client, pipelineName, startDate)

       
    def process_awsCodePipeline_data(self, appId, client, pipelineName, startDate):
        self.executionData = []
        nextToken = None

        while True:
            self.logger.info(f"Fetching pipeline executions for {pipelineName} ")
            try:
                executionResponse = client.list_pipeline_executions(
                pipelineName=pipelineName,
                maxResults=100,
                **({'nextToken': nextToken} if nextToken else {})
                )
        
            except Exception as e:
                if "PipelineNotFoundException" in str(e):
                    self.logger.exception(f"FLOWSOURCE_AWSCODEPIPELINE_AGENT_ERROR: Error fetching pipeline: {pipelineName}\n{str(e)}")
                    self.logger.info("Proceeding with next pipeline")
                    return
                else:
                    raise e

            # Retrive only the successful executions from the response
            successful_executions = [
            execution for execution in executionResponse['pipelineExecutionSummaries']
            if execution['status'] == 'Succeeded']
           
            # Initialize a flag to track whether data exists
            is_data_exists = True

            # Check if there are no successful executions 
            if not successful_executions:
                #Check if there is no nextToken,it means there are no more pages of data
                if 'nextToken' not in executionResponse:
                    self.logger.info(f"No successful executions found for {pipelineName}")
                    is_data_exists = False
            else:
            # Check if the start time of the latest successful execution is less than or equal to the startDate
                if successful_executions[0]['startTime'].strftime('%Y-%m-%dT%H:%M:%S%z') <= startDate:
                    self.logger.info(f"Data is up to date for {pipelineName}")
                    is_data_exists = False

            # If there is no succesful execution and tracking is uptodate, update the tracking to current time
            if not is_data_exists:
                currentTime = datetime.now(self.toolsTimeZone).strftime('%Y-%m-%dT%H:%M:%S')
                self.update_tracking_data(appId,pipelineName,currentTime)
                self.updateTrackingFile(self.tracking)
                return
            
            # Else collect the new data 
            # we are reversing the executions to get  update tracking with latest execution
            for execution in reversed(successful_executions):

                executionsStartTime = execution['startTime']

                # Converting to tool time zone string format to update in the tracking              
                executionsStartTimeStr = executionsStartTime.astimezone(self.toolsTimeZone).strftime('%Y-%m-%dT%H:%M:%S%z')

                # Converting to epoch to strore it in DB format
                executionsStartTimeEpoch = int((executionsStartTime).timestamp())
        
                # Taking the latest revision details from the revision dictionary 
                revision= execution['sourceRevisions'][0]  
                injectData = {
                    "appid": appId,
                    "deployment_job": pipelineName,
                    "short_description": pipelineName,
                    "build_number": revision['revisionId'],
                    "build_url": revision['revisionUrl'],
                    "build_status": "SUCCESS",
                    "build_timestamp": executionsStartTimeEpoch
                }

                dataObj = self.parseResponse(self.responseTemplate, execution, injectData)
                if startDate < executionsStartTimeStr:
                        self.executionData.append(dataObj[0])
                        #Update tracking with latest data and publish
                        self.update_tracking_data(appId,pipelineName,executionsStartTimeStr)
                        self.publishData(self.executionData, "Executions", batchSize=self.batchSize, is_residual=False, tracking=self.tracking)

            # Retrieve the nextToken from the execution response, if it exists and break out of loop if None
            nextToken = executionResponse.get('nextToken', None)
            if not nextToken:
                break

        # publish residual data if any               
        if len(self.executionData) > 0:
                self.publishData(self.executionData, "Executions", batchSize=self.batchSize, is_residual=True, tracking=self.tracking)
                self.logger.info('FLOWSOURCE_INFO: Published a final set of Executions Data')



    def perform_authorization(self):
        self.responseTemplate = self.getResponseTemplate()   

        # Create an STS client
        sts_client = boto3.client('sts')

        # Assume the role
        self.awscodepipelineRoleArn = self.config.get(self.cloud_provider, "").get("awscodepipelineRoleArn", "")
        self.roleArn = self.keyValues[self.awscodepipelineRoleArn]
        assumed_role = sts_client.assume_role(
                            RoleArn=self.roleArn,
                            RoleSessionName='codePipelineflowsourcesession',
                            DurationSeconds=900  
                        )
        # Extract temporary credentials
        credentials = assumed_role['Credentials']

        # Retrieve configurations from credentials
        self.accessKey = credentials['AccessKeyId']
        self.keyID = credentials['SecretAccessKey']
        self.sessionToken = credentials['SessionToken']
        

        
    def update_tracking_data(self, appId,pipelineName,executionStartTime):
        if appId not in self.tracking:
            self.tracking[appId] = {"lastupdated_" + pipelineName: executionStartTime}
        else:
            lastupdated_pipeline_name = "lastupdated_" + pipelineName
            self.tracking[appId][lastupdated_pipeline_name] = executionStartTime
        
    def get_lastupdated_from_tracking(self, appId, pipelineName):
        startDate = self.tracking.get(appId, {}).get("lastupdated_" + pipelineName, self.configStartDate)
        return startDate
    
   