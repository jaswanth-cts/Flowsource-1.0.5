import json
from DynatraceAgent import DynatraceAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = DynatraceAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Dynatrace Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Dynatrace Agent", "error": str(e)
            })
        }