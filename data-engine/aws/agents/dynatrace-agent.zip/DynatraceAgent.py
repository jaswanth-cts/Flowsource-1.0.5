from datetime import datetime, timezone
from core.BaseAgent import BaseAgent
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class DynatraceAgent(BaseAgent):
    @flowsource_exception_handler
    def process(self):

        # Load configurations and initialize
        self.load_configuration()

        # Fetch catalog data
        self.catalogData = self.fetchCatalogData(self.select_query)

        # Process and publish tools data and update tracking file
        self.process_tool_data()

    def load_configuration(self):
        # load common agent config
        self.select_query = self.config.get(self.cloud_provider, "").get("catalogDataSelectQuery", "")
        self.batchSize = self.config.get("batchSize", 1000)
        # Batch size should be greater than 0
        if self.batchSize < 1 or self.batchSize > 5000:
            self.batchSize = 1000
        self.batchCollectDays = self.config.get("batchCollectDays", 30)
        
        # agent specific var
        self.pageSize = self.config.get("pageSize", "500")
        self.severityLevel = self.config.get("severityLevel", "")
        self.dynatraceApiToken = self.config.get(self.cloud_provider, "").get("dynatraceApiToken", "")
        self.requiredMonitorTags = self.config.get("dynamicTemplate", {}).get("tags", [])
        # load responseTemplate from dynamicTemplate in config.json
        self.responseTemplate = self.getResponseTemplate() 
        
        # Check startFromDate should contain only date (i.e. YYYY-MM-DD)
        if len(self.startFromDate) == 10:
            self.startFromDate = self.startFromDate + " 00:00:00"

    def process_tool_data(self):

        self.logger.info("Inside process_tool_data function...")

        self.perform_authorization()
        
        self.allEvents = []
        for catalog in self.catalogData:
            appid = catalog[0]
            self.process_problems(appid)

    def perform_authorization(self):
        # Get dynatrace credentials from credential manager
        self.dynatraceApiToken = self.keyValues[self.dynatraceApiToken]

        # Set the Headers for the Api call for Problems
        self.json_headers = {
            "Authorization": f"Api-Token " + self.dynatraceApiToken,
            "Content-Type": "application/json",
        }

    def get_tracking_last_update(self, appid):
        # Converting env startFromDate into startDateEpoch
        startDateEpoch = int(datetime.strptime(self.startFromDate, '%Y-%m-%d %H:%M:%S').timestamp()) * 1000

        # If last updated epoch is not present in tracking take startDateEpoch
        startTime = int(self.tracking.get(appid, {}).get('lastupdated', startDateEpoch))

        # Get end date from startTime with batchCollectDays
        endTime = self.getEndTime(startTime,self.batchCollectDays,timeFormat= '%Y-%m-%d %H:%M:%S',type='epoch')

        # Adding one to startTime to avoid duplicates
        return str(startTime + 1), str(endTime * 1000)

    def process_problems(self, appid):

        startTime, endTime = self.get_tracking_last_update(appid)

        requiredTags, problems = self.get_problems(appid, startTime, endTime)

        if problems:
            for problem in problems:
                start_time = problem.get("startTime")
                end_time = problem.get("endTime")

                if start_time:
                    start_timeReadFormat = datetime.fromtimestamp(start_time / 1000, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                else:
                    start_timeReadFormat = ""
                
                # Calculate recovery time from the problem's startTime and endTime
                recovery_time = end_time - start_time
                    
                entityTags = []
                # the result is a Python dictionary:
                for tag in problem.get("entityTags", []):
                    if 'key' in tag:
                        entityTags.append(tag['key'])

                injectData = {
                    "recoverTimeInSec": recovery_time // 1000,
                    "eventOccurDate": start_timeReadFormat,
                    "eventOccurDateEpoch": start_time // 1000,
                    "eventTags": entityTags
                }

                # Adding appid and tags to the json file
                for requiredTag in requiredTags:
                    requiredTag = requiredTag.replace("\\", "")
                    injectData.update(
                        {requiredTag.split(
                            ":")[0]: requiredTag.split(":")[1]}
                    )
                    
                problemData = self.parseResponse(
                    self.responseTemplate, problem, injectData)
                    
                self.allEvents.append(problemData[0])
                
                self.update_tracking_data(appid, endTime)    
                # Publish dynatrace problem data
                self.publishData(
                    self.allEvents,
                    fileType="Event",
                    batchSize=self.batchSize,
                    is_residual=False,
                    tracking=self.tracking,
                )

        else:
            # Update tracking time to current time if there are no problems in the response
            self.logger.error(f"4001 - FLOWSOURCE_ERROR: No Problems for appids- {appid}")
            self.tracking[appid]= {'lastupdated' : endTime}
            self.updateTrackingFile(self.tracking)
        
        if len(self.allEvents) > 0:
            # Publish dynatrace problem data
            self.publishData(
                self.allEvents,
                fileType="Event",
                batchSize=self.batchSize,
                is_residual=True,
                tracking=self.tracking,
            )

    def get_problems(self, appid, startTime, endTime):
        requiredTags = self.requiredMonitorTags.copy()
        requiredTags.append("appid\\:" + appid)

        # Constructing all required problem tags
        problemTags = [f'entityTags("{tag}")' for tag in requiredTags]
        problemTags = ",".join(problemTags)
            
        # Constructing API to get all problem associated with required tags
        problemUrl = (
                self.baseUrl
                + "/v2/problems?problemSelector="
                + problemTags
                + ',status("closed")&from='
                + startTime
                + "&to="
                + endTime
                + "&pageSize="
                + self.pageSize
                + '&severityLevel=("'
                + self.severityLevel
                + '")'
        )
        problemResponse = self.getResponse(
            problemUrl, "GET", None, None, None, reqHeaders=self.json_headers
            )

        problems = problemResponse["problems"]
        return requiredTags,problems

    def update_tracking_data(self, appId, end_time):
        # Update tracking with the problem's maximum endTime in the response of problems
        self.tracking[appId] = {'lastupdated' : end_time}
