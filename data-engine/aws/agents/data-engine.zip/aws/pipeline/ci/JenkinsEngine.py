from IPipeline import IPipeline
from aws.AWSBaseEngine import AWSBaseEngine

class JenkinsEngine(AWSBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):

        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)

        self.ATHENA_TABLE_NAME = "ci_jenkins_data"

        self.MAIN_TABLE_NAME = "ci_prod_deployment_data"

        self.ATHENA_UNLOAD_QUERY_TEMPLATE = """UNLOAD (
                    SELECT
                		id,
                        appid,
                        jobname AS deployment_job,
                        shortdescription AS short_description, 
                        buildnumber AS build_number, 
                        result AS build_status,
                        buildtimestamp AS build_timestamp, 
                        buildurl AS build_url,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX, 
                        toolname AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                        FROM \"{ATHENA_DATABASE}\".\"{ATHENA_TABLE}\"
                	    WHERE "$path" LIKE \'%{JSON_FILE_NAME}%\'
                    )
                    TO \'{PARQUET_FILE_LOC}\'
                    WITH (format = 'PARQUET', compression = 'SNAPPY');"""
