from IPipeline import IPipeline
from aws.AWSBaseEngine import AWSBaseEngine

class AzurepipelineEngine(AWSBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):

        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)

        self.ATHENA_TABLE_NAME = "ci_azurepipeline_data"

        self.MAIN_TABLE_NAME = "ci_prod_deployment_data"

        self.ATHENA_UNLOAD_QUERY_TEMPLATE = """UNLOAD (
                    SELECT
                		id,
                        appid,
                        jobName AS deployment_job,
                        shortDescription AS short_description, 
                        buildNumber AS build_number, 
                        result AS build_status,
                        buildTimestamp AS build_timestamp, 
                        buildUrl AS build_url,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX, 
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                        FROM \"{ATHENA_DATABASE}\".\"{ATHENA_TABLE}\"
                	    WHERE "$path" LIKE \'%{JSON_FILE_NAME}%\'
                    )
                    TO \'{PARQUET_FILE_LOC}\'
                    WITH (format = 'PARQUET', compression = 'SNAPPY');"""
