import uuid
from utils.TimeUtils import TimeUtils
from IPipeline import IPipeline
from aws.AWSBaseEngine import AWSBaseEngine
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
from datetime import datetime


class ResiliencehubEngine(AWSBaseEngine, IPipeline):

    def __init__(self, cloud_provider, tool_name, json_file_path):

        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)

        self.ATHENA_TABLE_NAME = "apm_resilience_data"

        self.MAIN_TABLE_NAME = "apm_resilience_data"

        self.CREATE_TEMP_QUERY_TEMPLATE = """
                    create temp table {REDSHIFT_TEMP_TABLE} (id VARCHAR(255), appid VARCHAR(255), assessment_name VARCHAR(255), assesment_start_time BIGINT,
                    resilience_score VARCHAR(255), compliance_status VARCHAR(255), flowsource_time BIGINT, flowsource_timeX VARCHAR(255),
                    tool_name VARCHAR(255), engine_execution_time BIGINT
                    );
                    """

        self.ATHENA_UNLOAD_QUERY_TEMPLATE = """UNLOAD (
                    SELECT 
                        id,
                        appid,
                        assessmentName as assessment_name,
						startTime as assesment_start_time,
						resiliencyScore as resilience_score,
						complianceStatus as compliance_status,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM \"{ATHENA_DATABASE}\".\"{ATHENA_TABLE}\"
                    WHERE appid is not null AND assessmentName is not null AND
                    "$path" LIKE \'%{JSON_FILE_NAME}%\'
                    )
                    TO \'{PARQUET_FILE_LOC}\'
                    WITH (format = 'PARQUET', compression = 'SNAPPY');"""

        self.MERGE_SQL_TEMPLATE = """
                    MERGE INTO {MAIN_TABLE} USING {TEMP_TABLE} ON {MAIN_TABLE}.appid = {TEMP_TABLE}.appid AND
                    {MAIN_TABLE}.assessment_name = {TEMP_TABLE}.assessment_name
                    WHEN MATCHED THEN UPDATE SET assessment_name = {TEMP_TABLE}.assessment_name
                    WHEN NOT MATCHED THEN INSERT VALUES ({TEMP_TABLE}.id,{TEMP_TABLE}.appid, {TEMP_TABLE}.assessment_name, {TEMP_TABLE}.assesment_start_time, {TEMP_TABLE}.resilience_score, {TEMP_TABLE}.compliance_status, {TEMP_TABLE}.flowsource_time, {TEMP_TABLE}.flowsource_timex, {TEMP_TABLE}.tool_name, {TEMP_TABLE}.engine_execution_time);
                    """

    @flowsource_exception_handler
    def execute_pipeline(self):
        # Creating all the queries
        engineExecutionTime = TimeUtils().get_current_time()

        folder_name = self.tool_name + "-" + str(uuid.uuid4())
        output_loc = self.PARQUET_FILE_LOC + folder_name
        ATHENA_UNLOAD_QUERY = self.format_unload_query(
            self.ATHENA_UNLOAD_QUERY_TEMPLATE,
            engineExecutionTime,
            self.ATHENA_TABLE_NAME,
            output_loc,
        )

        # Set redshift table name
        current_time = datetime.now()
        current_timestamp = int(current_time.timestamp())
        redshiftTableName = self.MAIN_TABLE_NAME + "_temp_" + str(current_timestamp)

        COPY_QUERY = self.COPY_QUERY_TEMPLATE.format(
            REDSHIFT_TABLE=redshiftTableName,
            PARQUET_FILE_LOC=output_loc,
            ARN_ROLE=self.ARN_ROLE,
        )

        # Formatting Create temporory table query
        CREATE_TEMP_TABLE_QUERY = self.CREATE_TEMP_QUERY_TEMPLATE.format(
            REDSHIFT_TEMP_TABLE=redshiftTableName
        )

        main_table = (
            self.REDSHIFT_DATABASE
            + "."
            + self.REDSHIFT_DATABASE_SCHEMA
            + "."
            + self.MAIN_TABLE_NAME
        )
        # Formatting merge query for resilience hub
        MERGE_QUERY = self.MERGE_SQL_TEMPLATE.format(
            MAIN_TABLE=main_table, TEMP_TABLE=redshiftTableName
        )

        # Set the parameters to be executed in order
        parameters = [
            f"PARQUET_FILE_LOC: {output_loc}",
            f"UNLOAD_QUERY: {ATHENA_UNLOAD_QUERY}",
            f"CREATE_TEMP_QUERY: {CREATE_TEMP_TABLE_QUERY}{COPY_QUERY}{MERGE_QUERY}",
        ]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(parameters)
