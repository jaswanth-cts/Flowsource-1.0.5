from IPipeline import IPipeline
from aws.AWSBaseEngine import AWSBaseEngine

class DynatraceEngine(AWSBaseEngine, IPipeline):
    
    def __init__(self, cloud_provider, tool_name, json_file_path):

        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)

        self.ATHENA_TABLE_NAME = "apm_dynatrace_data"

        self.MAIN_TABLE_NAME = "apm_event_data"

        self.ATHENA_UNLOAD_QUERY_TEMPLATE = """UNLOAD (
                    SELECT 
                        id,
                        appid,
                        eventId AS event_id,
                        eventOccurDateEpoch AS event_date,
                        recoverTimeInSec AS recovery_time,
                        environment,
                        flowsourceTime AS flowsource_time,
                        flowsourceTimeX AS flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                    FROM \"{ATHENA_DATABASE}\".\"{ATHENA_TABLE}\"
                    WHERE "$path" LIKE \'%{JSON_FILE_NAME}%\'
                    )
                    TO \'{PARQUET_FILE_LOC}\'
                    WITH (format = 'PARQUET', compression = 'SNAPPY');"""
