import uuid
from utils.TimeUtils import TimeUtils
from IPipeline import IPipeline
from aws.AWSBaseEngine import AWSBaseEngine
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class CatalogEngine(AWSBaseEngine, IPipeline):

    def __init__(self, cloud_provider, tool_name, json_file_path):

        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)

        self.ATHENA_TABLE_NAME = "catalog_info_data"

        self.MAIN_TABLE_NAME = "catalog_data"

        self.STAGING_TABLE_NAME = "catalog_data_staging"

        self.ATHENA_UNLOAD_QUERY_TEMPLATE = """UNLOAD (      
                        SELECT
                            appid,
                            app_name,
                            annotations,
                            lob,
                            is_critical,
                            {ENGINE_EXECUTION_TIME} as engine_execution_time
                        FROM (
                            SELECT *, ROW_NUMBER() OVER (PARTITION BY appid ORDER BY appid) As rn
                            FROM \"{ATHENA_DATABASE}\".\"{ATHENA_TABLE}\"
                            WHERE "$path" LIKE \'%{JSON_FILE_NAME}%\'
                            ) catalog
                        WHERE rn = 1 and appid is not null
                    )
                    TO \'{PARQUET_FILE_LOC}\'
                    WITH (format = 'PARQUET', compression = 'SNAPPY');"""

        self.MERGE_SQL_TEMPLATE = """
                    MERGE INTO {MAIN_TABLE} USING {STAGING_TABLE} ON {STAGING_TABLE}.appid is not null and {MAIN_TABLE}.appid = flowsource.catalog_data_staging.appid
                    WHEN MATCHED THEN UPDATE SET app_name = {STAGING_TABLE}.app_name, annotations = {STAGING_TABLE}.annotations, lob = {STAGING_TABLE}.lob, is_critical = {STAGING_TABLE}.is_critical
                    WHEN NOT MATCHED THEN INSERT VALUES ({STAGING_TABLE}.appid, {STAGING_TABLE}.app_name, {STAGING_TABLE}.annotations, {STAGING_TABLE}.lob, {STAGING_TABLE}.is_critical, {STAGING_TABLE}.engine_execution_time);
                    """

        self.DELETE_STAGING_TABLE_QUERY_TEMPLATE = "DELETE FROM {STAGING_TABLE}"

        self.DELETE_RECORDS_TEMPLATE = """
                DELETE FROM {MAIN_TABLE}
                USING {STAGING_TABLE}
                WHERE {MAIN_TABLE}.appid NOT IN (SELECT appid FROM {STAGING_TABLE});"""

    @flowsource_exception_handler
    def execute_pipeline(self):
        # Creating all the queries
        timeUtils = TimeUtils()
        engineExecutionTime = timeUtils.get_current_time()

        folder_name = self.tool_name + "-" + str(uuid.uuid4())
        output_loc = self.PARQUET_FILE_LOC + folder_name
        ATHENA_UNLOAD_QUERY = self.format_unload_query(
            self.ATHENA_UNLOAD_QUERY_TEMPLATE,
            engineExecutionTime,
            self.ATHENA_TABLE_NAME,
            output_loc,
        )

        COPY_QUERY = self.format_copy_query(
            self.COPY_QUERY_TEMPLATE, self.STAGING_TABLE_NAME, output_loc
        )

        main_table = (
            self.REDSHIFT_DATABASE
            + "."
            + self.REDSHIFT_DATABASE_SCHEMA
            + "."
            + self.MAIN_TABLE_NAME
        )
        staging_table = (
            self.REDSHIFT_DATABASE
            + "."
            + self.REDSHIFT_DATABASE_SCHEMA
            + "."
            + self.STAGING_TABLE_NAME
        )
        MERGE_QUERY = self.MERGE_SQL_TEMPLATE.format(
            MAIN_TABLE=main_table, STAGING_TABLE=staging_table
        )
        DELETE_STAGING_QUERY = self.DELETE_STAGING_TABLE_QUERY_TEMPLATE.format(
            STAGING_TABLE=staging_table
        )

        DELETE_RECORDS_QUERY = self.DELETE_RECORDS_TEMPLATE.format(
            MAIN_TABLE=main_table, STAGING_TABLE=staging_table
        )

        # Set the parameters to be executed in order
        parameters = [
            f"PARQUET_FILE_LOC: {output_loc}",
            f"UNLOAD_QUERY: {ATHENA_UNLOAD_QUERY}",
            f"COPY_QUERY: {COPY_QUERY}",
            f"MERGE_QUERY: {MERGE_QUERY}",
            f"DELETE_RECORDS_QUERY: {DELETE_RECORDS_QUERY}",
            f"DELETE_STAGING_QUERY: {DELETE_STAGING_QUERY}",
        ]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(parameters)
