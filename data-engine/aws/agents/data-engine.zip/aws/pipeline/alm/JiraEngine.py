import uuid
from utils.TimeUtils import TimeUtils
from IPipeline import IPipeline
from aws.AWSBaseEngine import AWSBaseEngine
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler


class JiraEngine(AWSBaseEngine, IPipeline):

    def __init__(self, cloud_provider, tool_name, json_file_path):

        super().__init__(cloud_provider, json_file_path, tool_name=tool_name)

        self.ATHENA_TABLE_NAME = "alm_jira_data"

        self.MAIN_TABLE_NAME = "alm_changes_data"
        self.LEADTIME_MAIN_TABLE_NAME = "scm_leadtime_data"

        self.ATHENA_UNLOAD_QUERY_TEMPLATE = {
            "jira": """UNLOAD (
                    SELECT
                        id,
                        appid,
                        projectKey as project_key,
                        key as issue_key,
                        status,
                        lastUpdated AS done_date,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                        FROM \"{ATHENA_DATABASE}\".\"{ATHENA_TABLE}\"
                        WHERE "$path" LIKE \'%{JSON_FILE_NAME}%\'
                    )
                    TO \'{PARQUET_FILE_LOC}\'
                    WITH (format = 'PARQUET', compression = 'SNAPPY');""",
            "jira_scm": """UNLOAD (
                    SELECT
                        id,
                        appid,
                        key AS story_id,
                        commit_info.id AS commit_id,
                        commit_info.timestamp AS commit_timestamp,
                        lastUpdated AS story_last_updated,
                        cast(date_diff('day', from_unixtime(commit_info.timestamp), from_unixtime(lastUpdated)) as integer) as lead_time_in_days,
                        flowsourceTime as flowsource_time,
                        flowsourceTimeX as flowsource_timeX,
                        toolName AS tool_name,
                        {ENGINE_EXECUTION_TIME} as engine_execution_time
                        FROM \"{ATHENA_DATABASE}\".\"{ATHENA_TABLE}\"
                        CROSS JOIN UNNEST(commits) AS T(commit_info)
                        WHERE "$path" LIKE \'%{JSON_FILE_NAME}%\'
                    )
                    TO \'{PARQUET_FILE_LOC}\'
                    WITH (format = 'PARQUET', compression = 'SNAPPY');""",
        }

    @flowsource_exception_handler
    def execute_pipeline(self):

        # Creating all the queries
        engineExecutionTime = TimeUtils().get_current_time()

        folder_name = self.tool_name + "-" + str(uuid.uuid4())
        output_loc = self.PARQUET_FILE_LOC + folder_name

        ATHENA_UNLOAD_QUERY = self.format_unload_query(
            self.ATHENA_UNLOAD_QUERY_TEMPLATE[self.tool_name],
            engineExecutionTime,
            self.ATHENA_TABLE_NAME,
            output_loc,
        )

        COPY_QUERY = self.format_copy_query(
            self.COPY_QUERY_TEMPLATE, self.MAIN_TABLE_NAME, output_loc
        )
        
        # Creating Leadtime queries for jira
        folder_name = self.tool_name + "-" + str(uuid.uuid4())
        leadtime_output_loc = self.PARQUET_FILE_LOC + folder_name

        LEADTIME_ATHENA_UNLOAD_QUERY = self.format_unload_query(
            self.ATHENA_UNLOAD_QUERY_TEMPLATE[self.tool_name + "_scm"],
            engineExecutionTime,
            self.ATHENA_TABLE_NAME,
            leadtime_output_loc,
        )
        LEADTIME_COPY_QUERY = self.format_copy_query(
            self.COPY_QUERY_TEMPLATE, self.LEADTIME_MAIN_TABLE_NAME, leadtime_output_loc
        )

        # Set the parameters to be executed in order
        parameters = [
            f"PARQUET_FILE_LOC: {output_loc}",
            f"UNLOAD_QUERY: {ATHENA_UNLOAD_QUERY}",
            f"COPY_QUERY: {COPY_QUERY}",
            f"PARQUET_FILE_LOC: {leadtime_output_loc}",
            f"UNLOAD_QUERY: {LEADTIME_ATHENA_UNLOAD_QUERY}",
            f"COPY_QUERY: {LEADTIME_COPY_QUERY}",
        ]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(parameters)