import os
from dal.DataAccessLayer import DataAccessLayer
from DeadLetterQueue import DeadLetterQueue
from utils.FlowsourceLogger import FlowsourceLogger
from utils.FileUtils import FileUtils
from utils.exceptions.FlowsourceExceptionUtils import flowsource_exception_handler
from utils.TimeUtils import TimeUtils
import uuid

class AWSBaseEngine(object):

    @flowsource_exception_handler
    def __init__(self, cloud_provider, json_file_path, tool_name):
        self.cloud_provider = cloud_provider
        self.fileUtils = FileUtils()
        self.tool_name = tool_name
        self.logger = FlowsourceLogger(self.tool_name)

        # Set dal layer access
        dal = DataAccessLayer(self.cloud_provider, self.tool_name)
        self.database_access = dal.get_database_access()
        self.storage_access = dal.get_storage_access()
        self.engineQuery_access = dal.get_engineQuery_access()
        
        # Retrieve environment variables
        self.get_env_variables()

        self.json_file_path = json_file_path
        #need to extract file name from json file name
        self.json_file_name = self.json_file_path.split("/")[-1]
        self.logger.info(f"file name extracted -> {self.json_file_name}")

        # Initialize variables used in the child class
        self.COPY_QUERY_TEMPLATE = "COPY {REDSHIFT_TABLE} FROM '{PARQUET_FILE_LOC}' IAM_ROLE '{ARN_ROLE}' FORMAT AS PARQUET;"
        self.ATHENA_UNLOAD_QUERY_TEMPLATE = ""
        self.MAIN_TABLE_NAME = ""
        self.ATHENA_TABLE_NAME = ""

    def get_env_variables(self):
        self.storage_name = os.environ["STORAGE_NAME"]
        self.PARQUET_FILE_LOC = (
            "s3://"
            + os.environ["STORAGE_NAME"]
            + "/flowsource-agent-data/athena-output-files/"
        )
        self.ATHENA_DATABASE = os.environ["ATHENA_DATABASE_NAME"]
        self.REDSHIFT_DATABASE = os.environ["DATABASE_NAME"]
        self.REDSHIFT_DATABASE_SCHEMA = "flowsource"

        self.ARN_ROLE = os.environ["ARN_ROLE"]
        

    def processQuery(self, parameters):
        # Execute commands based on the order provided
        try:
            for parm in parameters:
                #Split the commands based on colon
                commands = parm.split(": ")
                match commands[0]:
                    case "PARQUET_FILE_LOC":
                        #Set the Parquet file location
                        self.parquet_file_loc = commands[1]
                    case "UNLOAD_QUERY":
                        #Execute Athena Unload query
                        self.athena_unload_as_parquet(commands[1], self.parquet_file_loc)
                        self.logger.info(f"The parquet file location is {self.parquet_file_loc}")
                    case "COPY_QUERY":
                        #Execute copy query
                        self.copy_query = commands[1]
                        self.database_access.execute_query_in_redshift(self.copy_query)
                        self.logger.info("Successfully copied parquet file to Redshift!")
                    case "MERGE_QUERY":
                        #Execute merge query
                        self.merge_query = commands[1]
                        self.database_access.execute_query_in_redshift(self.merge_query)
                        self.logger.info("Successfully merge data from staging table to main table in Redshift!")
                    case "DELETE_STAGING_QUERY":
                        #Delete staging table in redshift
                        self.database_access.execute_query_in_redshift(commands[1])
                        self.logger.info("Successfully deleted data from staging table in Redshift!")
                    case "DELETE_RECORDS_QUERY":
                        #Delete records from main table that are not available in staging table
                        self.database_access.execute_query_in_redshift(commands[1])
                        self.logger.info("Successfully deleted records from main table not available in staging table, if any!")
                    case "CREATE_TEMP_QUERY":
                        #Create temporary table
                        queries = commands[1].split(';')
                        self.database_access.execute_query_in_redshift(queries[0], queries[1], queries[2])
                        self.logger.info("Successfully Executed Query in Redshift!")
                    case _:
                        raise ValueError(f'1102 - FLOWSOURCE_ENGINE_QUERY_ERROR:{commands[0]} Command not found')
        except Exception as e:
            self.logger.exception(f"1101 - FLOWSOURCE_ENGINE_QUERY_ERROR: Failed to process processQuery {e}")
            raise e

    def athena_unload_as_parquet(self,unload_query, output_loc):
        
        # unload
        query_execution_id = self.engineQuery_access.execute_athena_query(unload_query, output_loc)
        output_key = self.fileUtils.extract_s3_key_path(output_loc)
               
        # delete csv file
        csv_file =  output_key + '/' + query_execution_id + '-manifest.csv'
        self.storage_access.delete_storage_object(self.storage_name, csv_file)
        
        # delete metadata file
        metadata_file = output_key + '/' + query_execution_id + '.metadata'
        self.storage_access.delete_storage_object(self.storage_name, metadata_file)
    
    def copy_file_to_dlq(self, error_message):
        #If any Exception/Error occurred upload the failed JSON and Error Message in Storage by DeadLetterQueue
        self.logger.info(f"Processing DeadLetter Queue...")
        deadLetterDataProcessing = DeadLetterQueue(self.cloud_provider, self.tool_name, self.json_file_path, self.storage_access)
        deadLetterDataProcessing.upload_file_to_dlq(error_message)
        self.logger.info(f"Processed DeadLetter Queue...")

    def format_unload_query(self, athena_unload_query_temp, engineExecutionTime, athena_table_name, output_loc):
        # Formatting unload query
        ATHENA_UNLOAD_QUERY = athena_unload_query_temp.format(
            ENGINE_EXECUTION_TIME=engineExecutionTime,
            ATHENA_DATABASE=self.ATHENA_DATABASE,
            ATHENA_TABLE=athena_table_name,
            JSON_FILE_NAME=self.json_file_name,
            PARQUET_FILE_LOC=output_loc,
        )
        return ATHENA_UNLOAD_QUERY
    
    def format_copy_query(self, copy_query_temp, main_table_name, output_loc):
        # Formatting copy query
        COPY_QUERY = copy_query_temp.format(
            REDSHIFT_TABLE=self.REDSHIFT_DATABASE
            + "."
            + self.REDSHIFT_DATABASE_SCHEMA
            + "."
            + main_table_name,
            PARQUET_FILE_LOC=output_loc,
            ARN_ROLE=self.ARN_ROLE,
        )
        return COPY_QUERY
    

    @flowsource_exception_handler
    def execute_pipeline(self):
        # Check whether all the required values are provided in the child class
        self.do_health_checks()

        # Creating all the queries
        engineExecutionTime = TimeUtils().get_current_time()

        folder_name = self.tool_name + "-" + str(uuid.uuid4())
        output_loc = self.PARQUET_FILE_LOC + folder_name

        ATHENA_UNLOAD_QUERY = self.format_unload_query(self.ATHENA_UNLOAD_QUERY_TEMPLATE, engineExecutionTime, self.ATHENA_TABLE_NAME, output_loc)
        COPY_QUERY = self.format_copy_query(self.COPY_QUERY_TEMPLATE, self.MAIN_TABLE_NAME, output_loc)

        # Set the parameters to be executed in order
        parameters = [
            f"PARQUET_FILE_LOC: {output_loc}",
            f"UNLOAD_QUERY: {ATHENA_UNLOAD_QUERY}",
            f"COPY_QUERY: {COPY_QUERY}"
        ]

        # Execute the queries beased on the order of parameters passed
        self.processQuery(parameters)
    
    def do_health_checks(self):
        if self.MAIN_TABLE_NAME == '':
            self.logger.error('1001 - FLOWSOURCE_BASEENGINE_ERROR: MAIN_TABLE_NAME should not be empty')
            raise ValueError('1001 - FLOWSOURCE_BASEENGINE_ERROR: MAIN_TABLE_NAME should not be empty')
        elif self.ATHENA_TABLE_NAME == '':
            self.logger.error('1002 - FLOWSOURCE_BASEENGINE_ERROR: ATHENA_TABLE_NAME should not be empty')
            raise ValueError('1002 - FLOWSOURCE_BASEENGINE_ERROR: ATHENA_TABLE_NAME should not be empty')
        elif self.ATHENA_UNLOAD_QUERY_TEMPLATE == '':
            self.logger.error('1003 - FLOWSOURCE_BASEENGINE_ERROR: ATHENA_UNLOAD_QUERY_TEMPLATE should not be empty')
            raise ValueError('1003 - FLOWSOURCE_BASEENGINE_ERROR: ATHENA_UNLOAD_QUERY_TEMPLATE should not be empty')
        else:
            self.logger.info("All required values are provided")