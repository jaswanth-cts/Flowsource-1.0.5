import urllib.parse
import sys
import json
from DataEngine import DataEngine
from utils.FlowsourceLogger import FlowsourceLogger

sys.path.append("/var/task")

def lambda_handler(event, context):

    #json with storage file path
    json_file_path = urllib.parse.unquote_plus(
        event["Records"][0]["s3"]["object"]["key"], encoding="utf-8"
    )

    json_file_name = json_file_path.split("/")[-1]
    tool_category = (json_file_name.lower()).split('-')[0]
    if tool_category == "catalog":
        tool_name = "system." + tool_category
    else:
        tool_name = tool_category + "." + (json_file_name.lower()).split('-')[1]
    
    logger = FlowsourceLogger(tool_name.split('.')[1]) 
    
    try:
        
        logger.info("Loading function Lambda-PlatformEngine-DataEngine ...")
        logger.info(f"Processing json: {json_file_path} ...")
          
        engine = DataEngine('AWS', tool_name, json_file_path)
        engine.processDataEngine()

        response = {
            "statusCode": 200,
            "body": json.dumps(
                {"message": "Data Engine Processing completed."}
            ),
        }
    
    except Exception as e:
        logger.exception(f"FLOWSOURCE_DATA_ENGINE_PROCESSING_EXCEPTION: Error Processing Data Engine {str(e)}")
        response = {
            "statusCode": 500,
            "body": json.dumps({"message": "Internal server error.", "error": str(e)}),
        }
    logger.info(f'Response: {response}')
    logger.flush()
    return response