import json
from SnowAgent import SnowAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        snow_Agent = SnowAgent(cloud_provider)
        snow_Agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Snow Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Snow Agent", "error": str(e)
            })
        }