import json
from VeracodeAgent import VeracodeAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = VeracodeAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Veracode Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing Veracode Agent", "error": str(e)
            })
        }