import json
from AzureBoardsAgent import AzureBoardsAgent

def lambda_handler(event, context):
    try:
        cloud_provider = 'AWS'
        agent = AzureBoardsAgent(cloud_provider)
        agent.process()
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "AzureBoardsAgent Agent Execution Completed Successfully ...",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error while processing AzureBoardsAgent Agent", "error": str(e)
            })
        }