# multi_agent_system_aws/agents/agents.py

from typing import Any, Dict, List, Generator, Optional  
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

class Agent(ABC):
    def __init__(self,
        name: str,  
        description: str,  
        system_prompt: Optional[str] = None,  
        model_id: Optional[str] = None,
        region: Optional[str] = None):
        self.name = name
        self.description = description
        self.system_prompt = system_prompt
        self.model_id = model_id
        self.region = region
    
    @abstractmethod  
    async def retrieve_context(self, user_id: str, session_id: str, query: str) -> str:  
        pass  
  
    @abstractmethod  
    async def process_query(  
        self,  
        user_id: str,  
        session_id: str,  
        user_query: str,  
        interaction_history: List[Dict[str, Any]]  
    ) -> Generator[str, None, None]:  
        pass