# multi_agent_system_aws/storage/__init__.py

from .memory_storage import MemoryStorage
from .dynamodb_storage import DynamoDBStorage