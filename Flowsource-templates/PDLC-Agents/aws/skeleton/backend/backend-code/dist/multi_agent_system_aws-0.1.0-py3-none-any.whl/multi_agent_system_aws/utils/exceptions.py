# multi_agent_system_aws/utils/exceptions.py

class ProviderError(Exception):
    """Custom exception for provider-related errors."""
    pass

class AgentError(Exception):
    """Custom exception for agent-related errors."""
    pass
