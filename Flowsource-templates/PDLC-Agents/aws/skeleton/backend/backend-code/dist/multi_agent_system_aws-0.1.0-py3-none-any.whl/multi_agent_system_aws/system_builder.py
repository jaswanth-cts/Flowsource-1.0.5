# system_builder.py

import json
from multi_agent_system_aws.multi_agent import MultiAgentSystem
from multi_agent_system_aws.storage.memory_storage import MemoryStorage
from multi_agent_system_aws.storage.dynamodb_storage import DynamoDBStorage
from multi_agent_system_aws.agents.bedrock_agent import BedrockAgent
from multi_agent_system_aws.agents.llm_agent import LLMAgent
from multi_agent_system_aws.retrievers.bedrock_retriever import BedrockRetriever
from multi_agent_system_aws.coordinator.bedrock_coordinator import BedrockCoordinator
from typing import Optional

class SystemBuilder:
    def __init__(self, config_path: str):
        self.config_path = config_path
        self.config = self.load_config()
        self.storage = self.create_storage()
        self.coordinator = self.create_coordinator()
        self.multi_agent_system = MultiAgentSystem(
            storage=self.storage,
            coordinator=self.coordinator
        )
        self.build_agents()

    def load_config(self) -> dict:
        with open(self.config_path, 'r') as f:
            return json.load(f)

    def create_storage(self):
        storage_config = self.config.get('storage', {})
        storage_type = storage_config.get('type', 'MemoryStorage')
        if storage_type == 'MemoryStorage':
            max_window_size = storage_config.get('max_window_size', 3)
            return MemoryStorage(max_window_size=max_window_size)
        elif storage_type == 'DynamoDBStorage':
            max_window_size = storage_config.get('max_window_size', 3)
            region = storage_config['region']
            table_name = storage_config['table_name']
            return DynamoDBStorage(
                                table_name=table_name,
                                region_name=region,
                                max_window_size=max_window_size
                            )
        else:
            raise ValueError(f"Unknown storage type: {storage_type}")

    def create_coordinator(self):
        coordinator_config = self.config.get('coordinator', {})
        coordinator_type = coordinator_config.get('type', 'BedrockCoordinator')
        if coordinator_type == 'BedrockCoordinator':
            model_id = coordinator_config.get('model_id', 'anthropic.claude-3-5-sonnet-20240620-v1:0')
            region = coordinator_config.get('region', 'us-west-2')
            return BedrockCoordinator(
                model_id=model_id,
                region=region,
                storage=self.storage
            )
        else:
            raise ValueError(f"Unknown coordinator type: {coordinator_type}")

    def build_agents(self):
        for agent_config in self.config.get('agents', []):
            agent = self.create_agent(agent_config)
            if agent:
                default_agent = agent_config.get('default_agent', False)
                self.multi_agent_system.add_agent(agent)
                if default_agent:
                    self.multi_agent_system.default_agent = agent

    def create_agent(self, agent_config: dict) -> Optional[object]:
        # Extract common agent details
        name = agent_config['name']
        description = agent_config['description']
        agent_type = agent_config.get('agent_type', 'LLMAgent')
        region = agent_config.get('region', 'us-west-2')
        citation = agent_config.get('citation', True)

        if agent_type == 'LLMAgent':
            # Extract LLMAgent-specific configurations
            system_prompt = agent_config['system_message']
            rag_enabled = agent_config.get('rag_enabled', False)
            tool_enabled = agent_config.get('tool_enabled', False)
            llm_config = agent_config.get('llm_config', {})
            additionalmodelrequestfields = agent_config.get('additionalModelRequestFields', {})
            guardrailconfig = agent_config.get('guardrailConfig', {})
            streaming = agent_config.get('streaming', False)

            # Initialize the retriever if RAG is enabled
            retriever = None
            if rag_enabled:
                rag_config = agent_config['rag_config']
                knowledge_base_id = rag_config['knowledge_base_id']
                retrieval_config = rag_config['retrieval_configuration']
                retriever = BedrockRetriever(
                    region_name=region,
                    knowledge_base_id=knowledge_base_id,
                    retrieval_config=retrieval_config
                )

            # If tool_enabled is True, set tool_config from agent_config
            tool_config = None
            if tool_enabled:
                tool_config = agent_config.get('tool_config', None)

            agent_options = {
                'retriever': retriever,
                'llm_config': {
                    'temperature': llm_config.get('temperature', 0.7),
                    'top_p': llm_config.get('top_p', 0.95),
                    'max_token_count': llm_config.get('max_token_count', 512),
                },
                'additionalModelRequestFields': additionalmodelrequestfields,
                'tool_config': tool_config,
                'callbacks': None,
                'client': None,
                'storage': self.storage,
                'max_window_size': None,
                'guardrail_config': guardrailconfig,
                'logger': None,
                'citation': citation
            }

            # Create the LLMAgent
            agent = LLMAgent(
                name=name,
                description=description,
                system_prompt=system_prompt,
                model_id=llm_config.get('model_id', 'anthropic.claude-3-opus'),
                region=region,
                streaming=streaming,
                agent_options=agent_options
            )
            return agent
        elif agent_type == 'BedrockAgent':
            # Extract BedrockAgent-specific configurations
            agent_id = agent_config['agent_id']
            agent_alias_id = agent_config['agent_alias_id']

            agent = BedrockAgent(
                name=name,
                description=description,
                agent_id=agent_id,
                agent_alias_id=agent_alias_id,
                region=region,
                citation=citation
            )
            return agent
        else:
            print(f"Unknown agent type: {agent_type}")
            return None

    def get_multi_agent_system(self) -> MultiAgentSystem:
        return self.multi_agent_system