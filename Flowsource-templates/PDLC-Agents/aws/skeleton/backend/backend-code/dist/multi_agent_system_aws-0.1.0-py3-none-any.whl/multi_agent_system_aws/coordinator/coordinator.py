# multi_agent_system_aws/coordinator/coordinator.py

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass
from multi_agent_system_aws.agents import Agent
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger
import re

TemplateVariables = Dict[str, Union[str, List[str]]]

@dataclass
class CoordinatorResult:
    selected_agent: Optional[Agent]
    #confidence: float

class Coordinator(ABC):
    def __init__(self, max_window_size: Optional[int] = None, logger: Optional[MultiAgentSystemLogger] = None):
        self.name = "Coordinator"
        self.system_prompt = ""
        self.max_window_size = max_window_size
        self.logger = logger or MultiAgentSystemLogger()
        self.agent_descriptions = ""
        self.history = ""
        self.custom_variables: Dict[str, Union[str, List[str]]] = {}
        self.prompt_template = """You are a system coordinator that routes user queries to the most suitable agent.

<agents>
{{AGENT_DESCRIPTIONS}}
</agents>
If you are unable to select an agent put "unkwnown"

Handle variations in user input, including different phrasings, synonyms,
and potential spelling errors.
For short responses like "yes", "ok", "I want to know more", or numerical answers,
treat them as follow-ups and maintain the previous agent selection.

Here is the conversation history that you need to take into account before answering:
<history>
{{HISTORY}}
</history>

Examples:

1. Initial query with no context:
User: "What are the symptoms of the flu?"

userinput: What are the symptoms of the flu?
selected_agent: agent-name
confidence: 0.95

Skip any preamble and provide only the response in the specified format.

"""

    def set_agents(self, agents: Dict[str, Agent]) -> None:
        self.agent_descriptions = "\n\n".join(f"{agent.name}: {agent.description}" for agent in agents.values())
        self.agents = agents

    def enforce_max_window_size(self, interaction_history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if self.max_window_size is not None and len(interaction_history) > self.max_window_size:
            interaction_history = interaction_history[-self.max_window_size:]
        return interaction_history

    @abstractmethod
    def process_request(self, user_query: str, interaction_history: List[Dict[str, Any]]) -> CoordinatorResult:
        pass

    def set_system_prompt(self, system_prompt: str) -> None:
        self.system_prompt = system_prompt

    def get_agent_by_name(self, agent_name: str) -> Optional[Agent]:
        return self.agents.get(agent_name)

    def set_history(self, messages) -> None:
        self.history = self.format_messages(messages)

    @staticmethod
    def format_messages(messages) -> str:
        return "\n".join([
            f"{message['role']}: {' '.join([message['content']])}" for message in messages
        ])
    def update_system_prompt(self) -> None:

        all_variables: TemplateVariables = {
            **self.custom_variables,
            "AGENT_DESCRIPTIONS": self.agent_descriptions,
            "HISTORY": self.history,
        }
        self.system_prompt = self.replace_placeholders(self.prompt_template, all_variables)

    @staticmethod
    def replace_placeholders(template: str, variables: {Dict[str, Union[str, List[str]]]}) -> str:

        return re.sub(r'{{(\w+)}}',
                      lambda m: '\n'.join(variables.get(m.group(1), [m.group(0)]))
                      if isinstance(variables.get(m.group(1)), list)
                      else variables.get(m.group(1), m.group(0)), template)