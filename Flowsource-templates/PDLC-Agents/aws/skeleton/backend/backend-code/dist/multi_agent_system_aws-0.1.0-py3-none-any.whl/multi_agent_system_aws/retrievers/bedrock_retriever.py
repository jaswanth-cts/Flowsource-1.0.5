# multi_agent_system_aws/retrievers/bedrock_retriever.py

import json
import logging
import boto3
from typing import Dict, Any
from botocore.exceptions import ClientError
from multi_agent_system_aws.retrievers.base_retriever import BaseRetriever
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger


class BedrockRetriever(BaseRetriever):
    def __init__(self, region_name: str, knowledge_base_id: str, retrieval_config: Dict[str, Any]):
        self.client = boto3.client('bedrock-agent-runtime', region_name=region_name)
        self.knowledge_base_id = knowledge_base_id
        self.retrieval_config = retrieval_config
        self.citation = []
        self.logger = MultiAgentSystemLogger()

    def retrieve(self, query: str, **kwargs) -> str:
        try:
            response = self.client.retrieve(
                retrievalQuery={'text': query},
                knowledgeBaseId=self.knowledge_base_id,
                retrievalConfiguration=self.retrieval_config
            )
            retrieval_results = response.get('retrievalResults', [])
            context = self._combine_retrieval_results(retrieval_results)
            return context
        except ClientError as e:
            self.logger.error(f"Unable to retrieve context. Reason: {e}")
            return ''

    def _combine_retrieval_results(self, retrieval_results):
        context = ''
        for result in retrieval_results:
            content = result['content']['text']
            source = result['location']['s3Location']['uri'].split("/")[-1]
            context_item = {source: content}
            self.citation.append(context_item)
            context += content + '\n\n'
        return context.strip()