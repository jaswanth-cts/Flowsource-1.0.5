# multi_agent_system_aws/retrievers/base_retriever.py

from abc import ABC, abstractmethod
from typing import Any

class BaseRetriever(ABC):
    @abstractmethod
    def retrieve(self, query: str, **kwargs) -> Any:
        """Retrieve context or data based on the query."""
        pass
