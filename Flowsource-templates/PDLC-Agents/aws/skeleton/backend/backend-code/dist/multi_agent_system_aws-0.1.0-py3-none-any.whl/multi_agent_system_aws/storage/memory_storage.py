# multi_agent_system_aws/storage/memory_storage.py

from typing import Any, List, Dict, Optional
from .base_storage import BaseStorage
import time
import logging
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger

class MemoryStorage(BaseStorage):
    def __init__(self, max_window_size: int = None):
        # A shared memory for all conversations indexed by user_id and session_id
        self._store: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        max_window_size = max_window_size or 5
        max_window_size = max_window_size * 2
        self.max_window_size = max_window_size
        self.logger = MultiAgentSystemLogger()

    def save(self, user_id: str, session_id: str, value: Dict[str, Any]) -> None:
        #Formats and saves a message to the conversation history.
        # Ensure value is correctly formatted
        formatted_value = self._format_message(value)

        if user_id not in self._store:
            self._store[user_id] = {}
        if session_id not in self._store[user_id]:
            self._store[user_id][session_id] = []

        # Save the formatted message to the conversation history
        self._store[user_id][session_id].append(formatted_value)
        # Trim conversation if it exceeds max window size
        self._store[user_id][session_id] = self.trim_conversation(self._store[user_id][session_id])

    def load(self, user_id: str, session_id: str) -> Optional[List[Dict[str, Any]]]:
        #Loads the conversation history and removes timestamps before returning.
        conversation = self._store.get(user_id, {}).get(session_id, [])
        return self._remove_timestamps(conversation)

    def delete(self, user_id: str, session_id: str) -> None:
        if user_id in self._store and session_id in self._store[user_id]:
            del self._store[user_id][session_id]

    def list_sessions(self, user_id: str) -> list:
        return list(self._store.get(user_id, {}).keys())

    def trim_conversation(self, conversation: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        # Trims the conversation to the maximum window size.
        if self.max_window_size is not None and len(conversation) > self.max_window_size and conversation[-1]['role'] != 'user':
            return conversation[-self.max_window_size:]
        return conversation

    def _format_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        # Format message to ensure it contains role, content, and timestamp
        if "role" not in message or "content" not in message:
            self.logger.error(f"Invalid message format: {message}")
            raise ValueError("Each message must have 'role' and 'content' fields.")

        return {
            "role": message["role"],
            "content": message["content"],
            "timestamp": time.time() * 1000  # Timestamp in milliseconds
        }

    def _remove_timestamps(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        # Remove timestamp before returning conversation history
        return [{"role": message["role"], "content": message["content"]} for message in messages]