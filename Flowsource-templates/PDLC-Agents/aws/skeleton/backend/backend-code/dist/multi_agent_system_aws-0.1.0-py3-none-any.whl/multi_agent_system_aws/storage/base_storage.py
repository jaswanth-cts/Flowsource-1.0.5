# multi_agent_system_aws/storage/base_storage.py

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, List

class BaseStorage(ABC):
    @abstractmethod
    def save(self, user_id: str, session_id: str, value: Any) -> None:
        pass

    @abstractmethod
    def load(self, user_id: str, session_id: str) -> Optional[List[Dict[str, Any]]]:
        pass

    @abstractmethod
    def delete(self, user_id: str, session_id: str) -> None:
        pass

    @abstractmethod
    def list_sessions(self, user_id: str) -> list:
        pass