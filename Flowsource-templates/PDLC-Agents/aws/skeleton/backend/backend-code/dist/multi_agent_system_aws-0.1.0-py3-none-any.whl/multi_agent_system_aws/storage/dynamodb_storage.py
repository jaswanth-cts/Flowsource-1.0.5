# multi_agent_system_aws/storage/dynamodb_storage.py

import boto3
from botocore.exceptions import ClientError
from typing import Any, Dict, Optional, List
from .base_storage import BaseStorage
import logging
import time
from boto3.dynamodb.conditions import Key
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger


class DynamoDBStorage(BaseStorage):
    def __init__(self, table_name: str, region_name: Optional[str] = None, max_window_size: int = None):
        self.table_name = table_name
        self.client = boto3.resource('dynamodb', region_name=region_name)
        self.table = self.client.Table(table_name)
        max_window_size = max_window_size or 5
        self.max_window_size = max_window_size * 2  # To match MemoryStorage behavior
        self.logger = MultiAgentSystemLogger()

    def save(self, user_id: str, session_id: str, value: Dict[str, Any]) -> None:
        try:
            # Format the message
            formatted_value = self._format_message(value)

            # Construct the composite partition key
            user_session_key = f"{user_id}#{session_id}"
            timestamp = formatted_value['timestamp']

            # Save the message as a separate item
            item = {
                'PK': user_session_key,
                'SK': timestamp,
                'UserId': user_id,
                'SessionId': session_id,
                'Role': formatted_value['role'],
                'Content': formatted_value['content'],
                'Timestamp': timestamp
            }

            self.table.put_item(Item=item)
            
        except ClientError as e:
            self.logger.error(f"Error saving item to DynamoDB: {e}")
            raise e
        except Exception as e:
            self.logger.error(f"Unexpected error during saving to DynamoDB: {e}")
            raise e

    def load(self, user_id: str, session_id: str) -> Optional[List[Dict[str, Any]]]:
        try:
            user_session_key = f"{user_id}#{session_id}"
            response = self.table.query(
                KeyConditionExpression=Key('PK').eq(user_session_key),
                ScanIndexForward=True  # Ensures messages are returned in ascending order by SK (Timestamp)
            )
            items = response.get('Items', [])

            # Trim conversation if it exceeds max window size
            if self.max_window_size is not None and len(items) > self.max_window_size:
                items = items[-self.max_window_size:]

            # Remove timestamps and format messages
            messages = [
                {
                    'role': item['Role'],
                    'content': item['Content']
                }
                for item in items
            ]
            return messages if messages else None
        except ClientError as e:
            self.logger.error(f"Error loading conversation from DynamoDB: {e}")
            return None

    def delete(self, user_id: str, session_id: str) -> None:
        try:
            user_session_key = f"{user_id}#{session_id}"
            # Query all items for the user session
            response = self.table.query(
                KeyConditionExpression=Key('PK').eq(user_session_key),
                ProjectionExpression='PK, SK'
            )
            items = response.get('Items', [])
            with self.table.batch_writer() as batch:
                for item in items:
                    batch.delete_item(
                        Key={
                            'PK': item['PK'],
                            'SK': item['SK']
                        }
                    )
        except ClientError as e:
            self.logger.error(f"Error deleting conversation from DynamoDB: {e}")

    def list_sessions(self, user_id: str) -> List[str]:
        try:
            # Use the GSI to query all sessions for the user
            response = self.table.query(
                IndexName='UserSessionsIndex',
                KeyConditionExpression=Key('UserId').eq(user_id),
                ProjectionExpression='SessionId',
                Select='SPECIFIC_ATTRIBUTES',
                Distinct=True  # Ensure sessions are unique
            )
            sessions = {item['SessionId'] for item in response.get('Items', [])}
            return list(sessions)
        except ClientError as e:
            self.logger.error(f"Error listing sessions from DynamoDB: {e}")
            return []

    def _format_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        # Ensure message has 'role' and 'content'
        if "role" not in message or "content" not in message:
            self.logger.error(f"Invalid message format: {message}")
            raise ValueError("Each message must have 'role' and 'content' fields.")
        return {
            "role": message["role"],
            "content": message["content"],
            "timestamp": int(time.time() * 1000)  # Timestamp in milliseconds
        }