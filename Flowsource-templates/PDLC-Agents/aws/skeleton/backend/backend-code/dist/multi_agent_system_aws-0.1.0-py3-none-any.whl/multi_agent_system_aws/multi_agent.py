# multi_agent_system_aws/multi_agent.py

from typing import Dict, Any, Optional, AsyncIterable,Iterable, List
from dataclasses import dataclass, replace, asdict
from multi_agent_system_aws.coordinator.coordinator import Coordinator, CoordinatorResult
from multi_agent_system_aws.coordinator.bedrock_coordinator import BedrockCoordinator
from multi_agent_system_aws.agents import Agent
from multi_agent_system_aws.storage.memory_storage import MemoryStorage
from multi_agent_system_aws.storage.base_storage import BaseStorage
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger

@dataclass
class MultiAgentSystem:
    def __init__(self, storage: Optional[BaseStorage] = None, coordinator: Optional[Coordinator] = None, max_window_size: Optional[int] = None, logger: Optional[MultiAgentSystemLogger] = None):
        self.logger = logger or MultiAgentSystemLogger()
        self.storage = storage or MemoryStorage(max_window_size=max_window_size)
        self.coordinator = coordinator or BedrockCoordinator(model_id="default_model", region="us-west-2", storage=self.storage, max_window_size=max_window_size, logger=self.logger)
        self.agents: Dict[str, Agent] = {}
        self.max_window_size = max_window_size

    def add_agent(self, agent: Agent):
        if agent.name in self.agents:
            raise ValueError(f"An agent with name '{agent.name}' already exists.")
        if 'storage' in dir(agent):
            agent.storage = self.storage
        self.agents[agent.name] = agent
        self.coordinator.set_agents(self.agents)

    def get_all_agents(self) -> Dict[str, Dict[str, str]]:
        return {key: {
            "name": agent.name,
            "description": agent.description
        } for key, agent in self.agents.items()}

    def process_user_query(self, user_id: str, session_id: str, user_query: str,
                       images: Optional[List[Dict[str, Any]]] = None) -> Iterable[Dict[str, Any]]:
        interaction_history = self._load_interaction_history(user_id, session_id)

        coordinator_result = self._determine_coordinator_result(user_id, session_id, user_query, interaction_history, images)
        if isinstance(coordinator_result, str):
            # It's an error message returned as a string
            yield {"error": coordinator_result}
            return

        selected_agent = coordinator_result.selected_agent
        if not selected_agent:
            yield {"error": "ERROR: No suitable agent found to handle the request."}
            return

        # Remove last user message if needed
        interaction_history = self._adjust_interaction_history(interaction_history)
        yield from self._generate_agent_response(selected_agent, user_id, session_id, user_query, interaction_history, images)


    def _load_interaction_history(self, user_id: str, session_id: str) -> List[Dict[str, Any]]:
        stored_history = self.storage.load(user_id, session_id)
        return stored_history if stored_history else []


    def _determine_coordinator_result(self, user_id: str, session_id: str, user_query: str,
                                    interaction_history: List[Dict[str, Any]], images: Optional[List[Dict[str, Any]]]) -> Any:
        try:
            if images:
                # If images are provided, directly select the default agent if available
                if hasattr(self, 'default_agent') and self.default_agent:
                    return CoordinatorResult(selected_agent=self.default_agent)
                return "ERROR: No default agent available to handle images."
            else:
                coordinator_result = self.coordinator.process_request(user_id, session_id, user_query, interaction_history)
                if not coordinator_result.selected_agent and hasattr(self, 'default_agent'):
                    coordinator_result.selected_agent = self.default_agent
                    self.logger.info("No suitable agent found; selecting default agent.")
                return coordinator_result
        except Exception as error:
            self.logger.error(f"Error determining coordinator result: {str(error)}")
            return f"ERROR: {str(error)}"


    def _adjust_interaction_history(self, interaction_history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        # Remove last user message if needed
        if interaction_history and interaction_history[-1]['role'] == 'user':
            return interaction_history[:-1]
        return interaction_history


    def _generate_agent_response(self, selected_agent: Agent, user_id: str, session_id: str,
                                user_query: str, interaction_history: List[Dict[str, Any]],
                                images: Optional[List[Dict[str, Any]]]) -> Iterable[Dict[str, Any]]:
        try:
            self.logger.info(f"Selected agent: {selected_agent.name}")
            response_generator = selected_agent.process_query(user_id, session_id, user_query, interaction_history, images)
            for data in response_generator:
                yield data
        except Exception as error:
            self.logger.error(f"Error during user query processing: {str(error)}")
            yield {"error": f"ERROR: {str(error)}"}


    def set_default_agent(self, agent: Agent):
        self.default_agent = agent

    def get_default_agent(self) -> Agent:
        return self.default_agent