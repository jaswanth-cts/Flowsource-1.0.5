# multi_agent_system_aws/coordinator/bedrock_coordinator.py

import os
import time
import random
from typing import List, Optional, Dict, Any
import boto3
from botocore.exceptions import BotoCoreError, ClientError
from multi_agent_system_aws.utils.helper import is_tool_input
from multi_agent_system_aws.coordinator.coordinator import Coordinator, CoordinatorResult
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger


class BedrockCoordinator(Coordinator):
    def __init__(
        self,
        model_id: str,
        region: str,
        storage,
        llm_config: Optional[Dict] = None,
        client: Optional[Any] = None,
        max_window_size: Optional[int] = None,
        logger: Optional[MultiAgentSystemLogger] = None,
    ):
        super().__init__(max_window_size=max_window_size, logger=logger)
        self.model_id = model_id
        self.region = region or os.environ.get('AWS_REGION')
        self.storage = storage
        self.inference_config = llm_config if llm_config is not None else {}
        self.client = client or boto3.client('bedrock-runtime', region_name=self.region)
        
        self.llm_config = {
            'maxTokens': self.inference_config.get('maxTokens', 1000),
            'temperature': self.inference_config.get('temperature', 0.0),
            'topP': self.inference_config.get('top_p', 0.9),
            'stopSequences': self.inference_config.get('stop_sequences', [])
        }

        self.tools = [
            {
                "toolSpec": {
                    "name": "analyzePrompt",
                    "description": "Analyze the user input and provide structured output",
                    "inputSchema": {
                        "json": {
                            "type": "object",
                            "properties": {
                                "userinput": {
                                    "type": "string",
                                    "description": "The original user input",
                                },
                                "selected_agent": {
                                    "type": "string",
                                    "description": "The name of the selected agent",
                                }
                            },
                            "required": ["userinput", "selected_agent"],
                        },
                    },
                },
            },
        ]

    def _make_request_with_retry(self, converse_cmd: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform the Bedrock `converse` request with exponential backoff and jitter.
        Retries multiple times on transient errors before giving up.
        """
        max_retries = 5
        base_delay = 30  # base delay in seconds
        for attempt in range(1, max_retries + 1):
            try:
                response = self.client.converse(**converse_cmd)
                return response
            except (BotoCoreError, ClientError, Exception) as e:
                if attempt == max_retries:
                    # After max retries, re-raise the exception
                    raise
                # exponential backoff with jitter
                sleep_time = base_delay * (2 ** (attempt - 1)) + random.uniform(0, base_delay)
                self.logger.warning(f"Error during Bedrock model inference attempt {attempt}: {str(e)}. Retrying in {sleep_time:.2f}s...")
                time.sleep(sleep_time)

    def process_request(self, user_id: str, session_id: str, user_query: str, interaction_history: List[Dict[str, Any]]) -> CoordinatorResult:
        if interaction_history:
            self.set_history(interaction_history)

        # Update system prompt with agent descriptions
        self.update_system_prompt()

        user_message = {"role": "user", "content": [{"text": user_query}]}
        interaction_history.append(user_message)

        converse_cmd = self._build_converse_cmd(user_message)

        self.logger.info(f"Sending request to Bedrock model: {self.model_id}")
        response = self._invoke_with_retry(converse_cmd)
        if response is None:
            return CoordinatorResult(selected_agent=None)

        return self._process_response_content(response)
    
    def _build_converse_cmd(self, user_message: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "modelId": self.model_id,
            "messages": [user_message],
            "system": [{"text": self.system_prompt}],
            "toolConfig": {
                "tools": self.tools,
            },
            "inferenceConfig": self.llm_config,
        }
    
    def _invoke_with_retry(self, converse_cmd: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            return self._make_request_with_retry(converse_cmd)
        except (BotoCoreError, ClientError, Exception) as error:
            self.logger.error(f"Error during Bedrock model inference after retries: {str(error)}")
            return None
    
    def _process_response_content(self, response: Dict[str, Any]) -> CoordinatorResult:
        if not response.get('output'):
            return CoordinatorResult(selected_agent=None)

        message = response['output'].get('message', {})
        content_blocks = message.get('content', [])
        if not content_blocks:
            return CoordinatorResult(selected_agent=None)

        tool_use = self._extract_tool_use(content_blocks)
        if not tool_use:
            return CoordinatorResult(selected_agent=None)

        if not is_tool_input(tool_use['input']):
            return CoordinatorResult(selected_agent=None)

        selected_agent = self.get_agent_by_name(tool_use['input']['selected_agent'])
        return CoordinatorResult(selected_agent=selected_agent)
    
    def _extract_tool_use(self, content_blocks: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        for block in content_blocks:
            if 'toolUse' in block:
                return block['toolUse']
        return None

    def enforce_max_window_size(self, interaction_history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Ensures that the interaction history doesn't exceed the maximum window size.
        """
        if self.max_window_size is not None and len(interaction_history) > self.max_window_size:
            return interaction_history[-self.max_window_size:]
        return interaction_history