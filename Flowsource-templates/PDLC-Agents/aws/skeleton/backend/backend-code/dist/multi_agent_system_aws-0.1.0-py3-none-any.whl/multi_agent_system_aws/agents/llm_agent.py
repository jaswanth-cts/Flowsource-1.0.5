# multi_agent_system_aws/agents/llm_agent.py

import boto3
import time
from .agent import Agent
from typing import Any, Dict, List, Generator, Optional, Iterable, Tuple, Union
from botocore.exceptions import ClientError
from multi_agent_system_aws.storage.memory_storage import MemoryStorage
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger

class LLMAgent(Agent):
    def __init__(
        self,
        name: str,
        description: str,
        system_prompt: str,
        model_id: str,
        region: str,
        streaming: bool,
        agent_options: Dict[str, Any],
    ):
        super().__init__(name, description, system_prompt, model_id, region)

        # Unpack agent_options dictionary
        retriever = agent_options.get('retriever')
        llm_config = agent_options.get('llm_config', {})
        additionalmodelrequestfields = agent_options.get('additionalModelRequestFields', {})
        tool_config = agent_options.get('tool_config')
        callbacks = agent_options.get('callbacks')
        client = agent_options.get('client')
        storage = agent_options.get('storage', MemoryStorage())
        guardrail_config = agent_options.get('guardrail_config', {})
        logger = agent_options.get('logger', MultiAgentSystemLogger())

        self.streaming = streaming
        self.retriever = retriever

        # Initialize default LLM config if not provided
        default_llm_config = {
            'maxTokens': 1000,
            'temperature': 0.0,
            'topP': 0.9,
            'stopSequences': []
        }
        # Convert provided keys in llm_config to match default keys
        merged_llm_config = {
            'maxTokens': llm_config.get('max_token_count', 512),
            'temperature': llm_config.get('temperature', 0.7),
            'topP': llm_config.get('top_p', 0.95),
            'stopSequences': default_llm_config['stopSequences']
        }
        self.llm_config = {**default_llm_config, **merged_llm_config}

        self.tool_config = tool_config
        self.callbacks = callbacks
        self.client = client or boto3.client('bedrock-runtime', region_name=region)
        self.storage = storage
        self.guardrail_config: Optional[Dict[str, str]] = guardrail_config
        self.additionalmodelrequestfields = additionalmodelrequestfields
        self.logger = logger or MultiAgentSystemLogger()

    def retrieve_context(self, user_id: str, session_id: str, query: str) -> str:
        if self.retriever:
            response = self.retriever.retrieve(query)
            context_prompt = "\nHere is the context to use to answer the user's question:\n" + response
            return context_prompt
        return ''

    def _make_request_with_retry(self, request_type: str, **converse_cmd):
        """Perform the Bedrock request with exponential backoff and jitter."""
        max_retries = 5
        base_delay = 30  # base delay in seconds
        for attempt in range(1, max_retries + 1):
            try:
                if request_type == "stream":
                    return self.client.converse_stream(**converse_cmd)
                else:
                    self.logger.info(message="Perform the bedrock request with converse.")
                    return self.client.converse(**converse_cmd)
            except (ClientError, Exception) as e:
                if attempt == max_retries:
                    # After max retries, re-raise the exception
                    raise

                sleep_time = base_delay + 30
                base_delay += 30
                self.logger.warning(message=f"Error during invoke_agent attempt {attempt}: {str(e)}. Retrying in {sleep_time:.2f}s...")
                time.sleep(sleep_time)

    def get_response_stream(
        self,
        converse_cmd: Dict[str, Any]
    ) -> Generator[str, None, None]:
        """Yields response text chunks as strings."""
        try:
            streaming_response = self._make_request_with_retry("stream", **converse_cmd)
            for event in streaming_response["stream"]:
                if 'contentBlockDelta' in event and 'delta' in event['contentBlockDelta']:
                    text = event['contentBlockDelta']['delta'].get("text", "")
                    if text:
                        if self.callbacks and hasattr(self.callbacks, 'on_llm_new_token'):
                            self.callbacks.on_llm_new_token(text)
                        yield text
        except (ClientError, Exception):
            yield "ERROR: Unable to process your request at this time."

    def get_response(
        self,
        converse_cmd: Dict[str, Any]
    ) -> Dict[str, Any]:
        try:
            response = self._make_request_with_retry("converse", **converse_cmd)
            return response
        except (ClientError, Exception) as e:
            return {"error": f"Unable to process your request at this time. Error: {str(e)}"}

    def process_query(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        interaction_history: List[Dict[str, Any]],
        images: Optional[List[Dict[str, Any]]] = None
    ) -> Iterable[Dict[str, Any]]:

        # Handle images separately
        image_result = self._handle_images(images)
        if isinstance(image_result, dict) and 'error' in image_result:
            yield image_result
            return
        user_message_content = image_result if image_result else []
        
        # Add user query
        user_message_content.append({"text": user_query})
        interaction_history.append({"role": "user", "content": user_message_content})

        # Retrieve context if needed
        context = self._get_context_if_available(user_id, session_id, user_query)
        if context:
            yield {'citation': self.retriever.citation}

        system_prompt = self._build_system_prompt(context)

        # Prepare messages for inference
        messages = self._prepare_messages(interaction_history)

        converse_cmd = self._build_converse_cmd(messages, system_prompt)
        continue_with_tools, final_response = self._initialize_tool_handling()

        if continue_with_tools:
            yield from self._handle_tool_logic(converse_cmd, user_id, session_id, user_query, interaction_history)
            return

        # Handle non-tool agents
        yield from self._handle_non_tool_agent(converse_cmd, user_id, session_id, user_query, interaction_history)


    def _handle_images(self, images: Optional[List[Dict[str, Any]]]) -> Union[List[Dict[str, Any]], Dict[str, str], None]:
        """
        Return Optional[List[Dict[str, Any]]]
        If error occurs, return None instead of a dict with error.
        """
        if not images:
            return None

        allowed_formats = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp']
        user_message_content: List[Dict[str, Any]] = []

        for image in images:
            fmt = image.get('format')
            content = image.get('content', b'')
            if not isinstance(content, bytes):
                content = bytes(content)
            if fmt in allowed_formats and content:
                actualformat = fmt.split('/')[1]
                try:
                    user_message_content.append({
                        "image": {
                            "format": actualformat,
                            "source": {"bytes": content}
                        }
                    })
                except Exception as e:
                    return {'error': f"Unable to process image. Error: {str(e)}"}
            else:
                return None
        return user_message_content


    def _get_context_if_available(self, user_id: str, session_id: str, query: str) -> str:
        context = ''
        if self.retriever:
            context = self.retrieve_context(user_id, session_id, query)
        return context


    def _build_system_prompt(self, context: str) -> str:
        system_prompt = self.system_prompt
        if context:
            system_prompt += context
        return system_prompt


    def _prepare_messages(self, interaction_history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [
            {
                "role": msg["role"],
                "content": msg["content"] if isinstance(msg["content"], list) else [{"text": msg["content"]}]
            }
            for msg in interaction_history
        ]


    def _build_converse_cmd(self, messages: List[Dict[str, Any]], system_prompt: str) -> Dict[str, Any]:
        converse_cmd = {
            "modelId": self.model_id,
            "messages": messages,
            "system": [{"text": system_prompt}],
            "inferenceConfig": self.llm_config
        }

        if self.guardrail_config:
            converse_cmd["guardrailConfig"] = self.guardrail_config

        if self.additionalmodelrequestfields:
            converse_cmd["additionalModelRequestFields"] = self.additionalmodelrequestfields

        if self.tool_config and 'tool' in self.tool_config:
            converse_cmd["toolConfig"] = {'tools': self.tool_config['tool']}

        return converse_cmd


    def _initialize_tool_handling(self) -> Tuple[bool, str]:
        if self.tool_config and 'tool' in self.tool_config:
            return True, ''
        return False, ''


    def _handle_tool_logic(
        self,
        converse_cmd: Dict[str, Any],
        user_id: str,
        session_id: str,
        user_query: str,
        interaction_history: List[Dict[str, Any]]
    ) -> Iterable[Dict[str, Any]]:
        max_recursions = self.tool_config.get('toolMaxRecursions', 2)
        while max_recursions > 0:
            system_prompt = self._add_instructions_to_system(self.system_prompt)
            converse_cmd['system'] = [{"text": system_prompt}]

            if self.streaming:
                assistant_message = self._process_streaming_response(converse_cmd)
            else:
                assistant_message = self._process_non_streaming_response(converse_cmd)
                if isinstance(assistant_message, dict) and 'error' in assistant_message:
                    yield assistant_message
                    return

            interaction_history.append({
                "role": assistant_message['role'],
                "content": self._extract_full_text(assistant_message)
            })

            tool_use = self._check_for_tool_use(assistant_message)
            if tool_use:
                result = self._handle_tool_use(tool_use, interaction_history)
                if isinstance(result, dict) and 'error' in result:
                    yield result
                    return
                max_recursions -= 1
                converse_cmd['messages'] = self._prepare_messages(interaction_history)
            else:
                # No tool use
                final_response = self._extract_full_text(assistant_message)
                yield from self._save_and_yield_final_response(user_id, session_id, user_query, final_response)
                return

        yield {'error': 'Maximum tool recursion limit reached.'}


    def _add_instructions_to_system(self, system_prompt: str) -> str:
        return (
            system_prompt +
            "\n\n"
            "Instructions for Assistant:\n"
            "1. If you require information from a tool, indicate this by specifying the tool name and required parameters.\n"
            "2. When you receive a user message starting with 'Tool Output:', treat the content that follows as the result from the tool.\n"
            "3. Use the tool output to provide a complete and final answer to the user.\n"
            "4. Do not attempt to invoke the tool again after receiving the tool output.\n"
            "5. Do not include 'Tool Output:' or any tool-related markers in your final response.\n"
            "6. Do not include any '<thinking>' tags in your final response.\n"
        )


    def _process_streaming_response(self, converse_cmd: Dict[str, Any]) -> Generator[Dict[str, Any], None, None]:
        response_generator = self.get_response_stream(converse_cmd)
        response_text = ''
        for chunk in response_generator:
            response_text += chunk
            # Since we're yielding Dict[str, Any] here, we must yield a dictionary consistently
            yield {'response': chunk}
        # At the end, instead of return, use yield if you need to provide a final value
        yield {"role": "assistant", "content": [{"text": response_text}]}


    def _process_non_streaming_response(self, converse_cmd: Dict[str, Any]) -> Any:
        response = self.get_response(converse_cmd)
        if 'error' in response:
            return response
        assistant_message = response['output']['message']
        full_text = self._extract_full_text(assistant_message)
        yield {'response': full_text}
        return assistant_message


    def _extract_full_text(self, assistant_message: Dict[str, Any]) -> str:
        return ''.join([block.get('text', '') for block in assistant_message['content']])


    def _check_for_tool_use(self, assistant_message: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        for content_block in assistant_message['content']:
            if 'toolUse' in content_block:
                return content_block['toolUse']
        return None


    def _handle_tool_use(
        self,
        tool_use: Dict[str, Any],
        interaction_history: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        tool_handler = self.tool_config.get('useToolHandler')
        if not tool_handler:
            return {'error': 'No tool handler provided.'}

        try:
            tool_response = tool_handler(tool_use, interaction_history)
        except Exception as e:
            return {'error': f"Error executing tool handler: {str(e)}"}

        interaction_history.append({
            "role": "user",
            "content": f"Tool Output:\n{tool_response}"
        })
        return None


    def _handle_non_tool_agent(
        self,
        converse_cmd: Dict[str, Any],
        user_id: str,
        session_id: str,
        user_query: str,
        interaction_history: List[Dict[str, Any]]
    ) -> Iterable[Dict[str, Any]]:
        if self.streaming:
            response_generator = self.get_response_stream(converse_cmd)
            response_text = ''
            for chunk in response_generator:
                response_text += chunk
                yield {'response': chunk}
            final_response = response_text
        else:
            response = self.get_response(converse_cmd)
            if 'error' in response:
                yield {'error': response['error']}
                return
            assistant_message = response['output']['message']
            final_response = self._extract_full_text(assistant_message)

        interaction_history.append({
            "role": "assistant",
            "content": final_response
        })
        self._save_and_yield_final_response(user_id, session_id, user_query, final_response)
        yield {'response': final_response}


    def _save_and_yield_final_response(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        final_response: str
    ) -> Iterable[Dict[str, Any]]:
        # Save user request
        self.storage.save(user_id, session_id, {"role": "user", "content": user_query})
        # Save the final response to storage
        self.storage.save(user_id, session_id, {"role": "assistant", "content": final_response})