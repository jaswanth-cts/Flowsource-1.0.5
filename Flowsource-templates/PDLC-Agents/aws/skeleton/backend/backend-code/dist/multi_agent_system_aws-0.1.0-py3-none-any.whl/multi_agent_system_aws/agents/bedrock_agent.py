# multi_agent_system_aws/agents/bedrock_agent.py

import os
import time
import random
import logging
import boto3
from dataclasses import dataclass
from typing import Any, Dict, List, Generator, Optional, Iterable
from botocore.exceptions import BotoCoreError, ClientError
from multi_agent_system_aws.agents.agent import Agent
from multi_agent_system_aws.storage.base_storage import BaseStorage
from multi_agent_system_aws.storage.memory_storage import MemoryStorage
from multi_agent_system_aws.utils.logger import MultiAgentSystemLogger

class BedrockAgent(Agent):
    MAX_COMPLETION_RETRIES = 5  # Number of total attempts including the initial one

    def __init__(
        self,
        name: str,
        description: str,
        region: str,
        agent_id: str = None,
        agent_alias_id: str = None,
        client: Optional[Any] = None,
        logger: Optional[MultiAgentSystemLogger] = None,
        storage: Optional[BaseStorage] = None,
        citation: Optional[bool] = None,
    ):
        super().__init__(name, description)
        self.region = region or os.environ.get('AWS_REGION')
        self.agent_id = agent_id
        self.agent_alias_id = agent_alias_id
        self.storage = storage or MemoryStorage()
        self.citations: List[Dict[str, str]] = []
        self.citation = citation
        self.logger = logger or MultiAgentSystemLogger()
        self.client = client or boto3.client('bedrock-agent-runtime', region_name=self.region)

    def retrieve_context(self, user_id: str, session_id: str, query: str) -> str:
        # No retrieval logic as requested
        self.logger.info(f'Your session id: {session_id}')
        self.logger.info(f'Your user id: {user_id}')

    @staticmethod
    def format_messages(messages: List[Dict[str, Any]]) -> str:
        return "\n".join([
            f"{message['role']}: {' '.join([message['content']])}" for message in messages
        ])

    def _make_request_with_retry(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        messages: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        max_retries = 5
        base_delay = 30  # base delay in seconds
        for attempt in range(1, max_retries + 1):
            try:
                response = self.client.invoke_agent(
                    agentId=self.agent_id,
                    agentAliasId=self.agent_alias_id,
                    sessionId=session_id,
                    inputText=user_query,
                    sessionState={'conversationHistory': {'messages': messages}}
                )
                self.logger.debug(message=f"invoke_agent successful on attempt {attempt}.")
                return response
            except (BotoCoreError, ClientError) as e:
                if attempt == max_retries:
                    raise
                sleep_time = base_delay + 30
                base_delay += 30
                self.logger.warning(f"Error during invoke_agent attempt {attempt}: {str(e)}. Retrying in {sleep_time:.2f}s...")
                time.sleep(sleep_time)

    def process_query(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        interaction_history: List[Dict[str, Any]],
        images: Optional[List[Dict[str, Any]]] = None,
        retry_count: int = 0
    ) -> Generator[Dict[str, Any], None, None]:
        if retry_count >= self.MAX_COMPLETION_RETRIES:
            yield {"error": "ERROR: Unable to process your request at this time after multiple completion retries."}
            return

        messages = self._prepare_messages(interaction_history)
        response = self._invoke_with_retry(user_id, session_id, user_query, messages)
        if 'error' in response:
            yield response
            return

        completion_events = response.get('completion', [])
        yield from self._handle_completion_events(
            user_id, session_id, user_query, interaction_history, images, completion_events, retry_count
        )

    def _invoke_with_retry(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        messages: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        try:
            return self._make_request_with_retry(user_id, session_id, user_query, messages)
        except (BotoCoreError, ClientError) as error:
            self.logger.error(f"Error processing request after retries from process_query bedrock agent: {str(error)}")
            return {"error": "ERROR: Unable to process your request at this time."}

    def _prepare_messages(self, interaction_history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [
            {
                "role": msg["role"],
                "content": msg["content"] if isinstance(msg["content"], list) else [{"text": msg["content"]}]
            }
            for msg in interaction_history
        ]

    def _handle_completion_events(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        interaction_history: List[Dict[str, Any]],
        images: Optional[List[Dict[str, Any]]],
        completion_events: List[Dict[str, Any]],
        retry_count: int
    ) -> Generator[Dict[str, Any], None, None]:
        try:
            response_text = self._process_completion_events(completion_events)
            yield from self._finalize_response(user_id, session_id, user_query, response_text)
        except (BotoCoreError, ClientError) as error:
            self.logger.error(f"Error processing request from completion event: {str(error)}")
            yield from self._handle_completion_error(user_id, session_id, user_query, interaction_history, images, retry_count)

    def _process_completion_events(self, completion_events: List[Dict[str, Any]]) -> str:
        response_text = ""
        self.citations.clear()
        for event in completion_events:
            if 'chunk' in event:
                chunk = event['chunk']
                decoded_response = chunk['bytes'].decode('utf-8')
                response_text += decoded_response
                if self.citation:
                    self._extract_citations(chunk)
            else:
                self.logger.warning("Received a chunk event with no chunk data")
        return response_text

    def _extract_citations(self, chunk: Dict[str, Any]) -> None:
        if 'attribution' in chunk and 'citations' in chunk['attribution']:
            raw_citations = chunk['attribution']['citations']
            if raw_citations and 'retrievedReferences' in raw_citations[0]:
                references = raw_citations[0]['retrievedReferences']
                for i, citation in enumerate(references):
                    content = citation['content']['text']
                    source = "source_" + str(i + 1)
                    context_item = {source: content}
                    self.citations.append(context_item)

    def _handle_completion_error(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        interaction_history: List[Dict[str, Any]],
        images: Optional[List[Dict[str, Any]]],
        retry_count: int
    ) -> Generator[Dict[str, Any], None, None]:
        # Re-run process_query if completion fails
        yield from self.process_query(
            user_id=user_id,
            session_id=session_id,
            user_query=user_query,
            interaction_history=interaction_history,
            images=images,
            retry_count=retry_count + 1
        )

    def _finalize_response(
        self,
        user_id: str,
        session_id: str,
        user_query: str,
        response_text: str
    ) -> Generator[Dict[str, Any], None, None]:
        if self.citations:
            yield {'citation': self.citations}

        self.storage.save(user_id, session_id, {"role": "user", "content": user_query})
        self.storage.save(user_id, session_id, {"role": "assistant", "content": response_text})

        yield {'response': response_text}