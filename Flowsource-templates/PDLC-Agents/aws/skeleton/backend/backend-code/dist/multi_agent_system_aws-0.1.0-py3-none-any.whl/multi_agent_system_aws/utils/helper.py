# multi_agent_system_aws/utils/helper.py

from typing import Any, List, Dict, Union

def is_tool_input(input_obj: Any) -> bool:
    """Check if the input object is a tool input."""
    return (
        isinstance(input_obj, dict)
        and 'selected_agent' in input_obj
        #and 'confidence' in input_obj
    )